#!/usr/bin/env python3
"""Serve the actual PNDCC Statistical Analysis page with the actual live-data
snapshot function, while deliberately not importing or starting PNDCC.

Usage:
  python3 PNDCC_V6_Isolated_Live_Page_Integration_Test.py /path/to/V6_candidate.py
Then open http://127.0.0.1:8798/statistical-analysis in a browser.
Press Ctrl+C to stop.
"""
import ast
import json
import math
import sys
import time
import urllib
import urllib.parse
import urllib.request
from datetime import datetime
from pathlib import Path
from threading import Lock
from concurrent.futures import ThreadPoolExecutor, as_completed
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

NAMES = {
    "_pndcc_cm_json_request", "_PNDCC_STATS_ASSETS", "_PNDCC_STATS_CACHE",
    "_PNDCC_STATS_LOCK", "_pndcc_stats_history", "_pndcc_stats_mean",
    "_pndcc_stats_std", "_pndcc_stats_regression", "_pndcc_stats_corr",
    "_pndcc_stats_snapshot", "_pndcc_stats_page",
}


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 PNDCC_V6_Isolated_Live_Page_Integration_Test.py /full/path/to/V6_candidate.py")
        return 2
    candidate = Path(sys.argv[1]).expanduser().resolve()
    if not candidate.is_file():
        print("FAIL: candidate file not found:", candidate)
        return 2
    source = candidate.read_text(encoding="utf-8")
    tree = ast.parse(source, filename=str(candidate))
    selected = []
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in NAMES:
            selected.append(node)
        elif isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id in NAMES for t in node.targets):
            selected.append(node)
    found = {n.name for n in selected if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
    required = {"_pndcc_cm_json_request", "_pndcc_stats_history", "_pndcc_stats_snapshot", "_pndcc_stats_page"}
    if not required.issubset(found):
        print("FAIL: expected production functions not found:", sorted(required - found))
        return 2
    ns = {"json": json, "math": math, "time": time, "urllib": urllib,
          "datetime": datetime, "Lock": Lock, "ThreadPoolExecutor": ThreadPoolExecutor,
          "as_completed": as_completed}
    mod = ast.Module(body=selected, type_ignores=[])
    ast.fix_missing_locations(mod)
    exec(compile(mod, "<isolated-pndcc-statistics-page>", "exec"), ns)
    page = ns["_pndcc_stats_page"]().encode("utf-8")
    if b"/api/statistical-analysis" not in page or b"function render(d)" not in page or b"id=\"refresh\"" not in page:
        print("FAIL: expected page render/API/refresh elements not found")
        return 2

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):
            print("[isolated-page]", fmt % args)
        def send_bytes(self, status, content_type, body):
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        def do_GET(self):
            parsed = urlparse(self.path)
            if parsed.path in ("/", "/statistical-analysis"):
                return self.send_bytes(200, "text/html; charset=utf-8", page)
            if parsed.path == "/api/statistical-analysis":
                force = parse_qs(parsed.query).get("force", ["0"])[0] == "1"
                try:
                    payload = ns["_pndcc_stats_snapshot"](force=force)
                    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
                    return self.send_bytes(200, "application/json; charset=utf-8", body)
                except Exception as exc:
                    body = json.dumps({"status":"error", "message":type(exc).__name__, "assets":[], "correlation":[]}).encode("utf-8")
                    return self.send_bytes(500, "application/json; charset=utf-8", body)
            return self.send_bytes(404, "text/plain; charset=utf-8", b"Not found")

    server = ThreadingHTTPServer(("127.0.0.1", 8798), Handler)
    server.daemon_threads = True
    print("ISOLATION: PASS — does not import PNDCC or execute its startup, monitor, dashboard, config, or history code")
    print("PAGE_SOURCE: extracted actual _pndcc_stats_page() from", candidate.name)
    print("API_SOURCE: extracted actual live _pndcc_stats_snapshot() and helper functions")
    print("BROWSER_URL: http://127.0.0.1:8798/statistical-analysis")
    print("TEST: verify live asset cards, correlation matrix, expandable forecast details, and Refresh data button")
    print("SAFETY: live Yahoo Finance requests only; no PNDCC config/history writes. Ctrl+C stops this test server.")
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        print("\nTEST SERVER STOPPED")
    finally:
        server.server_close()
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
