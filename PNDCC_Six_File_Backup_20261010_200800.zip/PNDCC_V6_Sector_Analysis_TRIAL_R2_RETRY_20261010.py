#!/usr/bin/env python3
"""PNDCC Sector Analysis R2 — isolated development candidate.
Does not import or start the PNDCC master application. R2 fixes Canadian TSX Yahoo Finance symbols and metric spacing.
Serves on 127.0.0.1:8799 and fetches public Yahoo Finance chart history.
"""
import json, math, time, urllib, urllib.parse, urllib.request
from datetime import datetime
from threading import Lock
from concurrent.futures import ThreadPoolExecutor, as_completed
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

_PNDCC_SECTOR_ASSETS = [
    {"name":'Technology — US (XLK)',"symbol":'US:XLK',"ticker":'XLK',"group":'US equity sector',"sector":'Technology',"country":'US'},
    {"name":'Technology — Canada (XIT)',"symbol":'CA:XIT',"ticker":'XIT',"group":'Canada equity sector',"sector":'Technology',"country":'Canada'},
    {"name":'Energy — US (XLE)',"symbol":'US:XLE',"ticker":'XLE',"group":'US equity sector',"sector":'Energy',"country":'US'},
    {"name":'Energy — Canada (XEG)',"symbol":'CA:XEG',"ticker":'XEG',"group":'Canada equity sector',"sector":'Energy',"country":'Canada'},
    {"name":'Financials — US (XLF)',"symbol":'US:XLF',"ticker":'XLF',"group":'US equity sector',"sector":'Financials',"country":'US'},
    {"name":'Financials — Canada (XFN)',"symbol":'CA:XFN',"ticker":'XFN',"group":'Canada equity sector',"sector":'Financials',"country":'Canada'},
    {"name":'Materials — US (XLB)',"symbol":'US:XLB',"ticker":'XLB',"group":'US equity sector',"sector":'Materials',"country":'US'},
    {"name":'Materials — Canada (XMA)',"symbol":'CA:XMA',"ticker":'XMA',"group":'Canada equity sector',"sector":'Materials',"country":'Canada'},
    {"name":'Diversified Funds — US (SPY)',"symbol":'US:SPY',"ticker":'SPY',"group":'US broad market',"sector":'Diversified Funds',"country":'US'},
    {"name":'Diversified Funds — Canada (XIU)',"symbol":'CA:XIU',"ticker":'XIU',"group":'Canada broad market',"sector":'Diversified Funds',"country":'Canada'},
    {"name":'Health Care — US (XLV)',"symbol":'US:XLV',"ticker":'XLV',"group":'US equity sector',"sector":'Health Care',"country":'US'},
    {"name":'Health Care — Canada (XHC)',"symbol":'CA:XHC',"ticker":'XHC',"group":'Canada healthcare proxy',"sector":'Health Care',"country":'Canada'},
    {"name":'Consumer Discretionary — US (XLY)',"symbol":'US:XLY',"ticker":'XLY',"group":'US equity sector',"sector":'Consumer Discretionary',"country":'US'},
    {"name":'Consumer Discretionary — Canada (XCD)',"symbol":'CA:XCD',"ticker":'XCD',"group":'Canada equity sector',"sector":'Consumer Discretionary',"country":'Canada'},
    {"name":'Communication Services — US (XLC)',"symbol":'US:XLC',"ticker":'XLC',"group":'US equity sector',"sector":'Communication Services',"country":'US'},
    {"name":'Communication Services — Canada (XIU)',"symbol":'CA:XIU-COMM',"ticker":'XIU',"group":'Canada broad market proxy (reused XIU)',"sector":'Communication Services',"country":'Canada'},
    {"name":'Utilities — US (XLU)',"symbol":'US:XLU',"ticker":'XLU',"group":'US equity sector',"sector":'Utilities',"country":'US'},
    {"name":'Utilities — Canada (ZUT)',"symbol":'CA:ZUT',"ticker":'ZUT',"group":'Canada equity sector',"sector":'Utilities',"country":'Canada'},
    {"name":'Industrials — US (XLI)',"symbol":'US:XLI',"ticker":'XLI',"group":'US equity sector',"sector":'Industrials',"country":'US'},
    {"name":'Industrials — Canada (ZIN)',"symbol":'CA:ZIN',"ticker":'ZIN',"group":'Canada equity sector',"sector":'Industrials',"country":'Canada'},
    {"name":'Consumer Staples — US (XLP)',"symbol":'US:XLP',"ticker":'XLP',"group":'US equity sector',"sector":'Consumer Staples',"country":'US'},
    {"name":'Consumer Staples — Canada (XST)',"symbol":'CA:XST',"ticker":'XST',"group":'Canada equity sector',"sector":'Consumer Staples',"country":'Canada'}
]
_PNDCC_SECTOR_CACHE = {"at":0.0,"data":None}
_PNDCC_SECTOR_LOCK = Lock()


def _pndcc_cm_json_request(url, headers=None, timeout=8):
    req = urllib.request.Request(url, headers=headers or {"User-Agent": "PNDCC-CapitalMarkets/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as response:
        raw = response.read(2 * 1024 * 1024 + 1)
    if len(raw) > 2 * 1024 * 1024:
        raise ValueError("provider response too large")
    return json.loads(raw.decode("utf-8"))

def _pndcc_sector_history(definition, timeout=2.2):
    # Yahoo Finance uses exchange suffixes for Toronto Stock Exchange listings.
    # Keep the user-facing ticker (XIT, XEG, etc.) unchanged in the UI, but
    # request the Canadian-listed symbol as XIT.TO, XEG.TO, and so on.
    ticker = definition["ticker"] + ".TO" if definition.get("country") == "Canada" else definition["ticker"]
    url = "https://query1.finance.yahoo.com/v8/finance/chart/" + urllib.parse.quote(ticker, safe="^=.-") + "?range=1y&interval=1d&events=history"
    payload = _pndcc_cm_json_request(url, headers={"User-Agent":"Mozilla/5.0 PNDCC-StatisticalAnalysis/1.0"}, timeout=timeout)
    chart = payload.get("chart") or {}
    errors = chart.get("error")
    results = chart.get("result") or []
    if errors or not results:
        raise ValueError("provider returned no history")
    item = results[0]
    stamps = item.get("timestamp") or []
    quote = ((item.get("indicators") or {}).get("quote") or [{}])[0]
    closes = quote.get("close") or []
    values=[]
    for stamp, close in zip(stamps, closes):
        if close is None:
            continue
        try:
            v=float(close)
            if math.isfinite(v) and v>0:
                values.append((datetime.fromtimestamp(int(stamp)).date().isoformat(), v))
        except Exception:
            continue
    if len(values)<40:
        raise ValueError("insufficient historical observations")
    return {"definition":definition, "observations":values, "currency":(item.get("meta") or {}).get("currency")}

def _pndcc_sector_mean(values):
    return sum(values)/len(values) if values else None

def _pndcc_sector_std(values):
    if len(values)<2: return None
    mean=_pndcc_sector_mean(values)
    return math.sqrt(sum((x-mean)**2 for x in values)/(len(values)-1))

def _pndcc_sector_regression(xs, ys):
    n=min(len(xs),len(ys))
    if n<3: return None
    xs=xs[:n]; ys=ys[:n]
    xm=_pndcc_sector_mean(xs); ym=_pndcc_sector_mean(ys)
    ssx=sum((x-xm)**2 for x in xs)
    ssy=sum((y-ym)**2 for y in ys)
    if ssx<=0 or ssy<=0: return None
    slope=sum((x-xm)*(y-ym) for x,y in zip(xs,ys))/ssx
    intercept=ym-slope*xm
    residuals=[y-(intercept+slope*x) for x,y in zip(xs,ys)]
    r2=1-sum(e*e for e in residuals)/ssy
    residual_se=math.sqrt(sum(e*e for e in residuals)/max(1,n-2))
    return {"slope":slope,"intercept":intercept,"r2":max(0.0,min(1.0,r2)),"residual_se":residual_se,"n":n}

def _pndcc_sector_corr(a,b):
    n=min(len(a),len(b))
    if n<3: return None
    a=a[:n]; b=b[:n]; am=_pndcc_sector_mean(a); bm=_pndcc_sector_mean(b)
    den=math.sqrt(sum((x-am)**2 for x in a)*sum((y-bm)**2 for y in b))
    if den<=0:return None
    return max(-1.0,min(1.0,sum((x-am)*(y-bm) for x,y in zip(a,b))/den))

def _pndcc_sector_snapshot(force=False):
    now=time.time()
    with _PNDCC_SECTOR_LOCK:
        cached=_PNDCC_SECTOR_CACHE
        if not force and cached["data"] is not None and now-cached["at"]<300:
            return cached["data"]
        pool=ThreadPoolExecutor(max_workers=12)
        futures={pool.submit(_pndcc_sector_history,d):d for d in _PNDCC_SECTOR_ASSETS}
        histories={}; errors=[]
        try:
            for future in as_completed(futures,timeout=12.0):
                definition=futures[future]
                try: histories[definition["symbol"]]=future.result()
                except Exception as exc: errors.append(definition["symbol"]+": "+type(exc).__name__)
        except Exception as exc:
            errors.append("history deadline: "+type(exc).__name__)
        finally:
            pool.shutdown(wait=False,cancel_futures=True)
        assets=[]
        for definition in _PNDCC_SECTOR_ASSETS:
            item=histories.get(definition["symbol"])
            if not item:
                assets.append({"name":definition["name"],"symbol":definition["symbol"],"group":definition["group"],"status":"unavailable","observations":0})
                continue
            obs=item["observations"]; prices=[x[1] for x in obs]
            returns=[prices[i]/prices[i-1]-1 for i in range(1,len(prices)) if prices[i-1]>0]
            reg=_pndcc_sector_regression(list(range(len(prices))),prices)
            last=prices[-1]; first=prices[0]
            sma20=_pndcc_sector_mean(prices[-20:]); sma50=_pndcc_sector_mean(prices[-50:]) if len(prices)>=50 else None
            vol=_pndcc_sector_std(returns)
            forecast={}
            if reg:
                for label,horizon in (("1_week",5),("1_month",21),("1_quarter",63)):
                    point=reg["intercept"]+reg["slope"]*(len(prices)-1+horizon)
                    # Descriptive residual band only; not a calibrated predictive interval.
                    spread=1.96*reg["residual_se"]*math.sqrt(1+horizon/max(1,len(prices)))
                    forecast[label]={"estimate":round(point,6),"lower":round(point-spread,6),"upper":round(point+spread,6)}
            assets.append({"name":definition["name"],"symbol":definition["symbol"],"group":definition["group"],"ticker":definition["ticker"],"status":"available","provider":"Yahoo Finance chart endpoint","currency":item.get("currency"),"last_date":obs[-1][0],"price":round(last,6),"period_change_pct":round((last/first-1)*100,3),"observations":len(prices),"sma20":round(sma20,6) if sma20 is not None else None,"sma50":round(sma50,6) if sma50 is not None else None,"daily_volatility_pct":round(vol*100,4) if vol is not None else None,"annualized_volatility_pct":round(vol*math.sqrt(252)*100,3) if vol is not None else None,"trend_slope_per_day":round(reg["slope"],8) if reg else None,"in_sample_r2":round(reg["r2"],4) if reg else None,"forecast":forecast,"history":obs})
        # Pairwise correlation uses aligned dates and daily percentage returns.
        return_map={}
        for sym,item in histories.items():
            obs=item["observations"]
            return_map[sym]={obs[i][0]:obs[i][1]/obs[i-1][1]-1 for i in range(1,len(obs)) if obs[i-1][1]>0}
        symbols=[a["symbol"] for a in assets if a["status"]=="available"]
        corr=[]
        for s1 in symbols:
            row={"symbol":s1,"values":{}}
            for s2 in symbols:
                shared=sorted(set(return_map.get(s1,{})) & set(return_map.get(s2,{})))
                row["values"][s2]=round(_pndcc_sector_corr([return_map[s1][d] for d in shared],[return_map[s2][d] for d in shared]),3) if len(shared)>=30 and _pndcc_sector_corr([return_map[s1][d] for d in shared],[return_map[s2][d] for d in shared]) is not None else None
            corr.append(row)
        result={"provider":"Yahoo Finance chart endpoint","status":"online" if histories else "unavailable","checked_at":datetime.now().astimezone().isoformat(timespec="seconds"),"cache_seconds":300,"assets":assets,"correlation_symbols":symbols,"correlation":corr,"errors":errors[:12],"methodology":{"history":"approximately 1 year of daily closes","correlation":"Pearson correlation of daily percentage returns on shared dates; at least 30 observations","trend":"in-sample OLS trend of price level against observation index","forecast":"linear trend extrapolation with descriptive residual bands; not a calibrated prediction interval","r2":"in-sample goodness-of-fit only; not forecast accuracy"},"disclaimer":"Analytical/educational only; not investment advice. Correlation is not causation. Forecasts are experimental model estimates and may fail materially."}
        cached["at"],cached["data"]=now,result
        return result

def _pndcc_sector_page_base():
    return r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>PNDCC Statistical Analysis</title><style>
:root{color-scheme:light dark}body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;max-width:1440px;margin:auto;padding:20px;background:Canvas;color:CanvasText}.top{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}.panel{border:1px solid #8885;border-radius:12px;padding:14px;margin:14px 0;overflow:hidden}.muted{opacity:.72;font-size:.9rem}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:10px}.kpi{position:relative;border:1px solid #8885;border-radius:10px;padding:12px;transition:box-shadow .14s ease;min-width:0}.kpi h3{margin:0 0 8px;font-size:1rem}.big{font-size:1.3rem;font-weight:700}.tablewrap{overflow:auto}table{border-collapse:collapse;width:100%;font-size:.9rem}th,td{text-align:left;padding:8px;border-bottom:1px solid #8884;white-space:nowrap}thead th{position:sticky;top:0;z-index:3;background:Canvas}tbody th{position:static;background:Canvas}button,a.btn{font:inherit;padding:8px 12px;border-radius:8px;border:1px solid #8888;background:ButtonFace;color:ButtonText;text-decoration:none;cursor:pointer}.heat{display:grid;gap:3px;grid-template-columns:repeat(auto-fit,minmax(75px,1fr));margin-top:10px}.cell{padding:7px 4px;text-align:center;border-radius:5px;font-size:.82rem;background:#8882}.notice{border-left:4px solid #b8860b;padding:10px 12px;background:#b8860b14}.error{color:#b45309}.hover-trend{display:none;margin-top:10px;padding-top:9px;border-top:1px solid #8885}.hover-trend svg{display:block;width:100%;height:112px;cursor:zoom-in}.hover-trend svg:focus{outline:2px solid #64748b;outline-offset:3px}.kpi.trend-closed .hover-trend,.kpi.trend-closed .inference{display:none!important}.chart-zoom-overlay{position:fixed;inset:0;z-index:99999;display:none;align-items:center;justify-content:center;padding:22px;background:rgba(0,0,0,.76)}.chart-zoom-overlay.open{display:flex}.chart-zoom-dialog{width:min(1200px,96vw);max-height:92vh;overflow:auto;background:Canvas;color:CanvasText;border:1px solid #8888;border-radius:16px;padding:16px;box-shadow:0 18px 60px #0008}.chart-zoom-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:12px}.chart-zoom-dialog svg{display:block;width:100%;height:min(62vh,620px);min-height:360px;cursor:crosshair;touch-action:pan-y}.chart-zoom-dialog .chart-legend{font-size:.9rem}#corr table{table-layout:auto}#corr th.compact-col,#corr td.compact-col{width:86px;min-width:86px;max-width:86px;padding-left:7px;padding-right:7px;text-align:center}#corr th.compact-col{white-space:normal;overflow-wrap:anywhere;line-height:1.2}#corr td.compact-col{white-space:nowrap}.hover-trend .trend-meta{font-size:.76rem;opacity:.8;display:flex;justify-content:space-between;gap:6px}.kpi:hover .hover-trend,.kpi:focus-within .hover-trend,.kpi.trend-open .hover-trend{display:block}.kpi:hover,.kpi:focus-within{box-shadow:0 6px 22px #0002;z-index:2}.inference{display:none;position:absolute;z-index:10;left:10px;right:10px;top:100%;margin-top:5px;padding:9px 11px;background:Canvas;color:CanvasText;border:1px solid #64748b88;border-radius:8px;box-shadow:0 8px 24px #0002;white-space:normal;line-height:1.35;font-size:.84rem}.inference b{display:inline;font-size:.72rem;text-transform:uppercase;letter-spacing:.04em;color:#64748b;margin-right:5px}.inference-grid{display:none}.insight-card{display:none}.kpi:hover .inference,.kpi:focus-within .inference,.kpi.trend-open .inference{display:block}.stat-tip{position:relative;display:inline-block;cursor:help;border-bottom:1px dotted #64748b;z-index:1}.stat-tip:hover,.stat-tip:focus{z-index:101}.metric-help-row{display:flex;flex-direction:column;align-items:flex-start;justify-content:flex-start;gap:7px;line-height:1.45}.metric-help-row .stat-tip{display:block;width:fit-content;max-width:100%}.metric-help-row .stat-tip{max-width:100%}.info-dot{display:inline-flex;align-items:center;justify-content:center;font-size:.78rem;font-weight:800;line-height:1;width:15px;height:15px;border:1px solid currentColor;border-radius:50%;vertical-align:middle;margin:0 3px}.stat-tip:focus{outline:2px solid #64748b}.stat-tip[data-tip]:hover:after,.stat-tip[data-tip]:focus:after{content:attr(data-tip);position:absolute;z-index:100;left:0;top:auto;bottom:calc(100% + 7px);min-width:180px;max-width:300px;white-space:normal;pointer-events:none;padding:8px 10px;border:1px solid #64748b88;border-radius:7px;background:Canvas;color:CanvasText;box-shadow:0 6px 18px #0002;font-size:.82rem;font-weight:400;line-height:1.35}
/* R7: use a viewport-level tooltip so card/table overflow and neighbouring text cannot clip or obscure explanations. */
.stat-tip[data-tip]:hover:after,.stat-tip[data-tip]:focus:after{content:none!important;display:none!important}
#pndcc-stat-tooltip{position:fixed;display:none;z-index:2147483647;box-sizing:border-box;width:max-content;min-width:180px;max-width:min(320px,calc(100vw - 24px));padding:9px 11px;white-space:normal;overflow-wrap:anywhere;pointer-events:none;border:1px solid #666;border-radius:8px;background:#000!important;color:#fff!important;box-shadow:0 10px 30px #000b;font-size:.83rem;font-weight:400;line-height:1.4;opacity:1!important}.trend-summary{font-size:.82rem;font-weight:600;margin-top:5px;color:#16845b}.trend-summary.down{color:#c24141}.kpi:nth-child(3n+1){border-top:2px solid #64748b}.kpi:nth-child(3n+2){border-top:2px solid #16845b}.kpi:nth-child(3n){border-top:2px solid #b8860b}.kpi .hint{font-size:.76rem;opacity:.72;margin-top:8px}.kpi:focus{outline:2px solid #64748b;outline-offset:2px}details{margin:8px 0}summary{cursor:pointer;font-weight:600}
/* Isolated hover reveal: the upper snapshot controls visibility of the two following analysis sections. */
/* Reveal sections while pointer/focus is within the complete analysis group; touch users always retain access. */
.stats-reveal .reveal-section{display:none}
.stats-reveal:hover .reveal-section,.stats-reveal:focus-within .reveal-section{display:block}
.reveal-hint{font-size:.76rem;margin-top:10px;opacity:.72}
@media(hover:none){.stats-reveal .reveal-section{display:block}.reveal-hint{display:none}}
/* V6 visual-only card treatment: restrained colour accents and subtle 3D depth. */
#assets .kpi{--card-accent:#64748b;background:color-mix(in srgb,var(--card-accent) 5%,Canvas);border:1px solid color-mix(in srgb,var(--card-accent) 34%,transparent);border-top:3px solid var(--card-accent);border-radius:13px;box-shadow:0 2px 4px #0000000a,0 7px 16px #0000000b;transform:perspective(900px) translateY(0) rotateX(0);transform-origin:center bottom;transition:transform .18s ease,box-shadow .18s ease,border-color .18s ease,background-color .18s ease}
#assets .kpi:nth-child(3n+1){--card-accent:#647db5}
#assets .kpi:nth-child(3n+2){--card-accent:#168b83}
#assets .kpi:nth-child(3n){--card-accent:#b8860b}
#assets .kpi h3{color:color-mix(in srgb,var(--card-accent) 82%,CanvasText)}
#assets .kpi .sma20{color:#2563eb;font-weight:650}#assets .kpi .sma50{color:#8b5e3c;font-weight:650}
.period-positive{color:#16845b;font-weight:700}.period-negative{color:#c24141;font-weight:700}.period-neutral{color:CanvasText;font-weight:650}
.chart-legend{display:flex;flex-wrap:wrap;gap:7px 12px;font-size:.74rem;margin-top:6px}.chart-legend span{display:inline-flex;align-items:center;gap:4px}.chart-legend i{display:inline-block;width:14px;height:3px;border-radius:2px}
.data-sources{border:1px solid #8885;border-radius:12px;padding:14px;margin:18px 0 8px}.data-sources h2{margin-top:0}.data-sources ul{padding-left:20px}.data-sources li{margin:6px 0}
#assets .kpi:hover,#assets .kpi:focus-within,#assets .kpi.trend-open{transform:perspective(900px) translateY(-3px) rotateX(.35deg);box-shadow:0 4px 7px #0000000d,0 14px 28px #00000020,0 2px 0 color-mix(in srgb,var(--card-accent) 30%,transparent);border-color:color-mix(in srgb,var(--card-accent) 60%,transparent);z-index:2}
#assets .kpi:focus{outline:2px solid var(--card-accent);outline-offset:3px}
/* R3: dark, high-contrast tooltip and Findings surfaces. */
.stat-tip[data-tip]:hover:after,.stat-tip[data-tip]:focus:after{background:#000000!important;color:#ffffff!important;border-color:#555555!important;box-shadow:0 10px 28px #000b!important}
#assets .kpi .inference{background:#000000!important;color:#ffffff!important;border-color:#555555!important;box-shadow:0 10px 28px #000b!important}
#assets .kpi .inference b{color:#93c5fd!important}
/* Explicit collapse must override hover/focus reveal rules for every card, including the first six. */
#assets .kpi.trend-closed .hover-trend,#assets .kpi.trend-closed .inference{display:none!important}
#assets .kpi .inference{position:relative;left:auto;right:auto;top:auto;margin-top:8px;border-color:color-mix(in srgb,var(--card-accent) 48%,transparent);box-shadow:0 6px 16px #00000012}
#assets .kpi .inference b{color:var(--card-accent)}
/* Correlation comments open below their cell so the first rows are not hidden under the top border. */
#corr .corr-tip[data-tip]:hover:after,#corr .corr-tip[data-tip]:focus:after{top:calc(100% + 7px)!important;bottom:auto!important;left:0;z-index:120;background:#000000!important;color:#ffffff!important;border-color:#555555!important}
#corr .corr-tip{z-index:2}
/* Keep lower-row correlation comments inside the table viewport by opening them upward. */
#corr tr.corr-bottom-row .corr-tip[data-tip]:hover:after,#corr tr.corr-bottom-row .corr-tip[data-tip]:focus:after{top:auto!important;bottom:calc(100% + 7px)!important;left:auto;right:0;z-index:130;background:#000000!important;color:#ffffff!important;border-color:#555555!important}
@media(hover:none){#assets .kpi:hover{transform:none;box-shadow:0 2px 4px #0000000a,0 7px 16px #0000000b}}
@media(prefers-reduced-motion:reduce){#assets .kpi{transition:none}#assets .kpi:hover,#assets .kpi:focus-within,#assets .kpi.trend-open{transform:none}}
</style></head><body>
<div class="top"><div><div class="muted">PNDCC · CAPITAL MARKETS</div><h1>Statistical Analysis</h1><div class="muted">Historical relationships · Trend diagnostics · Experimental forecasts</div></div><div><a class="btn" href="/capital-markets">Capital Markets</a> <a class="btn" href="/">Dashboard</a> <button id="refresh">Refresh data</button></div></div>
<div id="stats-reveal" class="stats-reveal">
<section id="stats-upper" class="panel"><h2>Market snapshot & trend statistics</h2><div id="status" class="muted">Loading historical data…</div><div id="assets" class="cards"></div><div class="muted reveal-hint">Hover over this section to reveal Correlation Matrix and Trend & Forecast Details. Move away to collapse them; on touch screens, sections remain visible.</div></section>
<section class="panel reveal-section" aria-label="Correlation matrix"><h2>Correlation matrix</h2><div class="muted">Pearson correlations of daily percentage returns over shared dates; at least 30 paired observations. Correlation does not establish causation.</div><div id="corr" class="tablewrap">Loading…</div></section>
<section class="panel reveal-section" aria-label="Trend and forecast details"><h2>Trend and forecast details</h2><div id="forecast">Loading…</div></section>
</div><div class="muted" id="stamp"></div>
<section class="data-sources" aria-label="Data sources and methodology"><h2>Data Sources &amp; Methodology</h2><ul>
<li><b>Historical market prices:</b> Yahoo Finance chart endpoint. Prices and histories may be delayed, incomplete, or temporarily unavailable.</li>
<li><b>Calculated indicators:</b> SMA20 and SMA50 are calculated from historical closing prices for the snapshot cards; the trend chart shows only actual prices and the linear trend. Annualized volatility is estimated from daily returns; R² measures in-sample linear trendline fit.</li>
<li><b>Trendline and forecasts:</b> The straight line is a least-squares linear fit to historical price levels. Forecasts are experimental linear extrapolations with descriptive residual bands, not calibrated prediction intervals.</li>
<li><b>Interpretation limits:</b> In-sample R² is not forecast accuracy. Historical volatility and trend fit do not guarantee future performance. Correlation does not establish causation.</li>
<li><b>Disclaimer:</b> For analytical and educational purposes only. Not investment advice.</li>
</ul></section>
<div id="stats-chart-zoom" class="chart-zoom-overlay" aria-hidden="true"><div class="chart-zoom-dialog" role="dialog" aria-modal="true" aria-labelledby="stats-chart-zoom-title"><div class="chart-zoom-head"><h2 id="stats-chart-zoom-title">Expanded trend chart</h2><button type="button" id="stats-chart-zoom-close">Close ✕</button></div><div id="stats-chart-zoom-body"></div><p class="muted">Expanded view · hover over the line for the value only. Press Escape or click outside to close.</p></div></div>
<script>
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));const fmt=(v,d=2)=>v===null||v===undefined||!Number.isFinite(Number(v))?'—':Number(v).toLocaleString(undefined,{maximumFractionDigits:d});
function inferenceBox(text,caution=''){return '<div class="inference"><b>Findings</b>'+esc(text)+(caution?'<div class="muted" style="margin-top:4px">'+esc(caution)+'</div>':'')+'</div>'}
function trendSvg(a,large=false){
 const h=Array.isArray(a.history)?a.history.filter(x=>Array.isArray(x)&&x.length>=2&&Number.isFinite(Number(x[1]))):[];
 if(h.length<2)return '<div class="muted">Historical trend unavailable.</div>';
 const vals=h.map(x=>Number(x[1])),n=vals.length,w=large?1100:320,ht=large?430:126,padL=large?54:12,padR=large?24:12,padT=large?24:10,padB=large?52:30;
 const xm=(n-1)/2,ym=vals.reduce((s,v)=>s+v,0)/n;
 const den=vals.reduce((s,_,i)=>s+(i-xm)*(i-xm),0);
 const slope=den?vals.reduce((s,v,i)=>s+(i-xm)*(v-ym),0)/den:0;
 const intercept=ym-slope*xm,linear=vals.map((_,i)=>intercept+slope*i);
 const rolling=period=>vals.map((_,i)=>i+1<period?null:vals.slice(i-period+1,i+1).reduce((s,v)=>s+v,0)/period);
 const sma20=rolling(20),sma50=rolling(50);
 const all=vals.concat(linear,sma20.filter(v=>v!==null),sma50.filter(v=>v!==null)),lo=Math.min(...all),hi=Math.max(...all),span=hi-lo||1;
 const xAt=i=>padL+i*(w-padL-padR)/(n-1),yAt=v=>ht-padB-(v-lo)*(ht-padT-padB)/span;
 const points=arr=>arr.map((v,i)=>v===null?null:`${xAt(i).toFixed(2)},${yAt(v).toFixed(2)}`).filter(Boolean).join(' ');
 const actual=points(vals),fit=points(linear),s20=points(sma20),s50=points(sma50);
 const shortDate=value=>{const raw=String(value??'');let d=new Date(raw.length===10?raw+'T12:00:00':raw);return Number.isNaN(d.getTime())?raw.slice(5,10):d.toLocaleDateString('en-US',{month:'short'})+"'"+d.getDate()+'/'+d.getFullYear()};
 const tickIndices=[...new Set(Array.from({length:Math.min(6,n)},(_,k)=>Math.round(k*(n-1)/(Math.min(6,n)-1||1))) )];
 const dateTicks=tickIndices.map(i=>`<line x1="${xAt(i)}" y1="${ht-padB+2}" x2="${xAt(i)}" y2="${ht-padB+6}" stroke="currentColor" opacity=".55"/><text x="${xAt(i)}" y="${ht-5}" text-anchor="${i===0?'start':i===n-1?'end':'middle'}" fill="currentColor" opacity=".78" font-size="${large?13:9}">${esc(shortDate(h[i][0]))}</text>`).join('');
 // Hover labels intentionally show only the value, never the date or period.
 const hoverPoints=vals.map((v,i)=>`<circle cx="${xAt(i).toFixed(2)}" cy="${yAt(v).toFixed(2)}" r="${large?5:3.5}" fill="transparent" stroke="transparent" pointer-events="all"><title>${fmt(v,0)}</title></circle>`).join('');
 const first=vals[0],last=vals[n-1],chg=first?((last/first)-1)*100:0;
 return `<svg viewBox="0 0 ${w} ${ht}" role="img" tabindex="0" aria-label="Historical price, SMA20, SMA50 and linear trend for ${esc(a.name)}" data-asset-name="${esc(a.name)}"><line x1="${padL}" y1="${ht-padB}" x2="${w-padR}" y2="${ht-padB}" stroke="currentColor" opacity=".25"/><line x1="${padL}" y1="${padT+(ht-padT-padB)/2}" x2="${w-padR}" y2="${padT+(ht-padT-padB)/2}" stroke="currentColor" opacity=".12"/><polyline points="${actual}" fill="none" stroke="#475569" stroke-width="${large?3:1.8}" stroke-linejoin="round" stroke-linecap="round"/><polyline points="${fit}" fill="none" stroke="#d97706" stroke-width="${large?3.5:2}" stroke-dasharray="${large?'10 6':'5 3'}" stroke-linejoin="round"/><polyline points="${s20}" fill="none" stroke="#2563eb" stroke-width="${large?3:1.8}" stroke-linejoin="round" stroke-linecap="round"/><polyline points="${s50}" fill="none" stroke="#8b5e3c" stroke-width="${large?3:1.8}" stroke-linejoin="round" stroke-linecap="round"/>${dateTicks}${hoverPoints}</svg><div class="chart-legend"><span><i style="background:#475569"></i>Actual price</span><span><i style="background:#d97706"></i>Linear trend</span><span><i style="background:#2563eb"></i>SMA20</span><span><i style="background:#8b5e3c"></i>SMA50</span></div><div class="trend-meta"><strong class="${chg>0?'period-positive':chg<0?'period-negative':'period-neutral'}">${chg>0?'+':''}${fmt(chg)}% over displayed history</strong></div>${large?'':`<div class="trend-summary ${chg<0?'down':''}">${esc(assetInference(a).split('. ')[1]||assetInference(a).split('. ')[0])}</div>`}`
}
function assetInference(a){
 if(a.status!=='available')return 'History unavailable; no reliable reading yet.';
 const bits=[];
 const change=Number(a.period_change_pct);
 if(Number.isFinite(change))bits.push(`Price ${change>=0?'rose':'fell'} ${Math.abs(change).toFixed(1)}% over this sample.`);
 const price=Number(a.price),s20=Number(a.sma20),s50=Number(a.sma50);
 if(Number.isFinite(price)&&Number.isFinite(s20)&&Number.isFinite(s50)){
  bits.push(price>s20&&price>s50?'Price is above both moving averages.':price<s20&&price<s50?'Price is below both moving averages.':'Price sits between the moving-average levels.');
 }
 const vol=Number(a.annualized_volatility_pct);
 if(Number.isFinite(vol))bits.push(vol>=25?'Price swings have been large.':vol>=10?'Price swings have been moderate.':'Price swings have been relatively small.');
 return bits.join(' ');
}
function regressionInference(a){const r=Number(a.in_sample_r2),s=Number(a.trend_slope_per_day);if(!Number.isFinite(r)||!Number.isFinite(s))return 'There is not enough valid history to fit a linear trend.';const fit=r>=.7?'The straight-line trend describes much of the variation in this historical price series.':r>=.35?'The straight-line trend captures some historical movement, but substantial variation remains.':'The straight-line trend explains little of the historical movement; do not rely on it alone.';return (s>0?'The fitted line slopes upward.':s<0?'The fitted line slopes downward.':'The fitted line is nearly flat.')+' '+fit}
function forecastInference(a,v){const now=Number(a.price),est=Number(v.estimate),delta=now?((est/now)-1)*100:NaN,fit=Number(a.in_sample_r2);const move=Number.isFinite(delta)?`The model estimate is ${Math.abs(delta).toFixed(2)}% ${delta>=0?'above':'below'} the latest price.`:'The latest price is unavailable for comparison.';return `${move} This is a mechanical extension of the historical line, not a promise; ${Number.isFinite(fit)&&fit<.35?'the historical linear fit is weak, so extra caution is warranted.':'future conditions can differ from this historical sample.'}`}
function correlationText(v){if(v===null||!Number.isFinite(Number(v)))return 'Insufficient aligned data to estimate this relationship.';v=Number(v);const strength=Math.abs(v)>=.8?'very strong':Math.abs(v)>=.6?'strong':Math.abs(v)>=.4?'moderate':Math.abs(v)>=.2?'weak':'very weak';return `${strength} ${v>=0?'positive':'negative'} relationship: these assets have tended to move ${v>=0?'in the same':'in opposite'} directions on the same days. This does not show that one causes the other.`}
function assetIcon(a){
 const s=String(a.symbol||'').toUpperCase(),g=String(a.group||'').toLowerCase(),name=String(a.name||'').toLowerCase();
 if(g.includes('crypto')||s==='BTC'||s==='ETH')return s==='BTC'?'₿':'◆';
 if(g.includes('currency')||g==='fx'||s.includes('/'))return '💱';
 if(g.includes('commodity')||name.includes('gold')||name.includes('oil'))return name.includes('gold')?'🥇':'🛢️';
 if(g.includes('bond')||name.includes('bond')||name.includes('treasury'))return '🏦';
 if(g.includes('index')||name.includes('index')||name.includes('nasdaq')||name.includes('s&p')||name.includes('dow')||name.includes('tsx'))return '📈';
 return '📊';
}
function periodClass(v){const n=Number(v);return !Number.isFinite(n)||n===0?'period-neutral':n>0?'period-positive':'period-negative'}
function volatilityText(v){
 if(v===null||v===undefined||!Number.isFinite(Number(v)))return 'Annualized volatility is unavailable for this sample.';
 const n=Number(v);let level=n<10?'Low':n<25?'Moderate':'High';
 const meaning=n<10?'historical price swings were relatively small in this sample':n<25?'historical price swings were noticeable in this sample':'historical price swings were relatively large in this sample';
 return `${level} volatility: ${meaning}. Higher volatility can mean larger price swings and greater price risk; lower volatility does not mean an investment is risk-free. These are rough guideposts, not universal thresholds or predictions.`;
}
function r2Text(v){
 if(v===null||v===undefined||!Number.isFinite(Number(v)))return 'R² is unavailable because there is not enough valid data to fit a trendline.';
 const n=Number(v),fit=n>=.7?'a relatively close fit to historical prices':n>=.4?'a moderate fit to historical prices':'a weak fit to historical prices';
 return `R² shows how closely the trendline fits historical prices. Higher values mean a closer fit—not a prediction of future performance. R² = ${n.toFixed(3)} indicates ${fit}. It is not a probability of success or a measure of forecast accuracy.`;
}
// R7: shared fixed-position tooltip avoids clipping inside cards and the horizontally scrolling correlation table.
const pndccStatTooltip=document.createElement('div');pndccStatTooltip.id='pndcc-stat-tooltip';pndccStatTooltip.setAttribute('role','tooltip');pndccStatTooltip.setAttribute('aria-hidden','true');document.body.appendChild(pndccStatTooltip);let pndccTooltipTarget=null;
function hidePndccStatTooltip(){pndccStatTooltip.style.display='none';pndccStatTooltip.setAttribute('aria-hidden','true');pndccTooltipTarget=null}
function showPndccStatTooltip(el){if(!el||!el.matches('.stat-tip[data-tip]'))return;const message=el.getAttribute('data-tip');if(!message)return;pndccTooltipTarget=el;pndccStatTooltip.textContent=message;pndccStatTooltip.style.display='block';pndccStatTooltip.style.left='12px';pndccStatTooltip.style.top='12px';const r=el.getBoundingClientRect(),t=pndccStatTooltip.getBoundingClientRect(),gap=9,pad=12;let left=Math.max(pad,Math.min(r.left,window.innerWidth-t.width-pad));let top=r.top-t.height-gap;if(top<pad)top=Math.min(window.innerHeight-t.height-pad,r.bottom+gap);top=Math.max(pad,top);pndccStatTooltip.style.left=Math.round(left)+'px';pndccStatTooltip.style.top=Math.round(top)+'px';pndccStatTooltip.setAttribute('aria-hidden','false')}
document.addEventListener('pointerover',e=>{const el=e.target.closest&&e.target.closest('.stat-tip[data-tip]');if(el)showPndccStatTooltip(el)});document.addEventListener('pointerout',e=>{const el=e.target.closest&&e.target.closest('.stat-tip[data-tip]');if(el&&(!e.relatedTarget||!el.contains(e.relatedTarget)))hidePndccStatTooltip()});document.addEventListener('focusin',e=>{const el=e.target.closest&&e.target.closest('.stat-tip[data-tip]');if(el)showPndccStatTooltip(el)});document.addEventListener('focusout',e=>{const el=e.target.closest&&e.target.closest('.stat-tip[data-tip]');if(el)hidePndccStatTooltip()});window.addEventListener('scroll',()=>{if(pndccTooltipTarget)showPndccStatTooltip(pndccTooltipTarget)},true);window.addEventListener('resize',()=>{if(pndccTooltipTarget)showPndccStatTooltip(pndccTooltipTarget)});
const statsZoom=document.getElementById('stats-chart-zoom');
function closeStatsChartZoom(){statsZoom.classList.remove('open');statsZoom.setAttribute('aria-hidden','true');document.getElementById('stats-chart-zoom-body').innerHTML=''}
function showChartZoom(card){
 const asset=JSON.parse(card.dataset.asset||'{}');
 document.getElementById('stats-chart-zoom-title').textContent=(asset.name||'Asset')+' — expanded trend';
 document.getElementById('stats-chart-zoom-body').innerHTML=trendSvg(asset,true);
 statsZoom.classList.add('open');statsZoom.setAttribute('aria-hidden','false');
 document.getElementById('stats-chart-zoom-close').focus();
}
document.getElementById('stats-chart-zoom-close').addEventListener('click',closeStatsChartZoom);
statsZoom.addEventListener('click',e=>{if(e.target===statsZoom)closeStatsChartZoom()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&statsZoom.classList.contains('open'))closeStatsChartZoom()});
function render(d){
 document.getElementById('status').textContent=(d.status||'unknown')+' · '+(d.provider||'provider')+' · '+(d.assets||[]).filter(a=>a.status==='available').length+'/'+(d.assets||[]).length+' assets available · cache '+(d.cache_seconds||300)+'s';
 document.getElementById('stamp').textContent='Retrieved: '+(d.checked_at||'—')+' · '+(d.disclaimer||'');
 document.getElementById('assets').innerHTML=(d.assets||[]).map(a=>{
  const change=a.period_change_pct,changeText=change===null||change===undefined||!Number.isFinite(Number(change))?'—':`${Number(change)>0?'+':''}${fmt(change)}%`;
  return `<article class="kpi" data-asset="${esc(JSON.stringify(a))}" tabindex="0" role="button" aria-expanded="false" aria-label="${esc(a.name)}. Hover or focus for chart and Findings; activate to pin on touch screens."><h3><span aria-hidden="true">${assetIcon(a)}</span> ${esc(a.name)} <span class="muted">${esc(a.symbol)}</span></h3><div class="big">${a.status==='available'?fmt(a.price,0):'Unavailable'}</div><div class="muted">${a.status==='available'?`Period change: <span class="${periodClass(change)}">${changeText}</span> · Latest date: ${esc(a.last_date)}`:'History unavailable'}</div><div class="muted">SMA20 <span class="sma20">${fmt(a.sma20,0)}</span> · SMA50 <span class="sma50">${fmt(a.sma50,0)}</span></div><div class="muted metric-help-row"><span class="stat-tip volatility-tip" tabindex="0" data-tip="${esc(volatilityText(a.annualized_volatility_pct))}">Annualized volatility ${a.annualized_volatility_pct===null||a.annualized_volatility_pct===undefined?'—':fmt(a.annualized_volatility_pct)+'%'}</span><span class="stat-tip r2-tip" tabindex="0" data-tip="${esc(r2Text(a.in_sample_r2))}">R² (trendline fit) ${fmt(a.in_sample_r2,3)}</span></div>${inferenceBox(assetInference(a))}<div class="hint">Hover/focus to reveal · click card to collapse/reopen · click chart to enlarge</div><div class="hover-trend">${trendSvg(a)}</div></article>`;
 }).join('');
 document.querySelectorAll('#assets .kpi').forEach(card=>{
  card.addEventListener('click',e=>{
   if(e.target.closest('.stat-tip')||e.target.closest('.hover-trend')||e.target.closest('.chart-zoom-overlay'))return;
   const isClosed=card.classList.contains('trend-closed');
   card.classList.remove('trend-open','trend-closed');
   if(isClosed){card.classList.add('trend-open');card.setAttribute('aria-expanded','true')}
   else{card.classList.add('trend-closed');card.setAttribute('aria-expanded','false')}
  });
  card.addEventListener('keydown',e=>{if(e.target===card&&(e.key==='Enter'||e.key===' ')){e.preventDefault();card.click()}});
 });
 document.querySelectorAll('#assets .hover-trend svg').forEach(svg=>{const open=()=>{const card=svg.closest('.kpi');if(card)showChartZoom(card)};svg.setAttribute('aria-label',(svg.dataset.assetName||'Asset')+' trend chart. Click or press Enter to enlarge.');svg.style.cursor='zoom-in';svg.addEventListener('click',e=>{e.stopPropagation();open()});svg.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();e.stopPropagation();open()}})});
 let symbols=d.correlation_symbols||[];let rows=d.correlation||[];const compactCol=s=>['NASDAQ','USD/CAD'].includes(String(s).toUpperCase())?' compact-col':'';document.getElementById('corr').innerHTML=symbols.length?'<table><thead><tr><th>Asset</th>'+symbols.map(s=>'<th class="'+compactCol(s).trim()+'">'+esc(s)+'</th>').join('')+'</tr></thead><tbody>'+rows.map((r,ri)=>'<tr class="'+(ri>=Math.max(0,rows.length-4)?'corr-bottom-row':'')+'"><th class="asset-row-label">'+esc(r.symbol)+'</th>'+symbols.map(s=>{let v=r.values[s];let bg=v===null?'#8882':`rgba(${v<0?190:30},${v<0?70:140},${v<0?70:90},${Math.max(.12,Math.abs(v)*.75)})`;return '<td class="'+compactCol(s).trim()+'" style="background:'+bg+'"><span class="stat-tip corr-tip" tabindex="0" data-tip="'+esc(correlationText(v))+'">'+fmt(v,2)+'</span></td>'}).join('')+'</tr>').join('')+'</tbody></table>':'No sufficient histories to calculate correlations.';document.getElementById('forecast').innerHTML=(d.assets||[]).filter(a=>a.status==='available').map(a=>'<details><summary>'+esc(a.name)+' · OLS trend</summary><div class="tablewrap"><table><thead><tr><th>Horizon</th><th>Estimate</th><th>Lower descriptive band</th><th>Upper descriptive band</th></tr></thead><tbody>'+Object.entries(a.forecast||{}).map(([k,v])=>'<tr><td>'+esc(k.replace('_',' '))+'</td><td><span class="stat-tip" tabindex="0" data-tip="'+esc(forecastInference(a,v))+'">'+fmt(v.estimate,0)+'</span></td><td>'+fmt(v.lower,0)+'</td><td>'+fmt(v.upper,0)+'</td></tr>').join('')+'</tbody></table></div>'+'<p class="muted"><span class="stat-tip" tabindex="0" data-tip="'+esc(regressionInference(a))+' R² shows how closely the trendline fits historical prices; it does not measure forecast accuracy.">Daily slope: '+fmt(a.trend_slope_per_day,0)+' · R² (trendline fit): '+fmt(a.in_sample_r2,0)+' · Observations: '+fmt(a.observations,0)+' · Latest: '+esc(a.last_date)+'</span></p><p class="muted">Hover a forecast estimate for its short interpretation. Bands are descriptive, not calibrated prediction intervals.</p></details>').join('');if(d.errors&&d.errors.length)document.getElementById('status').textContent+=' · Provider issues: '+d.errors.join('; ')}
async function load(force=false){let b=document.getElementById('refresh');b.disabled=true;try{let r=await fetch('/api/statistical-analysis'+(force?'?force=1':''),{cache:'no-store'});let d=await r.json();render(d)}catch(e){document.getElementById('status').textContent='Analysis API unavailable. Check server and data-provider access.'}finally{b.disabled=false}}document.getElementById('refresh').addEventListener('click',()=>load(true));load();</script></body></html>'''


EXTRA_HTML = '<section class="panel" id="sector-pair-panel"><h2>US vs Canada — Sector Comparison</h2><div class="muted">Side-by-side proxy comparison. Returns use each ETF\'s own listed-market price and currency; they are not currency-normalized.</div><div class="tablewrap"><table id="sector-pair-table"><thead><tr><th>Sector</th><th>US proxy</th><th>US 1Y change</th><th>US annualized vol.</th><th>Canada proxy</th><th>Canada 1Y change</th><th>Canada annualized vol.</th></tr></thead><tbody id="sector-pair-body"><tr><td colspan="7">Loading sector data…</td></tr></tbody></table></div><p class="muted">XIU is retained for both Diversified Funds and Communication Services as supplied. It is a broad-market proxy, not a dedicated Canadian communication-services sector ETF.</p></section>'
JS_RENDERER = '\nconst SECTOR_PAIRS=[\n [\'Technology\',\'US:XLK\',\'CA:XIT\',\'XLK\',\'XIT\'],[\'Energy\',\'US:XLE\',\'CA:XEG\',\'XLE\',\'XEG\'],[\'Financials\',\'US:XLF\',\'CA:XFN\',\'XLF\',\'XFN\'],[\'Materials\',\'US:XLB\',\'CA:XMA\',\'XLB\',\'XMA\'],[\'Diversified Funds\',\'US:SPY\',\'CA:XIU\',\'SPY\',\'XIU\'],[\'Health Care\',\'US:XLV\',\'CA:XHC\',\'XLV\',\'XHC\'],[\'Consumer Discretionary\',\'US:XLY\',\'CA:XCD\',\'XLY\',\'XCD\'],[\'Communication Services\',\'US:XLC\',\'CA:XIU-COMM\',\'XLC\',\'XIU\'],[\'Utilities\',\'US:XLU\',\'CA:ZUT\',\'XLU\',\'ZUT\'],[\'Industrials\',\'US:XLI\',\'CA:ZIN\',\'XLI\',\'ZIN\'],[\'Consumer Staples\',\'US:XLP\',\'CA:XST\',\'XLP\',\'XST\']\n];\nfunction renderSectorPairs(d){const body=document.getElementById(\'sector-pair-body\');if(!body)return;const byId=new Map((d.assets||[]).map(a=>[a.symbol,a]));const pct=a=>a&&a.status===\'available\'&&Number.isFinite(Number(a.period_change_pct))?`<span class="${periodClass(a.period_change_pct)}">${Number(a.period_change_pct)>0?\'+\':\'\'}${fmt(a.period_change_pct)}%</span>`:\'—\';const vol=a=>a&&a.status===\'available\'&&Number.isFinite(Number(a.annualized_volatility_pct))?`${fmt(a.annualized_volatility_pct)}%`:\'—\';body.innerHTML=SECTOR_PAIRS.map(p=>{const u=byId.get(p[1]),c=byId.get(p[2]);return `<tr><th>${esc(p[0])}</th><td>${esc(p[3])}</td><td>${pct(u)}</td><td>${vol(u)}</td><td>${esc(p[4])}</td><td>${pct(c)}</td><td>${vol(c)}</td></tr>`}).join(\'\')}\n'


def _pndcc_sector_page():
    page = _pndcc_sector_page_base()
    page = page.replace('<title>PNDCC Statistical Analysis</title>', '<title>PNDCC Sector Analysis</title>')
    page = page.replace('<h1>Statistical Analysis</h1>', '<h1>Sector Analysis</h1>')
    page = page.replace('Historical relationships · Trend diagnostics · Experimental forecasts', 'US & Canadian sector ETF comparison · Trend diagnostics · Experimental forecasts')
    page = page.replace('Market snapshot & trend statistics', 'Sector ETF snapshot & trend statistics')
    page = page.replace('/api/statistical-analysis', '/api/sector-analysis')
    page = page.replace('href="/capital-markets">Capital Markets', 'href="/">Home')
    page = page.replace('<div id="stats-reveal" class="stats-reveal">', EXTRA_HTML + '<div id="stats-reveal" class="stats-reveal">')
    page = page.replace('function render(d){', 'function render(d){renderSectorPairs(d);')
    page = page.replace('const esc=s=>String(s??', JS_RENDERER + '\nconst esc=s=>String(s??')
    page = page.replace('<li><b>Historical market prices:</b>', '<li><b>Proxy definitions:</b> ETF construction, sector coverage, fees, listing currency and index methodology may differ between US and Canadian proxies. Reported returns are not currency-normalized.</li><li><b>Historical market prices:</b>')
    return page


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args): print("[sector-analysis]", fmt % args)
    def send_bytes(self,status,ctype,body):
        self.send_response(status); self.send_header("Content-Type",ctype); self.send_header("Cache-Control","no-store"); self.send_header("Content-Length",str(len(body))); self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        parsed=urlparse(self.path)
        if parsed.path in ("/", "/sector-analysis"):
            return self.send_bytes(200,"text/html; charset=utf-8",_pndcc_sector_page().encode("utf-8"))
        if parsed.path=="/api/sector-analysis":
            force=parse_qs(parsed.query).get("force",["0"])[0]=="1"
            try:
                body=json.dumps(_pndcc_sector_snapshot(force=force),ensure_ascii=False).encode("utf-8")
                return self.send_bytes(200,"application/json; charset=utf-8",body)
            except Exception as exc:
                body=json.dumps({"status":"error","message":type(exc).__name__,"assets":[],"correlation":[]}).encode("utf-8")
                return self.send_bytes(500,"application/json; charset=utf-8",body)
        return self.send_bytes(404,"text/plain; charset=utf-8",b"Not found")

if __name__=="__main__":
    server=ThreadingHTTPServer(("127.0.0.1",8799),Handler)
    print("ISOLATION: sector-analysis R2 candidate only; PNDCC master is not imported or started")
    print("URL: http://127.0.0.1:8799/sector-analysis")
    print("Data source: Yahoo Finance chart endpoint; live requests require internet access")
    try: server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt: print("\nSector Analysis test server stopped")
    finally: server.server_close()
