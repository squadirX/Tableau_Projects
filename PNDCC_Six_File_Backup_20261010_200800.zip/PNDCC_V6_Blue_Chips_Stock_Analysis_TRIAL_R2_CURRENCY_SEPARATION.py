#!/usr/bin/env python3
"""PNDCC Blue Chips Stock Analysis R1 — isolated trial candidate.

Does not import or start the PNDCC master. Uses Canadian-listed provider symbols only
(.TO TSX, .V TSXV, .NE Cboe Canada, .CN Canadian Securities Exchange). It deliberately
never falls back to a US-listed ticker without an exchange suffix. Provider coverage is
verified at runtime; unsupported instruments remain unresolved rather than being guessed.
"""
import json, math, time, urllib.parse, urllib.request, urllib.error, http.cookiejar, threading
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

HOST, PORT = "127.0.0.1", 8800
CACHE_SECONDS = 300
LOCK = threading.Lock()
_CACHE = {"at": 0, "data": None}
_SESSION_LOCK = threading.Lock()
_SESSION = {"opener": None, "crumb": None, "at": 0}

# Original supplied list, excluding XNDU, APTX and BRK as requested.
# Industry labels are retained from the user's sheet. Symbols are starting search keys,
# not a claim that each original symbol is itself a TSX/TSXV symbol.
STOCKS = [
("AAPL","Apple Inc.","Computers, Phones & Household Electronics"),
("AMD","Advanced Micro Devices, Inc.","Semiconductors & Semiconductor Equipment"),
("META","Meta Platforms, Inc.","Software & IT Services"),
("MSFT","Microsoft Corporation","Software & IT Services"),
("NVDA","NVIDIA Corporation","Semiconductors & Semiconductor Equipment"),
("TSLA","Tesla, Inc.","Automobiles & Auto Parts"),
("IBM","International Business Machines Corporation","Software & IT Services"),
("GOOG","Alphabet Inc.","Software & IT Services"),
("AMZN","Amazon.com, Inc.","Diversified Retail"),
("INTC","Intel Corporation","Semiconductors & Semiconductor Equipment"),
("PFE","Pfizer Inc.","Pharmaceuticals"),
("LLY","Eli Lilly and Company","Pharmaceuticals"),
("MU","Micron Technology, Inc.","Semiconductors & Semiconductor Equipment"),
("ASML","ASML Holding N.V.","Semiconductors & Semiconductor Equipment"),
("AVGO","Broadcom Inc.","Semiconductors & Semiconductor Equipment"),
("SMCI","Super Micro Computer, Inc.","Computers, Phones & Household Electronics"),
("QCOM","Qualcomm Incorporated","Semiconductors & Semiconductor Equipment"),
("AMAT","Applied Materials, Inc.","Semiconductors & Semiconductor Equipment"),
("TXN","Texas Instruments Incorporated","Semiconductors & Semiconductor Equipment"),
("LRCX","Lam Research Corporation","Semiconductors & Semiconductor Equipment"),
("ANET","Arista Networks, Inc.","Communications & Networking"),
("MRV","Marvell Technology, Inc.","Semiconductors & Semiconductor Equipment"),
("VRT","Vertiv Holdings Co.","Machinery, Equipment & Components"),
("LMT","Lockheed Martin Corporation","Aerospace & Defense"),
("KLAC","KLA Corporation","Semiconductors & Semiconductor Equipment"),
("PNG","Kraken Robotics Inc.","Aerospace & Defense"),
("MDA","MDA Space Ltd.","Aerospace & Defense"),
("JNJ","Johnson & Johnson","Pharmaceuticals"),
("BA","The Boeing Company","Aerospace & Defense"),
("CRWD","CrowdStrike Holdings, Inc.","Software & IT Services"),
("WDC","Western Digital Corporation","Computers, Phones & Household Electronics"),
("SPCX","SpaceX CDR / Canadian-listed instrument","Telecommunications Services"),
("ABBV","AbbVie Inc.","Pharmaceuticals"),
("GE","GE Aerospace","Aerospace & Defense"),
("BB","BlackBerry Limited","Software & IT Services"),
("NVS","Novartis AG","Pharmaceuticals"),
("MRK","Merck & Co., Inc.","Pharmaceuticals"),
("SNDK","SanDisk Corporation","Computers, Phones & Household Electronics"),
("NOVO","Novo Nordisk A/S","Pharmaceuticals"),
]

SUFFIXES = [".TO", ".V", ".NE", ".CN"]

# Price/technical data always uses the verified Canadian listing. For US issuers,
# fundamentals are fetched separately from the issuer's primary US ticker so the
# financial statements and EPS are not confused with the Canadian trading currency.
# These are fundamentals-only source symbols; they never replace Canadian price data.
US_FUNDAMENTALS_SYMBOLS = {
    "AAPL", "AMD", "META", "MSFT", "NVDA", "TSLA", "IBM", "GOOG", "AMZN",
    "INTC", "PFE", "LLY", "MU", "AVGO", "SMCI", "QCOM", "AMAT", "TXN",
    "LRCX", "ANET", "MRV", "VRT", "LMT", "KLAC", "JNJ", "BA", "CRWD",
    "WDC", "ABBV", "GE", "BB", "SNDK"
}
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X) AppleWebKit/537.36 PNDCC-BlueChips/1.0"

def _get(url, timeout=10, opener=None, headers=None):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json, text/plain, */*", **(headers or {})})
    op = opener or urllib.request.build_opener()
    with op.open(req, timeout=timeout) as r:
        raw = r.read(4 * 1024 * 1024 + 1)
    if len(raw) > 4 * 1024 * 1024:
        raise ValueError("Provider response exceeded size limit")
    return json.loads(raw.decode("utf-8"))

def _yahoo_session(force=False):
    with _SESSION_LOCK:
        if not force and _SESSION["opener"] and time.time() - _SESSION["at"] < 1800:
            return _SESSION["opener"], _SESSION["crumb"]
        jar = http.cookiejar.CookieJar()
        opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
        try:
            req = urllib.request.Request("https://fc.yahoo.com/", headers={"User-Agent": UA})
            try:
                opener.open(req, timeout=8).read(1024)
            except Exception:
                pass
            crumb_req = urllib.request.Request("https://query1.finance.yahoo.com/v1/test/getcrumb", headers={"User-Agent": UA})
            with opener.open(crumb_req, timeout=8) as resp:
                crumb = resp.read(256).decode("utf-8", "replace").strip()
            if not crumb or "{" in crumb or len(crumb) > 100:
                crumb = None
        except Exception:
            crumb = None
        _SESSION.update(opener=opener, crumb=crumb, at=time.time())
        return opener, crumb

def _chart(ticker):
    url = "https://query1.finance.yahoo.com/v8/finance/chart/" + urllib.parse.quote(ticker, safe=".-^=") + "?range=1y&interval=1d&events=div%2Csplits"
    data = _get(url, timeout=12)
    root = data.get("chart") or {}
    if root.get("error") or not root.get("result"):
        raise ValueError((root.get("error") or {}).get("description") or "No price history returned")
    item = root["result"][0]
    stamps = item.get("timestamp") or []
    quote = ((item.get("indicators") or {}).get("quote") or [{}])[0]
    adj = ((item.get("indicators") or {}).get("adjclose") or [{}])
    adj_values = (adj[0].get("adjclose") or []) if adj else []
    closes = quote.get("close") or []
    volumes = quote.get("volume") or []
    bars = []
    for i, (stamp, close) in enumerate(zip(stamps, closes)):
        try:
            if close is None or not math.isfinite(float(close)) or float(close) <= 0: continue
            dt = datetime.fromtimestamp(int(stamp)).date().isoformat()
            adjusted = adj_values[i] if i < len(adj_values) else None
            bars.append({"date":dt,"close":float(close),"adjclose":float(adjusted) if adjusted is not None else float(close),"volume":int(volumes[i]) if i < len(volumes) and volumes[i] is not None else None})
        except Exception: continue
    if len(bars) < 20: raise ValueError("Fewer than 20 daily price observations")
    meta = item.get("meta") or {}
    exchange = str(meta.get("fullExchangeName") or meta.get("exchangeName") or "")
    currency = str(meta.get("currency") or "")
    # Accept only recognized Canadian listings; never silently use a bare US ticker.
    suffix = ticker.rsplit(".", 1)[-1] if "." in ticker else ""
    expected = {"TO":"Toronto Stock Exchange", "V":"TSX Venture Exchange", "NE":"Cboe Canada", "CN":"Canadian Securities Exchange"}
    if suffix not in expected:
        raise ValueError("Ticker is not a Canadian exchange-suffixed symbol")
    return {"bars":bars,"meta":{"symbol":meta.get("symbol",ticker),"exchange":exchange or expected[suffix],"currency":currency or ("CAD" if suffix in expected else ""),"exchange_suffix":suffix,"regularMarketPrice":meta.get("regularMarketPrice"),"fiftyTwoWeekHigh":meta.get("fiftyTwoWeekHigh"),"fiftyTwoWeekLow":meta.get("fiftyTwoWeekLow")}}

def _resolve(stock):
    base = stock[0]
    errors=[]
    for suffix in SUFFIXES:
        candidate=base+suffix
        try:
            payload=_chart(candidate)
            meta=payload["meta"]
            # Guard against provider aliasing to a different symbol.
            provider_symbol=str(meta.get("symbol") or "").upper()
            if provider_symbol and provider_symbol != candidate.upper():
                errors.append(candidate+": provider symbol mismatch ("+provider_symbol+")")
                continue
            return candidate,payload,None
        except Exception as e:
            errors.append(candidate+": "+str(e)[:100])
    return None,None,"No verified Canadian listing found. Checked "+", ".join(errors)

def _moving(values,n):
    if len(values)<n:return None
    return sum(values[-n:])/n

def _stats(bars):
    closes=[b["adjclose"] for b in bars]
    returns=[closes[i]/closes[i-1]-1 for i in range(1,len(closes)) if closes[i-1]>0]
    avg=sum(returns)/len(returns) if returns else 0
    vol=(sum((x-avg)**2 for x in returns)/(len(returns)-1))**.5*math.sqrt(252)*100 if len(returns)>1 else None
    peak=closes[0]; maxdd=0
    for v in closes:
        peak=max(peak,v)
        if peak>0:maxdd=min(maxdd,(v/peak-1)*100)
    def change(days):
        if len(closes)<=days:return None
        return (closes[-1]/closes[-days-1]-1)*100
    return {"price":bars[-1]["close"],"adjusted_price":closes[-1],"last_date":bars[-1]["date"],"change_1d_pct":change(1),"change_1m_pct":change(21),"change_3m_pct":change(63),"change_6m_pct":change(126),"change_1y_pct":(closes[-1]/closes[0]-1)*100,"sma20":_moving(closes,20),"sma50":_moving(closes,50),"annualized_volatility_pct":vol,"max_drawdown_pct":maxdd,"observations":len(bars),"volume_latest":bars[-1].get("volume"),"fifty_two_week_high":max(b["close"] for b in bars),"fifty_two_week_low":min(b["close"] for b in bars)}

def _fundamentals(ticker, source_ticker=None):
    source_ticker = source_ticker or ticker
    # Yahoo quoteSummary requires a valid session/crumb in many regions. Return explicit
    # availability/error status rather than fabricating or substituting fundamentals.
    modules="price,summaryDetail,defaultKeyStatistics,financialData,incomeStatementHistory,balanceSheetHistory,cashflowStatementHistory,calendarEvents"
    opener,crumb=_yahoo_session()
    if not crumb:
        return {"status":"unavailable","reason":"Yahoo fundamentals session/crumb unavailable; price history may still work."}
    url="https://query1.finance.yahoo.com/v10/finance/quoteSummary/"+urllib.parse.quote(source_ticker,safe=".-")+"?modules="+urllib.parse.quote(modules)+"&crumb="+urllib.parse.quote(crumb,safe="")
    try:
        data=_get(url,timeout=12,opener=opener)
        root=data.get("quoteSummary") or {}
        if root.get("error") or not root.get("result"):
            return {"status":"unavailable","reason":str((root.get("error") or {}).get("description") or "No fundamentals returned")[:180]}
        x=root["result"][0]
        def raw(obj,key):
            v=(obj or {}).get(key)
            if isinstance(v,dict): return v.get("raw")
            return v
        price=x.get("price") or {}; detail=x.get("summaryDetail") or {}; keys=x.get("defaultKeyStatistics") or {}; fin=x.get("financialData") or {}
        inc=((x.get("incomeStatementHistory") or {}).get("incomeStatementHistory") or [])
        bal=((x.get("balanceSheetHistory") or {}).get("balanceSheetStatements") or [])
        cf=((x.get("cashflowStatementHistory") or {}).get("cashflowStatements") or [])
        def statement_value(rows,key):
            if not rows:return None
            return raw(rows[0],key)
        rev=statement_value(inc,"totalRevenue"); prevrev=statement_value(inc[1:],"totalRevenue") if len(inc)>1 else None
        earnings=statement_value(inc,"netIncome"); prevearn=statement_value(inc[1:],"netIncome") if len(inc)>1 else None
        cash=statement_value(cf,"totalCashFromOperatingActivities"); capex=statement_value(cf,"capitalExpenditures")
        debt=raw(fin,"totalDebt"); cash_balance=raw(fin,"totalCash")
        fcf=raw(fin,"freeCashflow")
        if fcf is None and cash is not None and capex is not None: fcf=cash+capex # Yahoo usually reports capex as negative.
        def growth(cur,prev): return ((cur/prev)-1)*100 if isinstance(cur,(int,float)) and isinstance(prev,(int,float)) and prev else None
        out={"status":"available","company_name":raw(price,"longName") or raw(price,"shortName"),"currency":raw(price,"currency"),"market_cap":raw(price,"marketCap"),"trailing_pe":raw(detail,"trailingPE"),"forward_pe":raw(detail,"forwardPE"),"price_to_book":raw(keys,"priceToBook"),"eps_ttm":raw(keys,"trailingEps"),"eps_forward":raw(keys,"forwardEps"),"dividend_yield_pct":(raw(detail,"dividendYield")*100 if isinstance(raw(detail,"dividendYield"),(int,float)) else None),"payout_ratio_pct":(raw(detail,"payoutRatio")*100 if isinstance(raw(detail,"payoutRatio"),(int,float)) else None),"revenue_latest":rev,"revenue_growth_pct":growth(rev,prevrev),"net_income_latest":earnings,"net_income_growth_pct":growth(earnings,prevearn),"profit_margin_pct":(raw(fin,"profitMargins")*100 if isinstance(raw(fin,"profitMargins"),(int,float)) else None),"operating_margin_pct":(raw(fin,"operatingMargins")*100 if isinstance(raw(fin,"operatingMargins"),(int,float)) else None),"free_cash_flow":fcf,"total_debt":debt,"total_cash":cash_balance,"debt_to_equity":raw(fin,"debtToEquity"),"return_on_equity_pct":(raw(fin,"returnOnEquity")*100 if isinstance(raw(fin,"returnOnEquity"),(int,float)) else None),"source_symbol":source_ticker,"source":"Yahoo Finance quoteSummary; issuer fundamentals source is separate from Canadian listing price data; reporting periods/definitions may differ by issuer"}
        return out
    except Exception as e:
        # Refresh session once for common crumb/session failures.
        if "401" in str(e) or "403" in str(e):
            try:
                opener,crumb=_yahoo_session(force=True)
                if crumb:
                    url="https://query1.finance.yahoo.com/v10/finance/quoteSummary/"+urllib.parse.quote(source_ticker,safe=".-")+"?modules="+urllib.parse.quote(modules)+"&crumb="+urllib.parse.quote(crumb,safe="")
                    data=_get(url,timeout=10,opener=opener)
                    root=(data.get("quoteSummary") or {}).get("result") or []
                    if root: return {"status":"unavailable","reason":"Fundamentals endpoint responded after session refresh; parser retry required."}
            except Exception: pass
        return {"status":"unavailable","reason":"Fundamentals request failed: "+str(e)[:150]}

def _load_all(force=False):
    with LOCK:
        if not force and _CACHE["data"] and time.time()-_CACHE["at"]<CACHE_SECONDS:
            return _CACHE["data"]
    assets=[]
    # Deliberately serial requests to reduce provider throttling and keep startup responsive.
    for symbol,name,industry in STOCKS:
        a={"symbol":symbol,"name":name,"industry":industry,"status":"unresolved","provider_symbol":None,"listing_exchange":None,"currency":None,"price_data":None,"fundamentals":{"status":"unavailable","reason":"Not requested until a Canadian listing is verified."},"errors":[]}
        resolved,history,error=_resolve((symbol,name,industry))
        if resolved:
            a["provider_symbol"]=resolved
            a["listing_exchange"]=history["meta"].get("exchange")
            a["currency"]=history["meta"].get("currency")
            a["status"]="available"
            a["price_data"]={**_stats(history["bars"]),"bars":history["bars"]}
            fundamentals_source = symbol if symbol in US_FUNDAMENTALS_SYMBOLS else resolved
            a["fundamentals"]=_fundamentals(resolved, fundamentals_source)
        else:
            a["errors"].append(error)
        assets.append(a)
    available=sum(1 for a in assets if a["status"]=="available")
    fundamentals=sum(1 for a in assets if a["fundamentals"].get("status")=="available")
    data={"assets":assets,"summary":{"requested":len(assets),"price_available":available,"price_unavailable":len(assets)-available,"fundamentals_available":fundamentals,"retrieved_at":datetime.now().astimezone().isoformat(timespec="seconds"),"cache_seconds":CACHE_SECONDS},"notes":["Only verified Canadian exchange-suffixed symbols are used; there is no silent US ticker fallback.","Yahoo Finance data may be incomplete, delayed, unavailable or subject to provider changes.","Fundamental metrics can use different reporting periods and definitions; inspect source/period before comparing.","This analytical tool is educational, not investment advice."]}
    with LOCK: _CACHE.update(at=time.time(),data=data)
    return data

HTML = r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>PNDCC · Blue Chips Stock Analysis</title><style>
:root{color-scheme:light dark;--panel:color-mix(in srgb,Canvas 94%,#718096 6%);--line:color-mix(in srgb,CanvasText 18%,transparent);--muted:color-mix(in srgb,CanvasText 68%,transparent);--accent:#2563eb}*{box-sizing:border-box}body{font:14px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;margin:0;padding:20px;max-width:1500px;margin-inline:auto;background:Canvas;color:CanvasText}header{display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap;margin-bottom:20px}h1{font-size:28px;margin:4px 0}h2{font-size:19px;margin:0 0 12px}h3{font-size:16px;margin:0 0 8px}.muted{color:var(--muted)}button,select,input{font:inherit;padding:8px 11px;border:1px solid var(--line);border-radius:8px;background:Canvas;color:CanvasText}button{cursor:pointer}.panel{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:16px;margin-bottom:16px}.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}.kpi{padding:14px;border:1px solid var(--line);border-radius:10px}.kpi strong{font-size:24px;display:block}.tools{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px}.tablewrap{overflow:auto;max-height:65vh}table{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums}th,td{padding:9px 10px;border-bottom:1px solid var(--line);text-align:right;white-space:nowrap}th:first-child,td:first-child{text-align:left}thead{position:sticky;top:0;background:Canvas;z-index:1}tr[data-id]{cursor:pointer}tr[data-id]:hover{background:color-mix(in srgb,var(--accent) 9%,transparent)}.positive{color:#16a34a}.negative{color:#dc2626}.badge{display:inline-block;border:1px solid var(--line);border-radius:99px;padding:2px 8px;font-size:12px}.details{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.metric{border:1px solid var(--line);border-radius:10px;padding:10px;min-width:0}.metric .label{font-size:12px;color:var(--muted)}.metric .value{font-size:17px;font-weight:650;overflow-wrap:anywhere}.chart{width:100%;height:auto;display:block;min-height:170px}.twocol{display:grid;grid-template-columns:1.3fr 1fr;gap:16px}.warn{border-left:3px solid #d97706;padding:8px 10px;background:color-mix(in srgb,#d97706 9%,transparent);margin:8px 0}.small{font-size:12px}.hidden{display:none}@media(max-width:850px){.grid{grid-template-columns:repeat(2,minmax(0,1fr))}.twocol{grid-template-columns:1fr}.details{grid-template-columns:repeat(2,minmax(0,1fr))}body{padding:12px}}@media(max-width:480px){.details{grid-template-columns:1fr}.grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
</style></head><body><header><div><div class="muted">PNDCC · CAPITAL MARKETS · ISOLATED TRIAL</div><h1>Blue Chips Stock Analysis</h1><div class="muted">Canadian-listed instrument verification · Technicals · Fundamentals</div></div><div><button id="refresh">Refresh data</button></div></header>
<div class="warn"><strong>Listing verification is strict:</strong> the app tests Canadian exchange-suffixed symbols only (.TO, .V, .NE, .CN). It will not silently substitute a US listing. Buying through a Canadian brokerage does not itself establish the exchange where an instrument trades.</div>
<section class="panel"><h2>Coverage overview</h2><div class="grid"><div class="kpi"><span class="muted">Requested instruments</span><strong id="requested">39</strong></div><div class="kpi"><span class="muted">Canadian price histories verified</span><strong id="priceok">—</strong></div><div class="kpi"><span class="muted">Price data unresolved</span><strong id="pricebad">—</strong></div><div class="kpi"><span class="muted">Fundamentals available</span><strong id="fundok">—</strong></div></div><p id="stamp" class="muted small">Loading coverage report…</p></section>
<section class="panel"><h2>Blue Chips universe</h2><div class="tools"><input id="search" placeholder="Search symbol, company or industry…" aria-label="Search stocks"><select id="statusFilter"><option value="all">All statuses</option><option value="available">Canadian listing verified</option><option value="unresolved">Unresolved</option></select><select id="industryFilter"><option value="all">All industries</option></select><button id="export">Export coverage CSV</button></div><div class="tablewrap"><table><thead><tr><th>Symbol</th><th>Company</th><th>Industry</th><th>Provider symbol</th><th>Exchange</th><th>Currency</th><th>Latest price</th><th>1Y return</th><th>Volatility</th><th>Fundamentals</th><th>Status</th></tr></thead><tbody id="rows"><tr><td colspan="11">Loading…</td></tr></tbody></table></div><p class="muted small">Select a row to inspect its technical and fundamental metrics. Returns use adjusted historical close where available; latest quote is provider-reported.</p></section>
<section class="panel" id="detail"><h2>Stock detail</h2><p class="muted">Choose a verified stock above. Fundamentals are shown only when the provider returns usable values.</p></section>
<section class="panel"><h2>Methodology & limitations</h2><ul id="notes"></ul><p class="muted small">Historical volatility is annualized from daily adjusted-close returns using 252 trading days. Maximum drawdown is calculated from the available one-year adjusted-price series. SMA20/SMA50 use adjusted closes. Fundamental values are provider-reported and may reflect different fiscal periods.</p></section>
<script>
let DATA=null;const $=id=>document.getElementById(id);const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));const num=(v,d=2)=>v===null||v===undefined||!Number.isFinite(Number(v))?'—':Number(v).toLocaleString(undefined,{maximumFractionDigits:d});const money=(v,c='CAD')=>v===null||v===undefined?'—':(c==='CAD'?'CA$':c==='USD'?'US$':c+' ')+num(v,2);const pct=v=>v===null||v===undefined?'—':(v>0?'+':'')+num(v,2)+'%';const sign=v=>v>0?'positive':v<0?'negative':'';function fmtLarge(v,c=''){if(v===null||v===undefined)return '—';let n=Number(v);if(!Number.isFinite(n))return '—';let a=Math.abs(n),body=(a>=1e12?(a/1e12).toFixed(2)+'T':a>=1e9?(a/1e9).toFixed(2)+'B':a>=1e6?(a/1e6).toFixed(2)+'M':a>=1e3?(a/1e3).toFixed(2)+'K':num(n,2));let prefix=c==='USD'?'US$':c==='CAD'?'CA$':c==='EUR'?'€':c==='CHF'?'CHF ':c==='DKK'?'DKK ':'';return (n<0?'-':'')+prefix+body}
async function load(force=false){$('rows').innerHTML='<tr><td colspan="11">Loading and verifying Canadian listings… this can take a little while.</td></tr>';$('stamp').textContent='Requesting provider coverage report…';try{let r=await fetch('/api/stock-analysis'+(force?'?refresh=1':''));let d=await r.json();if(!r.ok)throw Error(d.error||'Request failed');DATA=d;render();}catch(e){$('rows').innerHTML='<tr><td colspan="11">Load failed: '+esc(e.message)+'</td></tr>';$('stamp').textContent='Check that the isolated Python server is still running.'}}
function render(){let s=DATA.summary;$('requested').textContent=s.requested;$('priceok').textContent=s.price_available;$('pricebad').textContent=s.price_unavailable;$('fundok').textContent=s.fundamentals_available;$('stamp').textContent='Retrieved: '+s.retrieved_at+' · Cache '+s.cache_seconds+' seconds · Provider data can be delayed or incomplete';$('notes').innerHTML=DATA.notes.map(x=>'<li>'+esc(x)+'</li>').join('');let inds=[...new Set(DATA.assets.map(a=>a.industry))].sort();$('industryFilter').innerHTML='<option value="all">All industries</option>'+inds.map(x=>'<option>'+esc(x)+'</option>').join('');renderRows();}
function renderRows(){let q=$('search').value.toLowerCase(),st=$('statusFilter').value,ind=$('industryFilter').value;let list=DATA.assets.filter(a=>(st==='all'||(st==='available'?a.status==='available':a.status!=='available'))&&(ind==='all'||a.industry===ind)&&[a.symbol,a.name,a.industry,a.provider_symbol||'',a.listing_exchange||''].join(' ').toLowerCase().includes(q));$('rows').innerHTML=list.map(a=>{let p=a.price_data||{},f=a.fundamentals||{};return `<tr data-id="${esc(a.symbol)}"><td><strong>${esc(a.symbol)}</strong></td><td>${esc(a.name)}</td><td>${esc(a.industry)}</td><td>${esc(a.provider_symbol||'—')}</td><td>${esc(a.listing_exchange||'—')}</td><td>${esc(a.currency||'—')}</td><td>${a.status==='available'?money(p.price,a.currency):'—'}</td><td class="${sign(p.change_1y_pct)}">${a.status==='available'?pct(p.change_1y_pct):'—'}</td><td>${a.status==='available'?pct(p.annualized_volatility_pct):'—'}</td><td>${esc(f.status==='available'?'Available':'Unavailable')}</td><td><span class="badge">${esc(a.status==='available'?'Verified':'Unresolved')}</span></td></tr>`}).join('')||'<tr><td colspan="11">No matches.</td></tr>';document.querySelectorAll('tr[data-id]').forEach(tr=>tr.addEventListener('click',()=>showDetail(tr.dataset.id)));}
function metric(label,value){return `<div class="metric"><div class="label">${esc(label)}</div><div class="value">${esc(value)}</div></div>`}
function chartSvg(bars){if(!bars||bars.length<2)return '<p class="muted">No price chart available.</p>';let w=900,h=250,p=28,vals=bars.map(b=>b.adjclose),lo=Math.min(...vals),hi=Math.max(...vals);if(hi===lo)hi=lo+1;let points=vals.map((v,i)=>`${p+i*(w-2*p)/(vals.length-1)},${h-p-(v-lo)*(h-2*p)/(hi-lo)}`).join(' ');return `<svg class="chart" viewBox="0 0 ${w} ${h}" role="img" aria-label="One-year adjusted close chart"><line x1="${p}" y1="${h-p}" x2="${w-p}" y2="${h-p}" stroke="currentColor" opacity=".25"/><polyline points="${points}" fill="none" stroke="#2563eb" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round"/><text x="${p}" y="16" font-size="12" fill="currentColor">${esc(num(hi,2))}</text><text x="${p}" y="${h-4}" font-size="12" fill="currentColor">${esc(num(lo,2))}</text><text x="${p}" y="${h-4}" font-size="12" fill="currentColor">${esc(bars[0].date)}</text><text x="${w-p}" y="${h-4}" text-anchor="end" font-size="12" fill="currentColor">${esc(bars[bars.length-1].date)}</text></svg>`}
function showDetail(sym){let a=DATA.assets.find(x=>x.symbol===sym);if(!a)return;let p=a.price_data||{},f=a.fundamentals||{};let pmetrics=a.status==='available'?[metric('Latest price',money(p.price,a.currency)),metric('1 day',pct(p.change_1d_pct)),metric('1 month',pct(p.change_1m_pct)),metric('3 months',pct(p.change_3m_pct)),metric('6 months',pct(p.change_6m_pct)),metric('1 year',pct(p.change_1y_pct)),metric('SMA20',money(p.sma20,a.currency)),metric('SMA50',money(p.sma50,a.currency)),metric('Annualized volatility',pct(p.annualized_volatility_pct)),metric('Maximum drawdown',pct(p.max_drawdown_pct)),metric('52-week high',money(p.fifty_two_week_high,a.currency)),metric('52-week low',money(p.fifty_two_week_low,a.currency)),metric('Latest volume',num(p.volume_latest,0)),metric('Observations',num(p.observations,0))].join(''):'<div class="warn">No verified Canadian price history. '+esc((a.errors||[]).join(' '))+'</div>';let fc=f.currency||'Currency unverified';let fmetrics=f.status==='available'?[metric('Market cap ('+fc+')',fmtLarge(f.market_cap,fc)),metric('Trailing P/E',num(f.trailing_pe)),metric('Forward P/E',num(f.forward_pe)),metric('Price/book',num(f.price_to_book)),metric('EPS (TTM, '+fc+')',money(f.eps_ttm,fc)),metric('Forward EPS ('+fc+')',money(f.eps_forward,fc)),metric('Revenue ('+fc+')',fmtLarge(f.revenue_latest,fc)),metric('Revenue growth',pct(f.revenue_growth_pct)),metric('Net income ('+fc+')',fmtLarge(f.net_income_latest,fc)),metric('Net income growth',pct(f.net_income_growth_pct)),metric('Profit margin',pct(f.profit_margin_pct)),metric('Operating margin',pct(f.operating_margin_pct)),metric('Free cash flow ('+fc+')',fmtLarge(f.free_cash_flow,fc)),metric('Total debt ('+fc+')',fmtLarge(f.total_debt,fc)),metric('Cash ('+fc+')',fmtLarge(f.total_cash,fc)),metric('Debt/equity',num(f.debt_to_equity)),metric('Return on equity',pct(f.return_on_equity_pct)),metric('Dividend yield',pct(f.dividend_yield_pct)),metric('Payout ratio',pct(f.payout_ratio_pct))].join(''):`<div class="warn"><strong>Fundamentals unavailable.</strong> ${esc(f.reason||'Provider did not return the required metrics.')}</div>`;$('detail').innerHTML=`<h2>${esc(a.name)} <span class="muted">(${esc(a.symbol)})</span></h2><p class="muted">${esc(a.industry)} · Provider: ${esc(a.provider_symbol||'unresolved')} · Exchange: ${esc(a.listing_exchange||'unverified')} · Currency: ${esc(a.currency||'—')}</p><div class="twocol"><div><h3>Technical analysis</h3><div class="details">${pmetrics}</div></div><div><h3>Fundamental analysis</h3><div class="details">${fmetrics}</div><p class="muted small">Fundamentals use the issuer source symbol shown in the source metadata, separate from Canadian-listing technical prices. Currency is taken from that fundamentals response; verify it and the reporting period before comparing issuers.</p></div></div><h3 style="margin-top:18px">One-year adjusted price history</h3>${chartSvg(p.bars)}<p class="muted small">Latest daily observation: ${esc(p.last_date||'—')}. Trend indicators describe historical data and are not forecasts.</p>`;$('detail').scrollIntoView({behavior:'smooth',block:'start'});}
$('search').addEventListener('input',renderRows);$('statusFilter').addEventListener('change',renderRows);$('industryFilter').addEventListener('change',renderRows);$('refresh').addEventListener('click',()=>load(true));$('export').addEventListener('click',()=>{if(!DATA)return;let cols=['symbol','name','industry','provider_symbol','listing_exchange','currency','status','latest_price','return_1y_pct','volatility_pct','fundamentals_status','reason'];let rows=DATA.assets.map(a=>[a.symbol,a.name,a.industry,a.provider_symbol||'',a.listing_exchange||'',a.currency||'',a.status,a.price_data?.price??'',a.price_data?.change_1y_pct??'',a.price_data?.annualized_volatility_pct??'',a.fundamentals?.status||'',(a.errors||[]).join(' ')]);let csv=[cols,...rows].map(r=>r.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\r\n');let u=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));let x=document.createElement('a');x.href=u;x.download='PNDCC_Blue_Chips_Coverage.csv';x.click();URL.revokeObjectURL(u)});load();
</script></body></html>'''

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args): print("[blue-chips] " + (fmt % args))
    def send_body(self, code, ctype, body):
        raw=body.encode("utf-8") if isinstance(body,str) else body
        self.send_response(code); self.send_header("Content-Type",ctype); self.send_header("Content-Length",str(len(raw))); self.send_header("Cache-Control","no-store"); self.end_headers(); self.wfile.write(raw)
    def do_GET(self):
        path=urlparse(self.path).path
        if path in ("/","/stock-analysis"):
            self.send_body(200,"text/html; charset=utf-8",HTML); return
        if path=="/api/stock-analysis":
            try:
                force=parse_qs(urlparse(self.path).query).get("refresh",["0"])[0]=="1"
                self.send_body(200,"application/json; charset=utf-8",json.dumps(_load_all(force),ensure_ascii=False,separators=(",",":")))
            except Exception as e:
                self.send_body(500,"application/json; charset=utf-8",json.dumps({"error":str(e)[:250]}))
            return
        self.send_body(404,"text/plain; charset=utf-8","Not found")

def main():
    print("ISOLATION: Blue Chips Stock Analysis R2 currency-separation trial only; PNDCC master is not imported or started")
    print(f"URL: http://{HOST}:{PORT}/stock-analysis")
    print("Universe: 39 requested instruments; excludes XNDU, APTX and BRK")
    print("Provider: Yahoo Finance chart and quoteSummary endpoints; internet required")
    print("Note: first coverage refresh may take several minutes due to per-symbol exchange verification.")
    server=ThreadingHTTPServer((HOST,PORT),Handler)
    try: server.serve_forever(poll_interval=.4)
    except KeyboardInterrupt: print("\nBlue Chips trial server stopped")
    finally: server.server_close()
if __name__=="__main__": main()
