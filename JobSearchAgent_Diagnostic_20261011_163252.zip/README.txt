# JobSearchAgent diagnostic archive

This archive was generated locally from your JobSearchAgent folder for code/data-integrity auditing. Keep it private: `data/jobs.csv` can contain job URLs and personal search history. Review the archive before uploading or sharing.

## What is included
- Main Python script and matching Python copies/backups found at project root
- `data/jobs.csv` plus a field-count/source audit in `AUDIT_MANIFEST.json`
- Run history and a redacted tail of the app log
- Scoring-only sanitized candidate-profile fields
- Config key/type structure only; config values are not included

## Deliberately excluded
- `.env`, app passwords, tokens, Keychain data, and actual config values
- Unrelated documents/spreadsheets and Python caches

## Next step
Send this ZIP in the conversation or upload it to a **private** GitHub repository. Do not commit it to a public repository. The log redaction catches common patterns but is not perfect, so inspect contents first.
