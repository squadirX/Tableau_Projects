from pathlib import Path

code = '''#!/usr/bin/env python3
"""
JobSearchAgent - Phase 1

Reads Indeed/LinkedIn job-alert emails from Yahoo Mail, extracts
job information from the email itself, filters against
candidate_profile.json, removes duplicates, and writes jobs.csv.

This phase deliberately does NOT fetch LinkedIn/Indeed pages and
does NOT submit applications.
"""

import argparse
import csv
import email
import html
import imaplib
import json
import os
import re
import ssl
from datetime import datetime, timedelta
from email.header import decode_header

BASE_DIR = os.path.expanduser("~/JobSearchAgent")
DATA_DIR = os.path.join(BASE_DIR, "data")
LOG_DIR = os.path.join(BASE_DIR, "logs")
CONFIG_FILE = os.path.join(BASE_DIR, "config.json")
PROFILE_FILE = os.path.join(BASE_DIR, "candidate_profile.json")
JOBS_FILE = os.path.join(DATA_DIR, "jobs.csv")
LOG_FILE = os.path.join(LOG_DIR, "job_agent.log")
RUN_HISTORY_FILE = os.path.join(LOG_DIR, "run_history.csv")

IMAP_SERVER = "imap.mail.yahoo.com"
IMAP_PORT = 993
WINDOWS = (7, 14, 30)

FIELDS = [
    "date_found", "source", "title", "company", "location",
    "url", "email_subject", "email_date"
]

DEFAULT_PROFILE = {
    "name": "Saiful Quadir",
    "target_titles": [
        "market research analyst", "market research manager",
        "data analyst", "business analyst",
        "business development analyst", "project coordinator",
        "project manager", "project analyst", "marketing analyst",
        "marketing analytics", "operations analyst", "software qa",
        "qa analyst", "quality assurance analyst"
    ],
    "preferred_locations": ["Canada-wide", "Remote (Canada)"],
    "do_not_apply": [
        "unpaid", "commission only", "commission-only", "volunteer",
        "must be a us citizen", "u.s. citizenship required",
        "security clearance required", "requires relocation"
    ],
    "job_families": [
        "market research", "data analysis", "business analysis",
        "business development", "project management",
        "project coordination", "project analysis",
        "marketing analysis", "marketing analytics",
        "operations analysis", "software qa", "quality assurance"
    ],
    "search_scope": {
        "search_windows_days": [7, 14, 30],
        "geography": "All provinces and territories of Canada",
        "remote_policy": "Include remote positions available to candidates in Canada"
    }
}

CANADA_TERMS = [
    "canada", "canada-wide", "canada wide", "remote (canada)",
    "remote canada", "remote in canada", "remote within canada",
    "ontario", "quebec", "british columbia", "alberta", "manitoba",
    "saskatchewan", "nova scotia", "new brunswick",
    "newfoundland", "newfoundland and labrador",
    "prince edward island", "northwest territories", "nunavut", "yukon",
    "toronto", "ottawa", "mississauga", "brampton", "vaughan",
    "markham", "richmond hill", "oakville", "burlington", "hamilton",
    "london", "kitchener", "waterloo", "guelph", "windsor", "kingston",
    "montreal", "quebec city", "calgary", "edmonton", "vancouver",
    "victoria", "winnipeg", "halifax", "saskatoon", "regina",
    "st. john's", "fredericton", "charlottetown", "yellowknife",
    "whitehorse", "iqaluit"
]

US_ONLY = [
    "us only", "u.s. only", "united states only", "usa only",
    "must be in the united states",
    "must be located in the united states",
    "must reside in the united states",
    "must live in the united states",
    "authorized to work in the united states only"
]


def log(message):
    os.makedirs(LOG_DIR, exist_ok=True)
    line = f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {message}"
    print(line)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\\n")


def load_json(path, default):
    if not os.path.exists(path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(default, f, indent=4)
        return default
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def clean(text):
    if not text:
        return ""
    text = html.unescape(str(text))
    text = re.sub(r"<script\\b.*?</script>", " ", text, flags=re.I | re.S)
    text = re.sub(r"<style\\b.*?</style>", " ", text, flags=re.I | re.S)
    text = re.sub(r"<[^>]+>", " ", text)
    return re.sub(r"\\s+", " ", text).strip()


def norm(text):
    return re.sub(r"\\s+", " ", str(text or "")).strip()


def low(text):
    return norm(text).lower()


def decode_subject(value):
    result = []
    for part, enc in decode_header(value or ""):
        if isinstance(part, bytes):
            try:
                result.append(part.decode(enc or "utf-8", errors="ignore"))
            except Exception:
                result.append(part.decode("utf-8", errors="ignore"))
        else:
            result.append(str(part))
    return norm("".join(result))


def email_body(msg):
    parts = []
    for part in msg.walk() if msg.is_multipart() else [msg]:
        ctype = part.get_content_type()
        disp = str(part.get("Content-Disposition", "")).lower()
        if "attachment" in disp or ctype not in ("text/plain", "text/html"):
            continue
        try:
            payload = part.get_payload(decode=True)
            if not payload:
                continue
            charset = part.get_content_charset() or "utf-8"
            parts.append(payload.decode(charset, errors="ignore"))
        except Exception:
            pass
    return "\\n".join(parts)


def detect_source(sender, subject, body):
    text = f"{sender} {subject} {body}".lower()
    li = "linkedin" in text or "linkedin.com" in text
    indeed = "indeed" in text or "indeed.com" in text
    if li and indeed:
        return "Both"
    if li:
        return "LinkedIn"
    if indeed:
        return "Indeed"
    return ""


def is_job_alert(sender, subject, body):
    if detect_source(sender, subject, body):
        return True
    text = f"{sender} {subject} {body}".lower()
    return any(x in text for x in (
        "job alert", "jobs matching", "recommended jobs",
        "job recommendations", "new jobs",
        "jobs you may be interested"
    ))


def normalize_url(url):
    url = html.unescape(str(url or "")).strip().replace("\\\\/", "/")
    m = re.fullmatch(r"\\[([^\\]]+)\\]\\(([^)]+)\\)", url)
    if m:
        url = m.group(1) if m.group(1).lower().startswith("http") else m.group(2)
    return url.rstrip(".,);]}>\\\"'")


def extract_urls(body):
    found = []
    patterns = [
        r'''href\\s*=\\s*"([^"]+)"''',
        r"""href\\s*=\\s*'([^']+)'""",
        r"https?://[^\\s<>\\\"']+"
    ]
    for pattern in patterns:
        found.extend(re.findall(pattern, body or "", flags=re.I))
    found.extend(re.findall(r"\\[[^\\]]+\\]\\((https?://[^)\\s]+)\\)", body or ""))
    result = []
    for url in found:
        url = normalize_url(url)
        if url and url not in result:
            result.append(url)
    return result


def classify(url):
    u = normalize_url(url).lower()
    if re.search(r"(?:https?://)?(?:[\\w-]+\\.)?linkedin\\.com/(?:comm/)?jobs/view/\\d+", u):
        return "LinkedIn"
    if "indeed.com" in u and (
        "?jk=" in u or "&jk=" in u or "/viewjob" in u or "/rc/" in u
    ):
        return "Indeed"
    return ""


def anchor_records(body):
    pattern = re.compile(
        r'''<a\\b[^>]*href\\s*=\\s*["']([^"']+)["'][^>]*>(.*?)</a>''',
        re.I | re.S
    )
    return [
        (normalize_url(m.group(1)), clean(m.group(2)))
        for m in pattern.finditer(body or "")
    ]


def title_matches(title, profile):
    t = low(title)
    if not t:
        return False
    for target in profile.get("target_titles", []):
        if low(target) in t:
            return True

    patterns = (
        "market research", "data analyst", "data analysis",
        "business analyst", "business development",
        "project manager", "project coordinator", "project analyst",
        "marketing analyst", "marketing analytics",
        "operations analyst", "software qa",
        "quality assurance", "qa analyst"
    )
    return any(p in t for p in patterns)


def canada_eligible(text):
    t = low(text)
    if any(x in t for x in US_ONLY):
        return False
    return any(x in t for x in CANADA_TERMS)


def excluded(text, profile):
    t = low(text)
    return [
        rule for rule in profile.get("do_not_apply", [])
        if low(rule) and low(rule) in t
    ]


def clean_title(title):
    title = norm(title)
    if not title or len(title) > 180:
        return ""
    if low(title) in {
        "apply", "apply now", "view job", "view job posting",
        "see job", "learn more", "see all jobs", "view jobs"
    }:
        return ""
    return title


def split_title_company(text):
    text = norm(text)
    for sep in (" | ", " — ", " – ", " - "):
        parts = [norm(x) for x in text.split(sep)]
        if len(parts) == 2 and parts[0] and parts[1]:
            return parts[0], parts[1]
    return text, ""


def linkedin_cards(body):
    text = clean(body)
    text = re.sub(r"^.*?match your preferences\\.\\s*", "", text, flags=re.I)
    text = re.split(r"\\s+See all jobs\\b", text, maxsplit=1, flags=re.I)[0]
    cards = []

    # Common LinkedIn format:
    # Title · Company · Toronto, ON (Remote)
    pattern = re.compile(
        r"(?P<title>[^·•]{3,160}?)\\s+[·•]\\s+"
        r"(?P<company>[^·•]{1,100})\\s+[·•]\\s+"
        r"(?P<location>[^·•]{1,120}\\((?:Remote|Hybrid)\\))",
        re.I
    )
    for m in pattern.finditer(text):
        cards.append({
            "title": clean_title(m.group("title")),
            "company": norm(m.group("company")),
            "location": norm(m.group("location"))
        })

    # Alternate format: Title, Company · Location (Remote)
    if not cards:
        pattern = re.compile(
            r"(?P<prefix>[^·•]{3,220}?)\\s+[·•]\\s+"
            r"(?P<location>[^·•]{1,120}\\((?:Remote|Hybrid)\\))",
            re.I
        )
        for m in pattern.finditer(text):
            title, company = split_title_company(m.group("prefix"))
            cards.append({
                "title": clean_title(title),
                "company": company,
                "location": norm(m.group("location"))
            })

    unique = []
    seen = set()
    for card in cards:
        key = (low(card["title"]), low(card["company"]), low(card["location"]))
        if key not in seen:
            seen.add(key)
            unique.append(card)
    return unique


def context_title(context, profile):
    text = norm(context)
    titles = sorted(profile.get("target_titles", []), key=len, reverse=True)
    for title in titles:
        m = re.search(re.escape(title), text, re.I)
        if m:
            return m.group(0)
    return ""


def extract_location(text):
    t = low(text)
    hits = []
    for item in CANADA_TERMS:
        if item in t and item not in hits:
            hits.append(item)
    return ", ".join(hits[:3])


def extract_company(text, title):
    text = norm(text)
    for pattern in (
        r"\\bat\\s+([A-Z][A-Za-z0-9&.,'’()\\- ]{2,80})",
        r"\\bwith\\s+([A-Z][A-Za-z0-9&.,'’()\\- ]{2,80})"
    ):
        m = re.search(pattern, text)
        if m:
            value = norm(m.group(1))
            if value and low(value) != low(title):
                return value
    return ""


def make_job(source, title, company, location, url, subject, date, body, profile):
    title = clean_title(title)
    company = norm(company)
    location = norm(location)
    if not title or not title_matches(title, profile):
        return None

    all_text = f"{title} {company} {location} {subject} {body}"
    if excluded(all_text, profile):
        return None
    if not canada_eligible(f"{location} {all_text}"):
        return None

    return {
        "date_found": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "source": source,
        "title": title,
        "company": company,
        "location": location,
        "url": normalize_url(url),
        "email_subject": norm(subject),
        "email_date": norm(date)
    }


def extract_linkedin(body, subject, date, profile):
    urls = [u for u in extract_urls(body) if classify(u) == "LinkedIn"]
    cards = linkedin_cards(body)
    jobs = []

    for i in range(min(len(urls), len(cards))):
        card = cards[i]
        job = make_job(
            "LinkedIn", card["title"], card["company"], card["location"],
            urls[i], subject, date, body, profile
        )
        if job:
            jobs.append(job)

    # Fallback to anchor text if card parsing did not work.
    if not jobs:
        for url, anchor in anchor_records(body):
            if classify(url) != "LinkedIn":
                continue
            title = clean_title(anchor)
            job = make_job(
                "LinkedIn", title, "", "", url,
                subject, date, body, profile
            )
            if job:
                jobs.append(job)

    return jobs


def extract_indeed(body, subject, date, profile):
    jobs = []
    records = anchor_records(body)

    # Prefer anchor text because it is part of the alert email.
    for url, anchor in records:
        if classify(url) != "Indeed":
            continue
        title = clean_title(anchor)
        if not title:
            continue
        pos = body.find(url)
        context = clean(body[max(0, pos - 800):pos + 1000]) if pos >= 0 else ""
        if not title_matches(title, profile):
            title = context_title(context, profile)
        if not title:
            continue
        job = make_job(
            "Indeed", title, extract_company(context, title),
            extract_location(context), url, subject, date, body, profile
        )
        if job:
            jobs.append(job)

    # Plain URL fallback.
    if not jobs:
        for url in extract_urls(body):
            if classify(url) != "Indeed":
                continue
            pos = body.find(url)
            context = clean(body[max(0, pos - 700):pos + 900]) if pos >= 0 else ""
            title = context_title(context, profile)
            if not title:
                continue
            job = make_job(
                "Indeed", title, extract_company(context, title),
                extract_location(context), url, subject, date, body, profile
            )
            if job:
                jobs.append(job)

    return jobs


def job_key(job):
    url = normalize_url(job.get("url", ""))
    if url:
        return ("url", low(url))
    return (
        "details", low(job.get("source", "")),
        low(job.get("title", "")), low(job.get("company", "")),
        low(job.get("location", ""))
    )


def load_jobs():
    if not os.path.exists(JOBS_FILE):
        return []
    try:
        with open(JOBS_FILE, encoding="utf-8", newline="") as f:
            return list(csv.DictReader(f))
    except Exception:
        return []


def save_jobs(jobs):
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(JOBS_FILE, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows({k: j.get(k, "") for k in FIELDS} for j in jobs)


def append_history(data):
    fields = [
        "run_id", "start_time", "end_time", "duration_seconds",
        "days_to_scan", "source", "emails_scanned", "alerts_found",
        "jobs_found", "new_jobs", "duplicates", "errors", "status"
    ]
    exists = os.path.exists(RUN_HISTORY_FILE)
    os.makedirs(LOG_DIR, exist_ok=True)
    with open(RUN_HISTORY_FILE, "a", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        if not exists:
            writer.writeheader()
        writer.writerow(data)


def connect_yahoo(config):
    user = norm(config.get("yahoo_email", ""))
    password = str(config.get("yahoo_app_password", "")).strip()
    if not user or not password:
        raise ValueError("Yahoo email or Yahoo App Password is missing from config.json")
    mail = imaplib.IMAP4_SSL(
        IMAP_SERVER, IMAP_PORT, ssl_context=ssl.create_default_context()
    )
    mail.login(user, password)
    return mail


def parse_args():
    parser = argparse.ArgumentParser(description="Phase 1 Yahoo job-alert to CSV agent")
    parser.add_argument("--days", type=int, choices=WINDOWS, default=None)
    parser.add_argument("--source", choices=("LinkedIn", "Indeed", "Both"), default="Both")
    parser.add_argument(
        "--reset-csv", action="store_true",
        help="Start jobs.csv clean using only jobs found in this run"
    )
    return parser.parse_args()


def main():
    args = parse_args()
    os.makedirs(DATA_DIR, exist_ok=True)
    os.makedirs(LOG_DIR, exist_ok=True)

    config = load_json(CONFIG_FILE, {
        "yahoo_email": "",
        "yahoo_app_password": "",
        "search_windows_days": [7, 14, 30],
        "default_days_to_scan": 7
    })
    profile = load_json(PROFILE_FILE, DEFAULT_PROFILE)

    default_days = int(config.get("default_days_to_scan", 7))
    days = args.days if args.days is not None else (
        default_days if default_days in WINDOWS else 7
    )

    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    start = datetime.now()
    counts = {
        "emails": 0, "alerts": 0, "jobs": 0,
        "new": 0, "duplicates": 0, "errors": 0
    }
    status = "SUCCESS"

    print("=" * 64)
    print("JOB SEARCH AGENT - PHASE 1")
    print("=" * 64)
    print(f"Window : {days} days")
    print(f"Source : {args.source}")
    print("Mode   : EMAIL ONLY - no job-page fetching")
    print()

    try:
        mail = connect_yahoo(config)
        mail.select("INBOX")
        since = (datetime.now() - timedelta(days=days)).strftime("%d-%b-%Y")
        ok, data = mail.search(None, "SINCE", since)
        if ok != "OK":
            raise RuntimeError("Yahoo INBOX search failed")

        message_ids = data[0].split()
        log(f"Run {run_id}: {len(message_ids)} messages in {days}-day window")

        existing = [] if args.reset_csv else load_jobs()
        known = {job_key(j) for j in existing}
        new_jobs = []

        for message_id in reversed(message_ids):
            counts["emails"] += 1
            try:
                ok, data = mail.fetch(message_id, "(RFC822)")
                if ok != "OK":
                    counts["errors"] += 1
                    continue

                msg = email.message_from_bytes(data[0][1])
                subject = decode_subject(msg.get("Subject", ""))
                sender = msg.get("From", "")
                date = msg.get("Date", "")
                body = email_body(msg)

                if not is_job_alert(sender, subject, body):
                    continue

                detected = detect_source(sender, subject, body)
                if args.source == "LinkedIn" and detected not in ("LinkedIn", "Both"):
                    continue
                if args.source == "Indeed" and detected not in ("Indeed", "Both"):
                    continue

                counts["alerts"] += 1
                jobs = []

                if detected in ("LinkedIn", "Both") and args.source in ("LinkedIn", "Both"):
                    jobs.extend(extract_linkedin(body, subject, date, profile))

                if detected in ("Indeed", "Both") and args.source in ("Indeed", "Both"):
                    jobs.extend(extract_indeed(body, subject, date, profile))

                seen_email = set()
                for job in jobs:
                    key = job_key(job)
                    if key in seen_email:
                        continue
                    seen_email.add(key)
                    counts["jobs"] += 1

                    if key in known:
                        counts["duplicates"] += 1
                        continue

                    known.add(key)
                    new_jobs.append(job)
                    counts["new"] += 1

                    print(
                        f"FOUND | {job['source']} | {job['title']} | "
                        f"{job['company'] or 'Company not extracted'} | "
                        f"{job['location'] or 'Location not extracted'}"
                    )

            except Exception as exc:
                counts["errors"] += 1
                log(f"Email processing error: {exc}")

        try:
            mail.logout()
        except Exception:
            pass

        final_jobs = new_jobs if args.reset_csv else existing + new_jobs
        save_jobs(final_jobs)

    except Exception as exc:
        status = "ERROR"
        counts["errors"] += 1
        log(f"Run failed: {exc}")
        try:
            mail.logout()
        except Exception:
            pass

    end = datetime.now()
    duration = round((end - start).total_seconds(), 2)

    append_history({
        "run_id": run_id,
        "start_time": start.strftime("%Y-%m-%d %H:%M:%S"),
        "end_time": end.strftime("%Y-%m-%d %H:%M:%S"),
        "duration_seconds": duration,
        "days_to_scan": days,
        "source": args.source,
        "emails_scanned": counts["emails"],
        "alerts_found": counts["alerts"],
        "jobs_found": counts["jobs"],
        "new_jobs": counts["new"],
        "duplicates": counts["duplicates"],
        "errors": counts["errors"],
        "status": status
    })

    print()
    print("=" * 64)
    print("RUN COMPLETE")
    print("=" * 64)
    for label, key in (
        ("Emails scanned", "emails"),
        ("Alerts found", "alerts"),
        ("Jobs found", "jobs"),
        ("New jobs", "new"),
        ("Duplicates", "duplicates"),
        ("Errors", "errors")
    ):
        print(f"{label:<16}: {counts[key]}")
    print(f"Status           : {status}")
    print(f"CSV              : {JOBS_FILE}")
    print("=" * 64)


if __name__ == "__main__":
    main()
'''

path = Path("/mnt/data/job_agent_phase1.py")
path.write_text(code, encoding="utf-8")
print(f"Created: {path}")
print(f"Lines: {len(code.splitlines())}")
