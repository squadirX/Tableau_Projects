#!/usr/bin/env python3
"""
JobSearchAgent
---------------
A simple, single-file job-search application for personal use.

Main responsibilities:
1. Read LinkedIn/Indeed job-alert emails from Yahoo Mail.
2. Extract and validate job-posting links.
3. Remove duplicate postings.
4. Match jobs against candidate_profile.json.
5. Keep a permanent run-history log.
6. Keep a permanent job database.
7. Keep/update one permanent Excel workbook when openpyxl is installed.
8. Provide a simple interactive dashboard.
9. Keep both DOC/DOCX and PDF resume files visible in the system.
10. Never submit job applications automatically.

Project folder:
    ~/JobSearchAgent

Important:
- Before first use, create/verify config.json and candidate_profile.json.
- Never put your Yahoo password into source code.
- Use a Yahoo App Password in config.json.
- The program appends to history; it does not recreate the history file.
- User-entered application fields in Excel are preserved.

Author: Saiful Quadir
Version: 1.0.0
"""

# ============================================================
# STEP 1 - IMPORTS
# ============================================================

import csv
import email
import html
import imaplib
import json
import os
import re
import ssl
import subprocess
import sys
import time
import traceback
import webbrowser

from datetime import datetime, timedelta
from email.header import decode_header
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote
from urllib.request import Request, urlopen


# ============================================================
# STEP 2 - APPLICATION INFORMATION
# ============================================================

APP_NAME = "JobSearchAgent"
DEVELOPER = "Saiful Quadir"
VERSION = "1.0.0"
COPYRIGHT_YEAR = datetime.now().year

BASE_DIR = Path.home() / "JobSearchAgent"
DATA_DIR = BASE_DIR / "data"
LOG_DIR = BASE_DIR / "logs"

CONFIG_FILE = BASE_DIR / "config.json"
PROFILE_FILE = BASE_DIR / "candidate_profile.json"

JOBS_FILE = DATA_DIR / "jobs.csv"
RUN_HISTORY_FILE = LOG_DIR / "run_history.csv"
APP_LOG_FILE = LOG_DIR / "job_agent.log"
EXCEL_FILE = BASE_DIR / "Job_Search_Tracker.xlsx"

DATA_DIR.mkdir(parents=True, exist_ok=True)
LOG_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# STEP 3 - DEFAULT SEARCH PROFILE
# ============================================================

DEFAULT_PROFILE = {
    "target_titles": [
        "market research analyst",
        "market research manager",
        "market research specialist",
        "market research coordinator",
        "market research operations",
        "research analyst",
        "research coordinator",
        "data analyst",
        "data analysis",
        "business analyst",
        "business development analyst",
        "business development coordinator",
        "project coordinator",
        "project manager",
        "project analyst",
        "marketing analyst",
        "marketing analytics",
        "operations analyst",
        "operations coordinator",
        "reporting analyst",
        "mis analyst",
        "software qa",
        "qa analyst",
        "quality assurance analyst",
        "software tester",
        "software testing",
        "data entry specialist",
        "data entry clerk",
        "data entry associate",
        "data entry operator",
        "data entry analyst",
        "data processing clerk",
        "data processing specialist",
        "data operations associate",
        "data quality specialist",
        "data quality analyst",
        "records clerk",
        "records administrator",
        "administrative data entry",
    ],
    "preferred_locations": [
        "canada",
        "remote canada",
        "remote",
        "ontario",
        "toronto",
        "mississauga",
        "brampton",
        "vaughan",
        "markham",
        "richmond hill",
        "oakville",
        "burlington",
        "ottawa",
        "hamilton",
        "london",
        "windsor",
        "kingston",
        "kitchener",
        "waterloo",
        "guelph",
        "montreal",
        "quebec",
        "quebec city",
        "calgary",
        "edmonton",
        "vancouver",
        "victoria",
        "winnipeg",
        "halifax",
        "saskatoon",
        "regina",
        "st. john's",
        "newfoundland",
        "new brunswick",
        "nova scotia",
        "manitoba",
        "saskatchewan",
        "alberta",
        "british columbia",
        "prince edward island",
        "newfoundland and labrador",
        "northwest territories",
        "yukon",
        "nunavut",
        "hybrid",
        "on-site",
        "onsite",
    ],
    "skills": [
        "market research",
        "data analysis",
        "business development",
        "project management",
        "project coordination",
        "stakeholder management",
        "digital surveys",
        "survey analysis",
        "market analysis",
        "competitive analysis",
        "business analysis",
        "data visualization",
        "reporting",
        "power bi",
        "tableau",
        "excel",
        "automation",
        "process improvement",
        "systems analysis",
        "software testing",
        "quality assurance",
        "marketing analytics",
        "machine learning",
        "python",
        "sql",
        "data entry",
        "data processing",
        "data validation",
        "data verification",
        "data quality",
        "data cleansing",
        "records management",
        "database maintenance",
        "information management",
        "document management",
        "crm data entry",
    ],
    "experience": [
        "market research",
        "digital surveys",
        "data analysis",
        "project management",
        "business development",
        "systems analysis",
        "team management",
        "process automation",
        "reporting",
        "client management",
        "data entry",
        "data processing",
        "data quality",
    ],
    "education": [
        "mba",
        "marketing",
        "b.com",
        "business",
    ],
    "certifications": [
        "google project management",
        "google cybersecurity",
        "ibm machine learning",
    ],
    "do_not_apply": [
        "unpaid",
        "commission only",
        "commission-only",
        "volunteer",
        "must be a us citizen",
        "u.s. citizenship required",
        "security clearance required",
        "requires relocation",
    ],
    "minimum_apply_score": 70,
    "minimum_review_score": 45,
}


# ============================================================
# STEP 4 - CSV HEADERS
# ============================================================

JOB_HEADERS = [
    "date_found",
    "source",
    "title",
    "company",
    "location",
    "score",
    "decision",
    "matched_skills",
    "negative_matches",
    "url",
    "job_id",
    "description",
    "first_seen",
    "last_seen",
]

RUN_HEADERS = [
    "run_id",
    "date",
    "start_time",
    "end_time",
    "duration_seconds",
    "sources",
    "days_to_scan",
    "emails_scanned",
    "job_links_found",
    "valid_jobs",
    "duplicates_removed",
    "new_jobs",
    "previously_seen",
    "apply_count",
    "review_count",
    "skip_count",
    "errors",
    "status",
]


# ============================================================
# STEP 5 - BASIC FILE HELPERS
# ============================================================

def now():
    return datetime.now()


def timestamp():
    return now().strftime("%Y-%m-%d %H:%M:%S")


def clean_text(value):
    """Make email/page text easier to search."""
    if not value:
        return ""

    value = html.unescape(str(value))
    value = re.sub(r"(?is)<script.*?>.*?</script>", " ", value)
    value = re.sub(r"(?is)<style.*?>.*?</style>", " ", value)
    value = re.sub(r"(?is)<[^>]+>", " ", value)
    value = re.sub(r"\s+", " ", value)
    return value.strip()


def load_json(path, default):
    if not path.exists():
        return default.copy() if isinstance(default, dict) else default

    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as exc:
        log_message(f"Could not read {path.name}: {exc}")
        return default.copy() if isinstance(default, dict) else default


def save_json(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)


def ensure_config():
    """Create a safe config template if config.json does not exist."""
    if not CONFIG_FILE.exists():
        config = {
            "yahoo_email": "",
            "yahoo_app_password": "",
            "days_to_scan": 7
        }
        save_json(CONFIG_FILE, config)


def ensure_profile():
    """Create a profile file only if it does not exist."""
    if not PROFILE_FILE.exists():
        save_json(PROFILE_FILE, DEFAULT_PROFILE)


def load_config():
    ensure_config()
    return load_json(CONFIG_FILE, {
        "yahoo_email": "",
        "yahoo_app_password": "",
        "days_to_scan": 7
    })


def load_profile():
    ensure_profile()
    profile = load_json(PROFILE_FILE, DEFAULT_PROFILE)

    # Add missing newer fields without destroying user settings.
    changed = False
    for key, value in DEFAULT_PROFILE.items():
        if key not in profile:
            profile[key] = value
            changed = True

    if changed:
        save_json(PROFILE_FILE, profile)

    return profile


# ============================================================
# STEP 6 - LOGGING
# ============================================================

def log_message(message):
    line = f"[{timestamp()}] {message}\n"

    try:
        with open(APP_LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        pass

    print(line, end="")


def ensure_csv(path, headers):
    """Create a CSV only once. Existing files are preserved."""
    if not path.exists():
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=headers)
            writer.writeheader()


def append_csv(path, headers, row):
    ensure_csv(path, headers)

    with open(path, "a", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=headers, extrasaction="ignore")
        writer.writerow(row)


def read_csv(path):
    if not path.exists():
        return []

    try:
        with open(path, "r", newline="", encoding="utf-8-sig") as f:
            return list(csv.DictReader(f))
    except Exception as exc:
        log_message(f"Could not read {path.name}: {exc}")
        return []


# ============================================================
# STEP 7 - RUN HISTORY
# ============================================================

def next_run_id():
    rows = read_csv(RUN_HISTORY_FILE)

    if not rows:
        return "RUN-000001"

    numbers = []
    for row in rows:
        value = row.get("run_id", "")
        match = re.search(r"(\d+)$", value)
        if match:
            numbers.append(int(match.group(1)))

    number = max(numbers, default=0) + 1
    return f"RUN-{number:06d}"


def save_run_history(stats):
    append_csv(RUN_HISTORY_FILE, RUN_HEADERS, stats)


def run_history_summary():
    rows = read_csv(RUN_HISTORY_FILE)

    if not rows:
        return {
            "total_runs": 0,
            "successful_runs": 0,
            "error_runs": 0,
            "last_run": "Never",
            "last_status": "Not run yet",
            "last_duration": "0",
            "jobs_processed": 0,
            "apply_total": 0,
            "review_total": 0,
            "new_jobs_total": 0,
        }

    successful = sum(1 for r in rows if r.get("status") == "Successful")
    errors = sum(1 for r in rows if r.get("status") != "Successful")

    def total_int(field):
        total = 0
        for row in rows:
            try:
                total += int(float(row.get(field, 0) or 0))
            except Exception:
                pass
        return total

    last = rows[-1]

    return {
        "total_runs": len(rows),
        "successful_runs": successful,
        "error_runs": errors,
        "last_run": f"{last.get('date', '')} {last.get('end_time', '')}",
        "last_status": last.get("status", "Unknown"),
        "last_duration": last.get("duration_seconds", "0"),
        "jobs_processed": total_int("valid_jobs"),
        "apply_total": total_int("apply_count"),
        "review_total": total_int("review_count"),
        "new_jobs_total": total_int("new_jobs"),
    }


# ============================================================
# STEP 8 - EMAIL HELPERS
# ============================================================

LINKEDIN_SENDER = "jobalerts-noreply@linkedin.com"
INDEED_SENDER = "donotreply@jobalert.indeed.com"


def decode_email_subject(subject):
    if not subject:
        return ""

    parts = decode_header(subject)
    result = []

    for part, charset in parts:
        if isinstance(part, bytes):
            try:
                result.append(part.decode(charset or "utf-8", errors="replace"))
            except Exception:
                result.append(part.decode("utf-8", errors="replace"))
        else:
            result.append(str(part))

    return "".join(result)


def get_sender_address(message):
    address = email.utils.parseaddr(message.get("From", ""))[1]
    return address.lower().strip()


def get_email_body(message):
    parts = []

    if message.is_multipart():
        for part in message.walk():
            content_type = part.get_content_type()
            disposition = str(part.get("Content-Disposition", ""))

            if "attachment" in disposition.lower():
                continue

            if content_type not in ("text/plain", "text/html"):
                continue

            try:
                payload = part.get_payload(decode=True)
                if payload:
                    charset = part.get_content_charset() or "utf-8"
                    parts.append(payload.decode(charset, errors="replace"))
            except Exception:
                continue
    else:
        try:
            payload = message.get_payload(decode=True)
            if payload:
                charset = message.get_content_charset() or "utf-8"
                parts.append(payload.decode(charset, errors="replace"))
        except Exception:
            pass

    return "\n".join(parts)


def is_job_alert(message):
    """Use exact verified senders first, then conservative subject checks."""
    sender = get_sender_address(message)
    subject = decode_email_subject(message.get("Subject", "")).lower()

    if sender in {LINKEDIN_SENDER, INDEED_SENDER}:
        return True

    # Secondary safeguard for forwarding/alias situations.
    indicators = [
        "job alert",
        "jobs you may be interested",
        "jobs matching",
        "recommended jobs",
        "job recommendations",
        "new jobs",
    ]

    return any(text in subject for text in indicators)


def connect_yahoo(config):
    yahoo_email = str(config.get("yahoo_email", "")).strip()
    app_password = str(config.get("yahoo_app_password", "")).strip()

    if not yahoo_email or not app_password:
        raise RuntimeError(
            "Yahoo credentials are missing. Complete config.json first."
        )

    context = ssl.create_default_context()

    mail = imaplib.IMAP4_SSL(
        "imap.mail.yahoo.com",
        993,
        ssl_context=context
    )

    mail.login(yahoo_email, app_password)
    mail.select("INBOX")

    return mail


# ============================================================
# STEP 9 - URL EXTRACTION AND VALIDATION
# ============================================================

def extract_urls(text):
    if not text:
        return []

    pattern = r'https?://[^\s<>"\'\]\)]+'
    found = re.findall(pattern, text)

    urls = []
    seen = set()

    for url in found:
        url = html.unescape(url)
        url = url.rstrip(".,;")
        if url not in seen:
            seen.add(url)
            urls.append(url)

    return urls


def normalize_url(url):
    """Normalize tracking/wrapped URLs where possible."""
    url = html.unescape(url).strip()

    # Remove common trailing punctuation.
    url = url.rstrip(".,;")

    parsed = urlparse(url)

    # LinkedIn often places useful links inside redirect parameters.
    query = parse_qs(parsed.query)

    for key in ("url", "u", "redirect", "redirectUrl", "dest", "destination"):
        if key in query and query[key]:
            candidate = unquote(query[key][0])
            if candidate.startswith("http"):
                url = candidate
                parsed = urlparse(url)
                break

    return url


def classify_and_validate_url(url):
    """
    Return:
        source, normalized_url, job_id
    or:
        None
    """
    url = normalize_url(url)
    parsed = urlparse(url)
    host = parsed.netloc.lower()

    # -------------------------
    # LinkedIn
    # -------------------------
    if "linkedin.com" in host:
        # Accept genuine LinkedIn job-view URLs only.
        match = re.search(
            r"/(?:comm/)?jobs/view/(\d+)",
            parsed.path,
            flags=re.I
        )

        if not match:
            return None

        job_id = match.group(1)
        canonical = f"https://www.linkedin.com/jobs/view/{job_id}/"

        return "LinkedIn", canonical, job_id

    # -------------------------
    # Indeed
    # -------------------------
    if "indeed.com" in host:
        # Indeed commonly uses jk=<job-id>.
        query = parse_qs(parsed.query)
        job_id = None

        if query.get("jk"):
            job_id = query["jk"][0]

        if not job_id:
            match = re.search(r"/viewjob/([A-Za-z0-9_-]+)", parsed.path)
            if match:
                job_id = match.group(1)

        if not job_id:
            match = re.search(r"/rc/clk\?jk=([A-Za-z0-9_-]+)", url)
            if match:
                job_id = match.group(1)

        if not job_id:
            return None

        canonical = f"https://ca.indeed.com/viewjob?jk={job_id}"

        return "Indeed", canonical, job_id

    return None


# ============================================================
# STEP 10 - FETCH PUBLIC JOB PAGE
# ============================================================

def fetch_page(url):
    try:
        request = Request(
            url,
            headers={
                "User-Agent": (
                    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                    "AppleWebKit/605.1.15 Safari/605.1.15"
                )
            }
        )

        with urlopen(request, timeout=15) as response:
            raw = response.read(2_000_000)

        return clean_text(raw.decode("utf-8", errors="replace"))

    except Exception as exc:
        log_message(f"Page fetch failed: {url} | {exc}")
        return ""


# ============================================================
# STEP 11 - JOB INFORMATION EXTRACTION
# ============================================================

def find_first(patterns, text, default="Unknown"):
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.I)
        if match:
            value = match.group(1).strip()
            if value:
                return value
    return default


def guess_job_title(subject, body, page):
    combined = f"{subject} {body} {page}"

    # Common label patterns.
    patterns = [
        r"(?:job title|position|role)\s*[:\-]\s*([^|]{3,100})",
        r"(?:view job|apply for)\s*[:\-]?\s*([^|]{3,100})",
    ]

    title = find_first(patterns, combined, "")

    if title:
        return title[:150].strip()

    # Look for known target title phrases.
    lower = combined.lower()

    candidates = sorted(
        DEFAULT_PROFILE["target_titles"],
        key=len,
        reverse=True
    )

    for candidate in candidates:
        if candidate.lower() in lower:
            return candidate.title()

    # Subject fallback.
    subject_clean = clean_text(subject)
    if subject_clean:
        subject_clean = re.sub(
            r"\b(job alert|jobs?|recommended|linkedin|indeed)\b",
            " ",
            subject_clean,
            flags=re.I
        )
        subject_clean = re.sub(r"\s+", " ", subject_clean).strip()

        if 3 <= len(subject_clean) <= 150:
            return subject_clean

    return "Unknown"


def guess_company(body, page):
    combined = f"{body} {page}"

    patterns = [
        r"(?:company|employer)\s*[:\-]\s*([^|]{2,100})",
        r"(?:at|with)\s+([A-Z][A-Za-z0-9&.,' -]{2,80})",
    ]

    company = find_first(patterns, combined, "")

    if company:
        company = re.sub(r"\s+", " ", company).strip(" -|")
        if company.lower() not in {
            "linkedin", "indeed", "unknown", "logo", "relative"
        }:
            return company[:100]

    return "Unknown"


def guess_location(body, page):
    combined = f"{body} {page}"

    canadian_locations = [
        "Toronto, Ontario",
        "Mississauga, Ontario",
        "Brampton, Ontario",
        "Vaughan, Ontario",
        "Markham, Ontario",
        "Ottawa, Ontario",
        "Hamilton, Ontario",
        "London, Ontario",
        "Windsor, Ontario",
        "Kitchener, Ontario",
        "Waterloo, Ontario",
        "Montreal, Quebec",
        "Quebec City, Quebec",
        "Calgary, Alberta",
        "Edmonton, Alberta",
        "Vancouver, British Columbia",
        "Victoria, British Columbia",
        "Winnipeg, Manitoba",
        "Halifax, Nova Scotia",
        "Saskatoon, Saskatchewan",
        "Regina, Saskatchewan",
        "Remote, Canada",
        "Canada",
        "Remote",
        "Hybrid",
        "On-site",
        "Onsite",
    ]

    for location in canadian_locations:
        if location.lower() in combined.lower():
            return location

    return "Canada / Unknown"


def extract_job_description(body, page):
    """
    Keep the email/page text reasonably sized.
    This is intentionally simple so it is easy to debug.
    """
    text = clean_text(f"{body} {page}")

    # Remove excessive navigation terms where possible.
    text = re.sub(r"\s+", " ", text)

    return text[:12000]


# ============================================================
# STEP 12 - JOB MATCHING
# ============================================================

def analyze_job(title, company, location, description, profile):
    title_text = title.lower()
    location_text = location.lower()
    description_text = description.lower()

    combined = f"{title_text} {description_text}"

    negative_matches = [
        rule for rule in profile.get("do_not_apply", [])
        if rule.lower() in combined
    ]

    matched_skills = [
        skill for skill in profile.get("skills", [])
        if skill.lower() in combined
    ]

    matched_experience = [
        item for item in profile.get("experience", [])
        if item.lower() in combined
    ]

    title_matches = [
        item for item in profile.get("target_titles", [])
        if item.lower() in title_text
    ]

    score = 0

    # Title: maximum 30.
    if title_matches:
        score += 30

    # Skills: maximum 40.
    score += min(len(matched_skills) * 4, 40)

    # Experience: maximum 20.
    score += min(len(matched_experience) * 4, 20)

    # Location: 10.
    if any(
        location_item.lower() in location_text
        for location_item in profile.get("preferred_locations", [])
    ):
        score += 10
    elif "canada" in location_text:
        score += 10

    if negative_matches:
        decision = "SKIP"
    elif score >= int(profile.get("minimum_apply_score", 70)):
        decision = "APPLY"
    elif score >= int(profile.get("minimum_review_score", 45)):
        decision = "REVIEW"
    else:
        decision = "SKIP"

    return {
        "score": score,
        "decision": decision,
        "matched_skills": ", ".join(matched_skills),
        "negative_matches": ", ".join(negative_matches),
    }


# ============================================================
# STEP 13 - JOB DATABASE / DEDUPLICATION
# ============================================================

def existing_job_ids():
    rows = read_csv(JOBS_FILE)

    ids = set()
    urls = set()

    for row in rows:
        if row.get("job_id"):
            ids.add(row["job_id"])

        if row.get("url"):
            urls.add(normalize_url(row["url"]))

    return ids, urls


def job_already_exists(job_id, url, known_ids, known_urls):
    if job_id and job_id in known_ids:
        return True

    if normalize_url(url) in known_urls:
        return True

    return False


def save_job_record(job):
    append_csv(JOBS_FILE, JOB_HEADERS, job)


# ============================================================
# STEP 14 - EXCEL TRACKER
# ============================================================

def open_excel_file():
    """Open the permanent Excel workbook in the default application."""
    if not EXCEL_FILE.exists():
        return False

    try:
        if sys.platform == "darwin":
            subprocess.Popen(["open", str(EXCEL_FILE)])
        elif sys.platform.startswith("win"):
            os.startfile(str(EXCEL_FILE))
        else:
            subprocess.Popen(["xdg-open", str(EXCEL_FILE)])

        return True
    except Exception as exc:
        log_message(f"Could not open Excel workbook: {exc}")
        return False


def create_or_update_excel():
    """
    Create one permanent workbook and update it on later runs.
    User-entered fields are intentionally not overwritten.
    """
    try:
        from openpyxl import Workbook, load_workbook
        from openpyxl.styles import Font, PatternFill, Alignment
        from openpyxl.utils import get_column_letter
    except ImportError:
        log_message(
            "openpyxl is not installed. Excel update skipped. "
            "Install it with: python3 -m pip install openpyxl"
        )
        return False

    try:
        if EXCEL_FILE.exists():
            wb = load_workbook(EXCEL_FILE)
        else:
            wb = Workbook()
            # Remove the default sheet if we will create our own.
            default = wb.active
            wb.remove(default)

        # ----------------------------------------
        # Permanent Settings sheet
        # ----------------------------------------
        if "Settings" not in wb.sheetnames:
            ws = wb.create_sheet("Settings")
            settings = [
                ("Application", APP_NAME),
                ("Developer", DEVELOPER),
                ("Version", VERSION),
                ("Created", timestamp()),
                ("Base Folder", str(BASE_DIR)),
                ("Jobs CSV", str(JOBS_FILE)),
                ("Run History", str(RUN_HISTORY_FILE)),
                ("Resume DOC/DOCX", find_resume_files()[0]),
                ("Resume PDF", find_resume_files()[1]),
            ]

            for row_number, (key, value) in enumerate(settings, start=1):
                ws.cell(row=row_number, column=1, value=key)
                ws.cell(row=row_number, column=2, value=value)

        # ----------------------------------------
        # All Jobs sheet
        # ----------------------------------------
        if "All Jobs" not in wb.sheetnames:
            ws = wb.create_sheet("All Jobs")
        else:
            ws = wb["All Jobs"]

        for col, header in enumerate(JOB_HEADERS, start=1):
            ws.cell(row=1, column=col, value=header)

        existing_rows = {
            ws.cell(row=r, column=11).value
            for r in range(2, ws.max_row + 1)
            if ws.max_row >= 2
        }

        csv_rows = read_csv(JOBS_FILE)

        for job in csv_rows:
            job_id = job.get("job_id", "")

            if job_id and job_id in existing_rows:
                continue

            row_number = ws.max_row + 1

            for col, header in enumerate(JOB_HEADERS, start=1):
                ws.cell(
                    row=row_number,
                    column=col,
                    value=job.get(header, "")
                )

        # ----------------------------------------
        # Applications sheet
        # ----------------------------------------
        if "Applications" not in wb.sheetnames:
            ws_app = wb.create_sheet("Applications")

            app_headers = [
                "Application ID",
                "Application Date",
                "Company",
                "Position",
                "Location",
                "Source",
                "Match Score",
                "Status",
                "Job URL",
                "Resume Version",
                "Cover Letter",
                "Contact Person",
                "Follow-up Date",
                "Follow-up Status",
                "Notes",
            ]

            for col, header in enumerate(app_headers, start=1):
                ws_app.cell(row=1, column=col, value=header)

        # ----------------------------------------
        # Dashboard sheet
        # ----------------------------------------
        if "Dashboard" not in wb.sheetnames:
            ws_dash = wb.create_sheet("Dashboard", 0)
        else:
            ws_dash = wb["Dashboard"]

        # Clear only dashboard content.
        for row in ws_dash.iter_rows():
            for cell in row:
                cell.value = None

        history = run_history_summary()

        dashboard_rows = [
            ("JOBSEARCHAGENT", ""),
            ("Developed by", DEVELOPER),
            ("Version", VERSION),
            ("Current Date & Time", timestamp()),
            ("", ""),
            ("LAST RUN", ""),
            ("Last Run", history["last_run"]),
            ("Last Status", history["last_status"]),
            ("Last Duration (seconds)", history["last_duration"]),
            ("", ""),
            ("RUN HISTORY", ""),
            ("Total Runs", history["total_runs"]),
            ("Successful Runs", history["successful_runs"]),
            ("Runs With Errors", history["error_runs"]),
            ("Jobs Processed", history["jobs_processed"]),
            ("APPLY Decisions", history["apply_total"]),
            ("REVIEW Decisions", history["review_total"]),
            ("New Jobs", history["new_jobs_total"]),
            ("", ""),
            ("RESUME FILES", ""),
            ("DOC/DOCX", find_resume_files()[0]),
            ("PDF", find_resume_files()[1]),
            ("", ""),
            ("Copyright", f"© {COPYRIGHT_YEAR} {DEVELOPER}"),
        ]

        for row_number, (label, value) in enumerate(dashboard_rows, start=1):
            ws_dash.cell(row=row_number, column=1, value=label)
            ws_dash.cell(row=row_number, column=2, value=value)

        # Simple professional formatting.
        for sheet in wb.worksheets:
            sheet.freeze_panes = "A2"

            for cell in sheet[1]:
                cell.font = Font(bold=True)

            for column_cells in sheet.columns:
                max_length = 0
                column_letter = get_column_letter(column_cells[0].column)

                for cell in column_cells[:100]:
                    value = "" if cell.value is None else str(cell.value)
                    max_length = max(max_length, len(value))

                sheet.column_dimensions[column_letter].width = min(
                    max(max_length + 2, 12),
                    45
                )

        wb.save(EXCEL_FILE)
        return True

    except Exception as exc:
        log_message(f"Excel update failed: {exc}")
        return False


# ============================================================
# STEP 15 - RESUME MANAGEMENT
# ============================================================

def find_resume_files():
    """
    Search the project folder and common Documents/Desktop locations.
    Both editable and PDF versions are retained.
    """
    search_roots = [
        BASE_DIR,
        Path.home() / "Documents",
        Path.home() / "Desktop",
        Path.home() / "Downloads",
    ]

    doc_files = []
    pdf_files = []

    for root in search_roots:
        if not root.exists():
            continue

        try:
            for path in root.rglob("*"):
                if not path.is_file():
                    continue

                name = path.name.lower()

                if (
                    path.suffix.lower() in {".doc", ".docx"}
                    and "resume" in name
                ):
                    doc_files.append(path)

                if path.suffix.lower() == ".pdf" and "resume" in name:
                    pdf_files.append(path)

        except Exception:
            continue

    def newest(paths):
        if not paths:
            return "Not found"

        try:
            path = max(paths, key=lambda p: p.stat().st_mtime)
            return str(path)
        except Exception:
            return str(paths[0])

    return newest(doc_files), newest(pdf_files)


# ============================================================
# STEP 16 - EMAIL SCANNING / JOB PROCESSING
# ============================================================

def scan_job_alerts(days_to_scan, sources):
    config = load_config()
    profile = load_profile()

    stats = {
        "emails_scanned": 0,
        "job_links_found": 0,
        "valid_jobs": 0,
        "duplicates_removed": 0,
        "new_jobs": 0,
        "previously_seen": 0,
        "apply_count": 0,
        "review_count": 0,
        "skip_count": 0,
        "errors": 0,
    }

    known_ids, known_urls = existing_job_ids()
    discovered_this_run = set()

    start_date = datetime.now() - timedelta(days=int(days_to_scan))

    mail = None

    try:
        log_message("Connecting to Yahoo Mail...")
        mail = connect_yahoo(config)

        status, data = mail.search(
            None,
            "SINCE",
            start_date.strftime("%d-%b-%Y")
        )

        if status != "OK":
            raise RuntimeError("Yahoo mail search failed.")

        message_ids = data[0].split()

        # Newest first, but keep processing manageable.
        message_ids = list(reversed(message_ids))[:300]

        log_message(
            f"Found {len(message_ids)} email(s) in the selected date window."
        )

        for message_id in message_ids:
            try:
                status, message_data = mail.fetch(
                    message_id,
                    "(RFC822)"
                )

                if status != "OK":
                    stats["errors"] += 1
                    continue

                raw = None

                for item in message_data:
                    if isinstance(item, tuple):
                        raw = item[1]
                        break

                if not raw:
                    continue

                message = email.message_from_bytes(raw)
                stats["emails_scanned"] += 1

                if not is_job_alert(message):
                    continue

                sender = get_sender_address(message)

                if "linkedin" in sender:
                    if "LinkedIn" not in sources and "Both" not in sources:
                        continue

                if "indeed" in sender:
                    if "Indeed" not in sources and "Both" not in sources:
                        continue

                subject = decode_email_subject(
                    message.get("Subject", "")
                )

                body = get_email_body(message)
                body_clean = clean_text(body)

                urls = extract_urls(body)

                for raw_url in urls:
                    result = classify_and_validate_url(raw_url)

                    if not result:
                        # This is the key protection against navigation links.
                        continue

                    source, url, job_id = result
                    stats["job_links_found"] += 1

                    unique_key = f"{source}:{job_id}"

                    if unique_key in discovered_this_run:
                        stats["duplicates_removed"] += 1
                        continue

                    discovered_this_run.add(unique_key)

                    if job_already_exists(
                        job_id,
                        url,
                        known_ids,
                        known_urls
                    ):
                        stats["previously_seen"] += 1
                        continue

                    page = fetch_page(url)

                    title = guess_job_title(
                        subject,
                        body_clean,
                        page
                    )

                    company = guess_company(
                        body_clean,
                        page
                    )

                    location = guess_location(
                        body_clean,
                        page
                    )

                    description = extract_job_description(
                        body_clean,
                        page
                    )

                    analysis = analyze_job(
                        title,
                        company,
                        location,
                        description,
                        profile
                    )

                    current_time = timestamp()

                    record = {
                        "date_found": now().strftime("%Y-%m-%d"),
                        "source": source,
                        "title": title,
                        "company": company,
                        "location": location,
                        "score": analysis["score"],
                        "decision": analysis["decision"],
                        "matched_skills": analysis["matched_skills"],
                        "negative_matches": analysis["negative_matches"],
                        "url": url,
                        "job_id": job_id,
                        "description": description,
                        "first_seen": current_time,
                        "last_seen": current_time,
                    }

                    save_job_record(record)

                    known_ids.add(job_id)
                    known_urls.add(url)

                    stats["valid_jobs"] += 1
                    stats["new_jobs"] += 1

                    if analysis["decision"] == "APPLY":
                        stats["apply_count"] += 1
                    elif analysis["decision"] == "REVIEW":
                        stats["review_count"] += 1
                    else:
                        stats["skip_count"] += 1

            except Exception as exc:
                stats["errors"] += 1
                log_message(f"Email processing error: {exc}")

        return stats

    finally:
        if mail:
            try:
                mail.logout()
            except Exception:
                pass


# ============================================================
# STEP 17 - DASHBOARD GUI
# ============================================================

def launch_dashboard():
    """
    Simple Tkinter dashboard.
    Tkinter is included with most standard Python installations on macOS.
    """
    try:
        import tkinter as tk
        from tkinter import ttk, messagebox
    except ImportError:
        print("Tkinter is not available on this Python installation.")
        print("The command-line mode can still be used.")
        return

    config = load_config()

    root = tk.Tk()
    root.title(f"{APP_NAME} — v{VERSION}")
    root.geometry("1100x760")
    root.minsize(900, 650)

    # -----------------------------
    # Variables
    # -----------------------------
    source_var = tk.StringVar(value="Both")
    days_var = tk.IntVar(value=int(config.get("days_to_scan", 7) or 7))
    status_var = tk.StringVar(value="Ready")
    progress_var = tk.DoubleVar(value=0)

    # -----------------------------
    # Main frame
    # -----------------------------
    main = ttk.Frame(root, padding=20)
    main.pack(fill="both", expand=True)

    title = ttk.Label(
        main,
        text=APP_NAME,
        font=("Helvetica", 24, "bold")
    )
    title.pack(anchor="w")

    ttk.Label(
        main,
        text=f"Developed by {DEVELOPER}  |  Version {VERSION}",
        font=("Helvetica", 11)
    ).pack(anchor="w", pady=(0, 15))

    # -----------------------------
    # Search options
    # -----------------------------
    options = ttk.LabelFrame(
        main,
        text="Search Options",
        padding=15
    )
    options.pack(fill="x", pady=5)

    ttk.Label(options, text="Sources:").grid(
        row=0, column=0, sticky="w", padx=5, pady=5
    )

    source_box = ttk.Combobox(
        options,
        textvariable=source_var,
        values=["Both", "LinkedIn", "Indeed"],
        state="readonly",
        width=15
    )
    source_box.grid(row=0, column=1, padx=5, pady=5)

    ttk.Label(options, text="Days to scan:").grid(
        row=0, column=2, sticky="w", padx=5, pady=5
    )

    days_box = ttk.Combobox(
        options,
        textvariable=days_var,
        values=[7, 14, 30],
        state="readonly",
        width=10
    )
    days_box.grid(row=0, column=3, padx=5, pady=5)

    # -----------------------------
    # Progress
    # -----------------------------
    ttk.Label(
        main,
        textvariable=status_var
    ).pack(anchor="w", pady=(15, 5))

    progress = ttk.Progressbar(
        main,
        variable=progress_var,
        maximum=100
    )
    progress.pack(fill="x")

    # -----------------------------
    # Metrics
    # -----------------------------
    metrics_frame = ttk.LabelFrame(
        main,
        text="Run / History",
        padding=15
    )
    metrics_frame.pack(fill="x", pady=15)

    metric_labels = {}

    metric_names = [
        "Total Runs",
        "Last Run",
        "Last Status",
        "Emails Scanned",
        "Valid Jobs",
        "New Jobs",
        "Duplicates Removed",
        "APPLY",
        "REVIEW",
        "SKIP",
        "Errors",
    ]

    for index, name in enumerate(metric_names):
        row = index // 2
        col = (index % 2) * 2

        ttk.Label(
            metrics_frame,
            text=name + ":",
            font=("Helvetica", 10, "bold")
        ).grid(row=row, column=col, sticky="w", padx=5, pady=5)

        label = ttk.Label(
            metrics_frame,
            text="-"
        )
        label.grid(
            row=row,
            column=col + 1,
            sticky="w",
            padx=5,
            pady=5
        )

        metric_labels[name] = label

    # -----------------------------
    # Activity log
    # -----------------------------
    log_frame = ttk.LabelFrame(
        main,
        text="Current Run Log",
        padding=10
    )
    log_frame.pack(fill="both", expand=True)

    log_text = tk.Text(
        log_frame,
        height=12,
        wrap="word"
    )
    log_text.pack(side="left", fill="both", expand=True)

    scrollbar = ttk.Scrollbar(
        log_frame,
        orient="vertical",
        command=log_text.yview
    )
    scrollbar.pack(side="right", fill="y")
    log_text.configure(yscrollcommand=scrollbar.set)

    # -----------------------------
    # Footer
    # -----------------------------
    footer = ttk.Label(
        main,
        text=(
            f"© {COPYRIGHT_YEAR} {DEVELOPER} | "
            f"{APP_NAME} v{VERSION} | "
            f"Updated: {timestamp()}"
        ),
        font=("Helvetica", 9)
    )
    footer.pack(anchor="center", pady=(10, 0))

    # -----------------------------
    # Dashboard refresh
    # -----------------------------
    def refresh_dashboard():
        history = run_history_summary()

        metric_labels["Total Runs"].config(
            text=str(history["total_runs"])
        )
        metric_labels["Last Run"].config(
            text=history["last_run"]
        )
        metric_labels["Last Status"].config(
            text=history["last_status"]
        )
        metric_labels["APPLY"].config(
            text=str(history["apply_total"])
        )
        metric_labels["REVIEW"].config(
            text=str(history["review_total"])
        )

        if JOBS_FILE.exists():
            jobs = read_csv(JOBS_FILE)

            metric_labels["Valid Jobs"].config(
                text=str(len(jobs))
            )

            apply_count = sum(
                1 for row in jobs
                if row.get("decision") == "APPLY"
            )

            review_count = sum(
                1 for row in jobs
                if row.get("decision") == "REVIEW"
            )

            skip_count = sum(
                1 for row in jobs
                if row.get("decision") == "SKIP"
            )

            metric_labels["APPLY"].config(text=str(apply_count))
            metric_labels["REVIEW"].config(text=str(review_count))
            metric_labels["SKIP"].config(text=str(skip_count))

        if RUN_HISTORY_FILE.exists():
            rows = read_csv(RUN_HISTORY_FILE)

            if rows:
                last = rows[-1]

                for field, label_name in [
                    ("emails_scanned", "Emails Scanned"),
                    ("valid_jobs", "Valid Jobs"),
                    ("new_jobs", "New Jobs"),
                    ("duplicates_removed", "Duplicates Removed"),
                    ("apply_count", "APPLY"),
                    ("review_count", "REVIEW"),
                    ("skip_count", "SKIP"),
                    ("errors", "Errors"),
                ]:
                    if field in last:
                        metric_labels[label_name].config(
                            text=last.get(field, "0")
                        )

        footer.config(
            text=(
                f"© {datetime.now().year} {DEVELOPER} | "
                f"{APP_NAME} v{VERSION} | "
                f"Updated: {timestamp()}"
            )
        )

    # -----------------------------
    # Run search
    # -----------------------------
    def run_search():
        start = time.time()
        run_id = next_run_id()
        start_dt = now()

        status_var.set(f"{run_id}: Starting...")
        progress_var.set(5)
        root.update_idletasks()

        log_text.delete("1.0", tk.END)

        def ui_log(message):
            log_text.insert(tk.END, message + "\n")
            log_text.see(tk.END)
            root.update_idletasks()

        try:
            ui_log("Starting JobSearchAgent...")
            ui_log(f"Run ID: {run_id}")
            ui_log(f"Sources: {source_var.get()}")
            ui_log(f"Date window: {days_var.get()} days")

            progress_var.set(15)
            status_var.set("Connecting to Yahoo Mail...")
            ui_log("Connecting to Yahoo Mail...")

            progress_var.set(30)
            status_var.set("Scanning job-alert emails...")
            ui_log("Scanning job-alert emails...")

            stats = scan_job_alerts(
                int(days_var.get()),
                source_var.get()
            )

            progress_var.set(75)
            status_var.set("Updating Excel tracker...")
            ui_log("Updating permanent Excel tracker...")

            excel_ok = create_or_update_excel()

            progress_var.set(90)

            duration = round(time.time() - start, 2)
            end_dt = now()

            status = "Successful" if stats["errors"] == 0 else "Completed With Errors"

            history_row = {
                "run_id": run_id,
                "date": start_dt.strftime("%Y-%m-%d"),
                "start_time": start_dt.strftime("%H:%M:%S"),
                "end_time": end_dt.strftime("%H:%M:%S"),
                "duration_seconds": duration,
                "sources": source_var.get(),
                "days_to_scan": days_var.get(),
                **stats,
                "status": status,
            }

            save_run_history(history_row)

            progress_var.set(100)
            status_var.set(status)

            ui_log("")
            ui_log("Search completed.")
            ui_log(f"Emails scanned: {stats['emails_scanned']}")
            ui_log(f"Valid jobs: {stats['valid_jobs']}")
            ui_log(f"New jobs: {stats['new_jobs']}")
            ui_log(f"Duplicates removed: {stats['duplicates_removed']}")
            ui_log(f"APPLY: {stats['apply_count']}")
            ui_log(f"REVIEW: {stats['review_count']}")
            ui_log(f"SKIP: {stats['skip_count']}")
            ui_log(f"Errors: {stats['errors']}")
            ui_log(f"Duration: {duration} seconds")
            ui_log(
                "Excel: updated"
                if excel_ok
                else "Excel: not updated (check openpyxl)"
            )

            refresh_dashboard()

            answer = messagebox.askyesno(
                "Search Completed",
                (
                    "Search completed successfully.\n\n"
                    "Would you like to open the permanent Excel Job Tracker?"
                )
            )

            if answer:
                if not open_excel_file():
                    messagebox.showwarning(
                        "Excel",
                        "The Excel file could not be opened."
                    )

        except Exception as exc:
            duration = round(time.time() - start, 2)

            log_message(
                f"RUN ERROR {run_id}: {exc}\n"
                f"{traceback.format_exc()}"
            )

            error_row = {
                "run_id": run_id,
                "date": start_dt.strftime("%Y-%m-%d"),
                "start_time": start_dt.strftime("%H:%M:%S"),
                "end_time": now().strftime("%H:%M:%S"),
                "duration_seconds": duration,
                "sources": source_var.get(),
                "days_to_scan": days_var.get(),
                "emails_scanned": 0,
                "job_links_found": 0,
                "valid_jobs": 0,
                "duplicates_removed": 0,
                "new_jobs": 0,
                "previously_seen": 0,
                "apply_count": 0,
                "review_count": 0,
                "skip_count": 0,
                "errors": 1,
                "status": "Failed",
            }

            save_run_history(error_row)

            status_var.set("Failed")
            progress_var.set(0)

            ui_log(f"ERROR: {exc}")

            messagebox.showerror(
                "JobSearchAgent Error",
                str(exc)
            )

            refresh_dashboard()

    # -----------------------------
    # Buttons
    # -----------------------------
    buttons = ttk.Frame(main)
    buttons.pack(fill="x", pady=10)

    ttk.Button(
        buttons,
        text="RUN NEW SEARCH",
        command=run_search
    ).pack(side="left", padx=(0, 10))

    ttk.Button(
        buttons,
        text="Refresh Dashboard",
        command=refresh_dashboard
    ).pack(side="left", padx=5)

    ttk.Button(
        buttons,
        text="Open Excel",
        command=open_excel_file
    ).pack(side="left", padx=5)

    ttk.Button(
        buttons,
        text="Open Run History",
        command=lambda: open_path(RUN_HISTORY_FILE)
    ).pack(side="left", padx=5)

    ttk.Button(
        buttons,
        text="Open Project Folder",
        command=lambda: open_path(BASE_DIR)
    ).pack(side="left", padx=5)

    refresh_dashboard()

    root.mainloop()


# ============================================================
# STEP 18 - OPEN FILE/FOLDER
# ============================================================

def open_path(path):
    try:
        if sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        elif sys.platform.startswith("win"):
            os.startfile(str(path))
        else:
            subprocess.Popen(["xdg-open", str(path)])
    except Exception as exc:
        log_message(f"Could not open {path}: {exc}")


# ============================================================
# STEP 19 - COMMAND-LINE MODE
# ============================================================

def command_line_run():
    """Useful for debugging without the GUI."""
    config = load_config()

    days = int(config.get("days_to_scan", 7) or 7)

    start = time.time()
    run_id = next_run_id()
    start_dt = now()

    print("=" * 70)
    print(f"{APP_NAME} v{VERSION}")
    print(f"Developed by {DEVELOPER}")
    print(f"Run ID: {run_id}")
    print("=" * 70)

    try:
        stats = scan_job_alerts(days, "Both")
        create_or_update_excel()

        duration = round(time.time() - start, 2)

        status = "Successful" if stats["errors"] == 0 else "Completed With Errors"

        row = {
            "run_id": run_id,
            "date": start_dt.strftime("%Y-%m-%d"),
            "start_time": start_dt.strftime("%H:%M:%S"),
            "end_time": now().strftime("%H:%M:%S"),
            "duration_seconds": duration,
            "sources": "Both",
            "days_to_scan": days,
            **stats,
            "status": status,
        }

        save_run_history(row)

        print("")
        print("SEARCH COMPLETE")
        print(f"Emails scanned:       {stats['emails_scanned']}")
        print(f"Job links found:      {stats['job_links_found']}")
        print(f"Valid new jobs:       {stats['valid_jobs']}")
        print(f"Duplicates removed:   {stats['duplicates_removed']}")
        print(f"Previously seen:      {stats['previously_seen']}")
        print(f"APPLY:                {stats['apply_count']}")
        print(f"REVIEW:               {stats['review_count']}")
        print(f"SKIP:                 {stats['skip_count']}")
        print(f"Errors:               {stats['errors']}")
        print(f"Duration:             {duration} seconds")
        print("=" * 70)

    except Exception as exc:
        duration = round(time.time() - start, 2)

        row = {
            "run_id": run_id,
            "date": start_dt.strftime("%Y-%m-%d"),
            "start_time": start_dt.strftime("%H:%M:%S"),
            "end_time": now().strftime("%H:%M:%S"),
            "duration_seconds": duration,
            "sources": "Both",
            "days_to_scan": days,
            "emails_scanned": 0,
            "job_links_found": 0,
            "valid_jobs": 0,
            "duplicates_removed": 0,
            "new_jobs": 0,
            "previously_seen": 0,
            "apply_count": 0,
            "review_count": 0,
            "skip_count": 0,
            "errors": 1,
            "status": "Failed",
        }

        save_run_history(row)

        log_message(
            f"Fatal run error: {exc}\n{traceback.format_exc()}"
        )

        print(f"ERROR: {exc}")


# ============================================================
# STEP 20 - MAIN
# ============================================================

def main():
    ensure_config()
    ensure_profile()

    # These files are created only once.
    ensure_csv(JOBS_FILE, JOB_HEADERS)
    ensure_csv(RUN_HISTORY_FILE, RUN_HEADERS)

    # GUI is the normal product mode.
    if "--cli" in sys.argv:
        command_line_run()
    else:
        launch_dashboard()


if __name__ == "__main__":
    main()
