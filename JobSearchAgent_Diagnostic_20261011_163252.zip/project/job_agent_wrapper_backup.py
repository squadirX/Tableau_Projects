from pathlib import Path
import json, textwrap, py_compile

base = Path("/mnt/data")
out = base / "job_agent_latest.py"

code = r'''#!/usr/bin/env python3
"""
JobSearchAgent
---------------
Personal Canada-wide job-search agent.

Key design:
- Reads LinkedIn / Indeed job-alert emails from Yahoo Mail.
- Uses email subject/body as the primary job source.
- Does NOT depend on fetching LinkedIn/Indeed job pages.
- Supports 7 / 14 / 30 day scans.
- Searches Canada-wide, including Remote (Canada).
- Applies broad target job families and seniority.
- Rejects hard exclusions such as unpaid, commission-only, volunteer,
  U.S.-citizenship-only, security-clearance-required, and relocation-required roles.
- Scores jobs using the candidate profile.
- Keeps permanent CSV run history and job database.
- Maintains an Excel tracker when openpyxl is available.
- Never submits applications automatically.

Version: 2.0.0
"""

from __future__ import annotations

import csv
import email
import html
import imaplib
import json
import logging
import re
import sys
import time
import urllib.parse
from datetime import datetime, timedelta, timezone
from email.header import decode_header
from email.message import Message
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

try:
    from bs4 import BeautifulSoup
except ImportError:
    BeautifulSoup = None

try:
    from openpyxl import Workbook, load_workbook
except ImportError:
    Workbook = None
    load_workbook = None


# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

BASE_DIR = Path.home() / "JobSearchAgent"
DATA_DIR = BASE_DIR / "data"
LOG_DIR = BASE_DIR / "logs"

CONFIG_FILE = BASE_DIR / "config.json"
PROFILE_FILE = BASE_DIR / "candidate_profile.json"
JOBS_FILE = DATA_DIR / "jobs.csv"
RUN_HISTORY_FILE = LOG_DIR / "run_history.csv"
APP_LOG_FILE = LOG_DIR / "job_agent.log"
EXCEL_FILE = BASE_DIR / "Job_Search_Tracker.xlsx"

BASE_DIR.mkdir(parents=True, exist_ok=True)
DATA_DIR.mkdir(parents=True, exist_ok=True)
LOG_DIR.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

logging.basicConfig(
    filename=str(APP_LOG_FILE),
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)
logger = logging.getLogger("JobSearchAgent")


# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

DEFAULT_CONFIG = {
    "yahoo_email": "",
    "yahoo_app_password": "",
    "search_windows_days": [7, 14, 30],
    "default_days_to_scan": 7,
}

DEFAULT_PROFILE = {
    "target_titles": [
        "market research analyst",
        "market research manager",
        "market research specialist",
        "market research coordinator",
        "research analyst",
        "research coordinator",
        "data analyst",
        "data analysis",
        "business analyst",
        "business development analyst",
        "business development coordinator",
        "project manager",
        "project coordinator",
        "project analyst",
        "marketing analyst",
        "marketing analytics",
        "operations analyst",
        "operations coordinator",
        "reporting analyst",
        "mis analyst",
        "software qa",
        "qa analyst",
        "quality assurance analyst",
        "software tester",
        "software testing",
    ],
    "job_families": [
        "market research",
        "data analysis",
        "business analysis",
        "business development",
        "project management",
        "project coordination",
        "project analysis",
        "marketing analysis",
        "marketing analytics",
        "operations analysis",
        "software qa",
        "quality assurance",
    ],
    "preferred_locations": [
        "canada-wide",
        "remote (canada)",
    ],
    "skills": [
        "market research",
        "data analysis",
        "business development",
        "project management",
        "project coordination",
        "stakeholder management",
        "digital surveys",
        "survey analysis",
        "market analysis",
        "competitive analysis",
        "business analysis",
        "data visualization",
        "reporting",
        "power bi",
        "tableau",
        "excel",
        "automation",
        "process improvement",
        "systems analysis",
        "software testing",
        "qa",
        "marketing analytics",
        "machine learning",
        "python",
        "sql",
    ],
    "experience": [
        "market research",
        "digital surveys",
        "data analysis",
        "project management",
        "business development",
        "systems analysis",
        "team management",
        "process automation",
        "reporting",
        "client management",
    ],
    "education": [
        "MBA",
        "Marketing",
        "B.Com",
        "Business",
    ],
    "certifications": [
        "Google Project Management",
        "Google Cybersecurity",
        "IBM Machine Learning",
    ],
    "hard_exclusions": [
        "unpaid",
        "commission only",
        "commission-only",
        "volunteer",
        "must be a us citizen",
        "u.s. citizenship required",
        "security clearance required",
        "requires relocation",
    ],
    "scoring": {
        "minimum_apply_score": 70,
        "minimum_review_score": 45,
        "score_70_or_higher": "apply/recommended for application",
        "score_45_to_69": "review",
        "score_below_45": "skip",
    },
    "search_scope": {
        "geography": "All provinces and territories of Canada",
        "remote_policy": "Include remote positions available to candidates in Canada",
        "search_windows_days": [7, 14, 30],
        "seniority": "broad; do not exclude suitable roles solely by seniority or title",
    },
    "application_strategy": {
        "daily_quality_application_target": "2-3",
        "automatic_applications": False,
        "user_final_decision_required": True,
        "quality_over_quantity": True,
    },
    "job_source_strategy": {
        "primary": "Parse job information directly from available job-alert emails",
        "external_page_fetching": "Do not depend on fetching Indeed or LinkedIn job pages",
        "data_quality": "Reject navigation/fake records and avoid contaminating the clean jobs dataset",
    },
}


# ---------------------------------------------------------------------------
# CSV headers
# ---------------------------------------------------------------------------

JOB_HEADERS = [
    "job_id",
    "source",
    "source_sender",
    "email_date",
    "received_at",
    "job_url",
    "job_title",
    "company",
    "location",
    "employment_type",
    "salary",
    "description",
    "matched_title_terms",
    "matched_job_families",
    "matched_skills",
    "matched_experience",
    "matched_location",
    "negative_matches",
    "score",
    "decision",
    "reason",
    "first_seen",
    "last_seen",
]

RUN_HEADERS = [
    "run_id",
    "run_started_at",
    "run_finished_at",
    "days_to_scan",
    "sources",
    "emails_scanned",
    "alerts_found",
    "jobs_extracted",
    "new_jobs",
    "duplicate_jobs",
    "apply_count",
    "review_count",
    "skip_count",
    "errors",
    "status",
]


# ---------------------------------------------------------------------------
# General helpers
# ---------------------------------------------------------------------------

def now_local_string() -> str:
    return datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S")


def normalize_space(value: object) -> str:
    if value is None:
        return ""
    text = str(value).replace("\x00", " ")
    return re.sub(r"\s+", " ", text).strip()


def normalize_for_match(value: object) -> str:
    text = normalize_space(value).lower()
    text = text.replace("’", "'")
    return text


def clean_text(value: object) -> str:
    text = normalize_space(value)
    return html.unescape(text)


def safe_int(value: object, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def unique_preserve(items: Iterable[str]) -> List[str]:
    seen = set()
    result = []
    for item in items:
        item = normalize_space(item)
        key = item.lower()
        if item and key not in seen:
            seen.add(key)
            result.append(item)
    return result


def decode_mime_header(value: Optional[str]) -> str:
    if not value:
        return ""
    parts = []
    for item, encoding in decode_header(value):
        if isinstance(item, bytes):
            try:
                parts.append(item.decode(encoding or "utf-8", errors="replace"))
            except LookupError:
                parts.append(item.decode("utf-8", errors="replace"))
        else:
            parts.append(str(item))
    return normalize_space("".join(parts))


def parse_email_datetime(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        parsed = email.utils.parsedate_to_datetime(value)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone()
    except (TypeError, ValueError, IndexError, OverflowError):
        return None


def iso_date_string(dt: Optional[datetime]) -> str:
    return dt.strftime("%Y-%m-%d %H:%M:%S") if dt else ""


def normalize_url(url: str) -> str:
    url = html.unescape(normalize_space(url))
    url = url.strip("<>\"'")
    if not url:
        return ""
    parsed = urllib.parse.urlsplit(url)
    if not parsed.scheme:
        return ""
    scheme = parsed.scheme.lower()
    host = parsed.netloc.lower()

    if "linkedin.com" in host:
        host = "www.linkedin.com"
    elif "indeed.com" in host:
        host = "ca.indeed.com" if host.startswith("ca.") else host

    path = parsed.path.rstrip("/")
    query = parsed.query

    return urllib.parse.urlunsplit((scheme, host, path, query, ""))


def canonical_job_id(source: str, url: str) -> str:
    source = normalize_for_match(source)
    url = normalize_url(url)

    if source == "linkedin":
        match = re.search(r"/jobs/view/(\d+)", url, re.I)
        if match:
            return f"linkedin:{match.group(1)}"

    if source == "indeed":
        match = re.search(r"[?&]jk=([A-Za-z0-9_-]+)", url, re.I)
        if match:
            return f"indeed:{match.group(1)}"

    digest = re.sub(r"[^a-z0-9]+", "", url.lower())
    return f"{source}:{digest[-80:]}" if digest else ""


# ---------------------------------------------------------------------------
# Configuration / profile
# ---------------------------------------------------------------------------

def write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(
        json.dumps(data, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    temp.replace(path)


def ensure_config() -> None:
    if not CONFIG_FILE.exists():
        write_json(CONFIG_FILE, DEFAULT_CONFIG)


def load_config() -> dict:
    ensure_config()

    try:
        data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        logger.error("Could not read config: %s", exc)
        data = {}

    merged = dict(DEFAULT_CONFIG)
    merged.update(data if isinstance(data, dict) else {})

    windows = merged.get("search_windows_days", [7, 14, 30])
    if not isinstance(windows, list):
        windows = [7, 14, 30]

    valid_windows = sorted(
        {safe_int(x) for x in windows if safe_int(x) in {7, 14, 30}}
    )
    merged["search_windows_days"] = valid_windows or [7, 14, 30]

    default_days = safe_int(merged.get("default_days_to_scan", 7), 7)
    if default_days not in merged["search_windows_days"]:
        default_days = 7
    merged["default_days_to_scan"] = default_days

    return merged


def ensure_profile() -> None:
    if not PROFILE_FILE.exists():
        write_json(PROFILE_FILE, DEFAULT_PROFILE)


def load_profile() -> dict:
    ensure_profile()

    try:
        data = json.loads(PROFILE_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        logger.error("Could not read profile: %s", exc)
        data = {}

    profile = dict(DEFAULT_PROFILE)
    if isinstance(data, dict):
        profile.update(data)

    # Keep profile authoritative while ensuring required structures exist.
    for key in (
        "target_titles",
        "job_families",
        "preferred_locations",
        "skills",
        "experience",
        "education",
        "certifications",
        "hard_exclusions",
    ):
        if not isinstance(profile.get(key), list):
            profile[key] = list(DEFAULT_PROFILE[key])

    if not isinstance(profile.get("scoring"), dict):
        profile["scoring"] = dict(DEFAULT_PROFILE["scoring"])
    else:
        scoring = dict(DEFAULT_PROFILE["scoring"])
        scoring.update(profile["scoring"])
        profile["scoring"] = scoring

    if not isinstance(profile.get("search_scope"), dict):
        profile["search_scope"] = dict(DEFAULT_PROFILE["search_scope"])

    if not isinstance(profile.get("application_strategy"), dict):
        profile["application_strategy"] = dict(DEFAULT_PROFILE["application_strategy"])

    if not isinstance(profile.get("job_source_strategy"), dict):
        profile["job_source_strategy"] = dict(DEFAULT_PROFILE["job_source_strategy"])

    return profile


# ---------------------------------------------------------------------------
# Email parsing
# ---------------------------------------------------------------------------

LINKEDIN_SENDER = "jobalerts-noreply@linkedin.com"
INDEED_SENDER = "donotreply@jobalert.indeed.com"


def sender_domain_matches(sender: str, domain: str) -> bool:
    sender = normalize_for_match(sender)
    return domain in sender


def detect_source(sender: str, subject: str, body: str = "") -> str:
    sender_l = normalize_for_match(sender)
    subject_l = normalize_for_match(subject)
    body_l = normalize_for_match(body[:5000])

    if "linkedin.com" in sender_l or "linkedin" in subject_l:
        return "LinkedIn"

    if "indeed.com" in sender_l or "indeed" in subject_l:
        return "Indeed"

    if re.search(r"linkedin\.com/jobs/view/\d+", body_l):
        return "LinkedIn"

    if re.search(r"indeed\.com/[^\s>]+jk=[a-z0-9_-]+", body_l, re.I):
        return "Indeed"

    return ""


def is_job_alert(sender: str, subject: str, body: str = "") -> bool:
    source = detect_source(sender, subject, body)
    if source:
        return True

    subject_l = normalize_for_match(subject)
    indicators = (
        "job alert",
        "jobs matching",
        "jobs you may be interested in",
        "recommended jobs",
        "new jobs",
        "job recommendations",
        "jobs for you",
    )
    return any(term in subject_l for term in indicators)


def extract_message_text(message: Message) -> str:
    text_parts: List[str] = []
    html_parts: List[str] = []

    if message.is_multipart():
        for part in message.walk():
            content_type = part.get_content_type()
            disposition = str(part.get("Content-Disposition", "")).lower()

            if "attachment" in disposition:
                continue

            try:
                payload = part.get_payload(decode=True)
            except Exception:
                payload = None

            if payload is None:
                continue

            charset = part.get_content_charset() or "utf-8"
            try:
                decoded = payload.decode(charset, errors="replace")
            except (LookupError, UnicodeDecodeError):
                decoded = payload.decode("utf-8", errors="replace")

            if content_type == "text/plain":
                text_parts.append(decoded)
            elif content_type == "text/html":
                html_parts.append(decoded)
    else:
        try:
            payload = message.get_payload(decode=True)
        except Exception:
            payload = None

        if payload is not None:
            charset = message.get_content_charset() or "utf-8"
            try:
                decoded = payload.decode(charset, errors="replace")
            except (LookupError, UnicodeDecodeError):
                decoded = payload.decode("utf-8", errors="replace")

            if message.get_content_type() == "text/html":
                html_parts.append(decoded)
            else:
                text_parts.append(decoded)

    if html_parts:
        if BeautifulSoup is not None:
            for raw in html_parts:
                soup = BeautifulSoup(raw, "html.parser")
                text_parts.append(soup.get_text("\n"))
        else:
            for raw in html_parts:
                stripped = re.sub(r"<[^>]+>", " ", raw)
                text_parts.append(stripped)

    return clean_text("\n".join(text_parts))


def extract_urls(body: str) -> List[str]:
    candidates = re.findall(
        r'https?://[^\s<>"\']+',
        body,
        flags=re.I,
    )

    urls = []
    for raw in candidates:
        url = normalize_url(raw.rstrip(".,);]"))
        if url:
            urls.append(url)

    return unique_preserve(urls)


def classify_job_url(url: str) -> str:
    lower = url.lower()

    if "linkedin.com/jobs/view/" in lower:
        return "LinkedIn"

    if "indeed.com" in lower and re.search(r"[?&]jk=", lower):
        return "Indeed"

    return ""


def extract_job_links(body: str, requested_source: str = "Both") -> List[Tuple[str, str]]:
    requested = normalize_for_match(requested_source)
    results: List[Tuple[str, str]] = []

    for url in extract_urls(body):
        source = classify_job_url(url)
        if not source:
            continue

        if requested in {"linkedin", "indeed"} and source.lower() != requested:
            continue

        results.append((source, url))

    return unique_pairs(results)


def unique_pairs(items: Iterable[Tuple[str, str]]) -> List[Tuple[str, str]]:
    seen = set()
    result = []
    for source, url in items:
        key = (source.lower(), normalize_url(url))
        if key not in seen:
            seen.add(key)
            result.append((source, normalize_url(url)))
    return result


# ---------------------------------------------------------------------------
# Job information extraction from EMAIL ONLY
# ---------------------------------------------------------------------------

JOB_TITLE_PATTERNS = [
    r"(?:job title|title|position)\s*[:\-]\s*([^\n|]{3,150})",
    r"(?:role)\s*[:\-]\s*([^\n|]{3,150})",
]

COMPANY_PATTERNS = [
    r"(?:company|employer)\s*[:\-]\s*([^\n|]{2,120})",
]

LOCATION_PATTERNS = [
    r"(?:location|locations)\s*[:\-]\s*([^\n|]{2,150})",
]

SALARY_PATTERNS = [
    r"(?:salary|pay|compensation)\s*[:\-]\s*([^\n|]{2,150})",
]

EMPLOYMENT_PATTERNS = [
    r"(?:employment type|job type|type)\s*[:\-]\s*([^\n|]{2,100})",
]


def first_pattern_value(text: str, patterns: Sequence[str]) -> str:
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.I)
        if match:
            value = normalize_space(match.group(1))
            value = re.split(
                r"\b(?:job description|description|location|company|salary)\b\s*:",
                value,
                maxsplit=1,
                flags=re.I,
            )[0]
            return normalize_space(value)
    return ""


def guess_job_title(subject: str, body: str, profile: dict) -> str:
    for pattern in JOB_TITLE_PATTERNS:
        value = first_pattern_value(body, [pattern])
        if value:
            return value

    # Try subject after removing common alert wording.
    subject_clean = normalize_space(subject)
    subject_clean = re.sub(
        r"\b(job alert|jobs matching|recommended jobs|new jobs|jobs for you)\b",
        "",
        subject_clean,
        flags=re.I,
    )
    subject_clean = normalize_space(subject_clean)

    target_titles = sorted(
        [normalize_space(x) for x in profile.get("target_titles", []) if x],
        key=len,
        reverse=True,
    )

    # Prefer a target title found in the email text.
    combined = f"{subject_clean}\n{body[:12000]}"
    for title in target_titles:
        if re.search(rf"\b{re.escape(title)}\b", combined, flags=re.I):
            return title

    # Common alert format: "Title at Company".
    match = re.search(
        r"^\s*(.+?)\s+(?:at|@)\s+(.+?)(?:\s+\||$)",
        subject_clean,
        flags=re.I,
    )
    if match:
        return normalize_space(match.group(1))

    # Avoid treating the whole email as a title.
    first_line = next(
        (normalize_space(line) for line in body.splitlines() if normalize_space(line)),
        "",
    )
    if 3 <= len(first_line) <= 140:
        return first_line

    return "Unknown title"


def guess_company(body: str) -> str:
    value = first_pattern_value(body, COMPANY_PATTERNS)
    if value:
        return value

    # Common "Title at Company" / "Title - Company" snippets.
    match = re.search(
        r"\bat\s+([A-Z][A-Za-z0-9&.,'’()\- ]{1,100})(?=\s*(?:\||\n|location|Canada|Ontario|Remote|$))",
        body,
        flags=re.I,
    )
    if match:
        return normalize_space(match.group(1))

    return "Unknown company"


def guess_location(body: str) -> str:
    value = first_pattern_value(body, LOCATION_PATTERNS)
    if value:
        return value

    canada_locations = [
        "Remote (Canada)",
        "Remote Canada",
        "Canada-wide",
        "British Columbia",
        "Alberta",
        "Saskatchewan",
        "Manitoba",
        "Ontario",
        "Quebec",
        "New Brunswick",
        "Nova Scotia",
        "Prince Edward Island",
        "Newfoundland and Labrador",
        "Yukon",
        "Northwest Territories",
        "Nunavut",
        "Toronto",
        "Vancouver",
        "Calgary",
        "Edmonton",
        "Ottawa",
        "Montreal",
        "Winnipeg",
        "Hamilton",
        "London",
        "Kitchener",
        "Waterloo",
    ]

    lower = normalize_for_match(body)
    found = []
    for location in canada_locations:
        if normalize_for_match(location) in lower:
            found.append(location)

    return ", ".join(unique_preserve(found))


def extract_salary(body: str) -> str:
    value = first_pattern_value(body, SALARY_PATTERNS)
    if value:
        return value

    match = re.search(
        r"(?:CAD|C\$|\$)\s?\d[\d,]*(?:\.\d+)?\s*(?:-|to)\s*(?:CAD|C\$|\$)?\s?\d[\d,]*(?:\.\d+)?(?:\s*(?:per hour|/hour|hourly|per year|/year|annually))?",
        body,
        flags=re.I,
    )
    return normalize_space(match.group(0)) if match else ""


def extract_employment_type(body: str) -> str:
    value = first_pattern_value(body, EMPLOYMENT_PATTERNS)
    if value:
        return value

    types = [
        "full-time",
        "full time",
        "part-time",
        "part time",
        "contract",
        "temporary",
        "permanent",
        "internship",
        "intern",
    ]
    lower = normalize_for_match(body)
    found = [item for item in types if item in lower]
    return ", ".join(unique_preserve(found))


def extract_job_description(body: str) -> str:
    text = normalize_space(body)
    if not text:
        return ""

    # Remove repeated raw URLs while keeping surrounding email text.
    text = re.sub(r"https?://\S+", " ", text, flags=re.I)
    return normalize_space(text)[:12000]


def email_contains_real_job_signal(title: str, company: str, body: str) -> bool:
    combined = normalize_for_match(f"{title} {company} {body[:15000]}")

    if title.lower() == "unknown title":
        return False

    if len(combined) < 40:
        return False

    # Reject obvious navigation/non-job records.
    navigation_terms = [
        "sign in",
        "log in",
        "create an account",
        "password reset",
        "privacy policy",
        "cookie policy",
        "unsubscribe",
    ]
    if all(term in combined for term in navigation_terms[:2]):
        return False

    return True


# ---------------------------------------------------------------------------
# Canada eligibility and exclusions
# ---------------------------------------------------------------------------

CANADA_PROVINCES_TERRITORIES = [
    "alberta",
    "british columbia",
    "manitoba",
    "new brunswick",
    "newfoundland and labrador",
    "nova scotia",
    "ontario",
    "prince edward island",
    "quebec",
    "saskatchewan",
    "yukon",
    "northwest territories",
    "nunavut",
]


def find_negative_matches(text: str, profile: dict) -> List[str]:
    lower = normalize_for_match(text)
    matches = []

    for rule in profile.get("hard_exclusions", []):
        rule_l = normalize_for_match(rule)
        if not rule_l:
            continue

        # Use exact phrase matching, not broad substring logic where possible.
        if rule_l in lower:
            matches.append(rule)

    # Additional explicit variants.
    exclusion_patterns = {
        "commission only": [
            r"\bcommission[- ]only\b",
            r"\b100%\s*commission\b",
            r"\bcommission[- ]based\b",
        ],
        "unpaid": [
            r"\bunpaid\b",
            r"\bno salary\b",
            r"\bwithout pay\b",
        ],
        "volunteer": [
            r"\bvolunteer(?:ing)?\b",
        ],
        "security clearance required": [
            r"\bsecurity clearance (?:is )?required\b",
            r"\bmust (?:have|obtain) (?:a )?security clearance\b",
        ],
        "requires relocation": [
            r"\brelocation required\b",
            r"\bmust relocate\b",
            r"\brequires relocation\b",
        ],
        "must be a us citizen": [
            r"\bmust be (?:a )?(?:u\.?s\.?|us) citizen\b",
            r"\b(?:u\.?s\.?|us) citizenship required\b",
            r"\bonly (?:u\.?s\.?|us) citizens\b",
        ],
    }

    for label, patterns in exclusion_patterns.items():
        if any(re.search(pattern, lower, flags=re.I) for pattern in patterns):
            matches.append(label)

    return unique_preserve(matches)


def canada_location_status(location: str, body: str) -> Tuple[bool, str]:
    text = normalize_for_match(f"{location}\n{body[:12000]}")

    if not text:
        return False, ""

    if "remote (canada)" in text or "remote canada" in text:
        return True, "Remote (Canada)"

    if "canada-wide" in text or "across canada" in text:
        return True, "Canada-wide"

    if re.search(r"\bcanada\b", text):
        return True, "Canada"

    for place in CANADA_PROVINCES_TERRITORIES:
        if re.search(rf"\b{re.escape(place)}\b", text):
            return True, place.title()

    # Major Canadian cities not all uniquely covered by province names.
    canadian_cities = [
        "toronto", "mississauga", "brampton", "vaughan", "markham",
        "richmond hill", "oakville", "burlington", "ottawa", "hamilton",
        "london", "windsor", "kingston", "kitchener", "waterloo", "guelph",
        "montreal", "quebec city", "calgary", "edmonton", "vancouver",
        "victoria", "winnipeg", "halifax", "saskatoon", "regina", "st. john's",
    ]

    for city in canadian_cities:
        if re.search(rf"\b{re.escape(city)}\b", text):
            return True, city.title()

    # Explicit non-Canada locations should not be accepted.
    non_canada = [
        "united states",
        "usa",
        "u.s.",
        "new york",
        "california",
        "texas",
        "florida",
        "united kingdom",
        "uk",
        "london, uk",
    ]
    if any(term in text for term in non_canada):
        return False, ""

    return False, ""


# ---------------------------------------------------------------------------
# Matching / scoring
# ---------------------------------------------------------------------------

def find_matches(text: str, terms: Iterable[str]) -> List[str]:
    lower = normalize_for_match(text)
    matches = []

    for term in terms:
        term = normalize_space(term)
        if not term:
            continue

        term_l = normalize_for_match(term)

        # Phrase containment is useful for multi-word skills; word-boundary
        # matching is used for short terms to reduce accidental matches.
        if len(term_l) <= 3 and " " not in term_l:
            found = bool(re.search(rf"\b{re.escape(term_l)}\b", lower))
        else:
            found = term_l in lower

        if found:
            matches.append(term)

    return unique_preserve(matches)


def title_family_matches(title: str, profile: dict) -> Tuple[List[str], List[str]]:
    title_matches = find_matches(title, profile.get("target_titles", []))
    family_matches = find_matches(
        f"{title}\n{profile.get('job_families', [])}",
        profile.get("job_families", []),
    )
    return title_matches, family_matches


def analyze_job(
    job: dict,
    profile: dict,
) -> Tuple[int, str, str, dict]:
    title = job.get("job_title", "")
    company = job.get("company", "")
    location = job.get("location", "")
    description = job.get("description", "")

    combined = "\n".join(
        [
            title,
            company,
            location,
            description,
            job.get("salary", ""),
            job.get("employment_type", ""),
        ]
    )

    negative_matches = find_negative_matches(combined, profile)

    title_matches = find_matches(title, profile.get("target_titles", []))
    family_matches = find_matches(
        title,
        profile.get("job_families", []),
    )
    skill_matches = find_matches(combined, profile.get("skills", []))
    experience_matches = find_matches(combined, profile.get("experience", []))

    location_ok, matched_location = canada_location_status(location, combined)

    # Quality-focused scoring, capped at 100.
    score = 0

    if title_matches:
        score += 30
    elif family_matches:
        score += 22
    else:
        # A strong skill/experience match may still deserve REVIEW.
        score += 0

    score += min(30, len(skill_matches) * 4)
    score += min(20, len(experience_matches) * 4)

    if location_ok:
        score += 10

    # Small evidence bonuses, without making the score depend on seniority.
    if re.search(
        r"\b(full[- ]time|permanent|contract)\b",
        normalize_for_match(combined),
    ):
        score += 5

    if re.search(
        r"\b(canada|ontario|alberta|british columbia|quebec|remote)\b",
        normalize_for_match(combined),
    ):
        score += 5

    score = min(100, score)

    apply_threshold = safe_int(
        profile.get("scoring", {}).get("minimum_apply_score", 70),
        70,
    )
    review_threshold = safe_int(
        profile.get("scoring", {}).get("minimum_review_score", 45),
        45,
    )

    if negative_matches:
        decision = "SKIP"
        reason = "Hard exclusion: " + ", ".join(negative_matches)
    elif not location_ok:
        decision = "SKIP"
        reason = "Canadian work location/eligibility not verified from the alert email"
    elif score >= apply_threshold:
        decision = "APPLY"
        reason = "Strong match to target role, skills/experience, and Canadian eligibility"
    elif score >= review_threshold:
        decision = "REVIEW"
        reason = "Potential match; manual review needed before application"
    else:
        decision = "SKIP"
        reason = "Match evidence below review threshold"

    details = {
        "matched_title_terms": title_matches,
        "matched_job_families": family_matches,
        "matched_skills": skill_matches,
        "matched_experience": experience_matches,
        "matched_location": matched_location,
        "negative_matches": negative_matches,
    }

    return score, decision, reason, details


# ---------------------------------------------------------------------------
# Persistent CSV database
# ---------------------------------------------------------------------------

def ensure_csv(path: Path, headers: Sequence[str]) -> None:
    if path.exists() and path.stat().st_size > 0:
        return

    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=headers, extrasaction="ignore")
        writer.writeheader()


def append_csv_row(path: Path, headers: Sequence[str], row: dict) -> None:
    ensure_csv(path, headers)
    with path.open("a", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=headers, extrasaction="ignore")
        writer.writerow(row)


def read_csv_rows(path: Path) -> List[dict]:
    if not path.exists():
        return []

    try:
        with path.open("r", newline="", encoding="utf-8-sig") as handle:
            return list(csv.DictReader(handle))
    except (OSError, csv.Error) as exc:
        logger.error("Could not read %s: %s", path, exc)
        return []


def existing_job_ids() -> set:
    return {
        normalize_space(row.get("job_id"))
        for row in read_csv_rows(JOBS_FILE)
        if normalize_space(row.get("job_id"))
    }


def job_already_exists(job_id: str) -> bool:
    if not job_id:
        return False
    return job_id in existing_job_ids()


def upsert_job(job: dict) -> None:
    ensure_csv(JOBS_FILE, JOB_HEADERS)
    rows = read_csv_rows(JOBS_FILE)
    target_id = job.get("job_id", "")

    if not target_id:
        return

    found = False
    for row in rows:
        if row.get("job_id") == target_id:
            # Preserve first-seen and update current information.
            first_seen = row.get("first_seen") or job.get("first_seen") or now_local_string()
            row.update(job)
            row["first_seen"] = first_seen
            row["last_seen"] = now_local_string()
            found = True
            break

    if found:
        temp = JOBS_FILE.with_suffix(".csv.tmp")
        with temp.open("w", newline="", encoding="utf-8-sig") as handle:
            writer = csv.DictWriter(handle, fieldnames=JOB_HEADERS, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rows)
        temp.replace(JOBS_FILE)
    else:
        append_csv_row(JOBS_FILE, JOB_HEADERS, job)


# ---------------------------------------------------------------------------
# Yahoo IMAP
# ---------------------------------------------------------------------------

def connect_yahoo(config: dict) -> imaplib.IMAP4_SSL:
    email_address = normalize_space(config.get("yahoo_email"))
    app_password = str(config.get("yahoo_app_password") or "").strip()

    if not email_address or not app_password:
        raise RuntimeError(
            "Yahoo email/app password is missing from config.json. "
            "Do not paste the password into chat."
        )

    mail = imaplib.IMAP4_SSL("imap.mail.yahoo.com", 993)
    mail.login(email_address, app_password)
    return mail


def imap_date(days: int) -> str:
    target = datetime.now().date() - timedelta(days=days)
    return target.strftime("%d-%b-%Y")


def fetch_alert_messages(
    config: dict,
    days_to_scan: int,
    requested_source: str = "Both",
) -> List[dict]:
    mail = connect_yahoo(config)
    messages: List[dict] = []

    try:
        status, _ = mail.select("INBOX")
        if status != "OK":
            raise RuntimeError("Could not select Yahoo INBOX")

        since_date = imap_date(days_to_scan)
        status, data = mail.search(None, "SINCE", since_date)

        if status != "OK":
            raise RuntimeError("Yahoo IMAP search failed")

        ids = data[0].split() if data and data[0] else []

        for message_id in ids:
            try:
                status, fetched = mail.fetch(message_id, "(RFC822)")
                if status != "OK" or not fetched:
                    continue

                raw_bytes = None
                for item in fetched:
                    if isinstance(item, tuple) and len(item) >= 2:
                        raw_bytes = item[1]
                        break

                if not raw_bytes:
                    continue

                msg = email.message_from_bytes(raw_bytes)
                sender = decode_mime_header(msg.get("From", ""))
                subject = decode_mime_header(msg.get("Subject", ""))
                date_header = msg.get("Date", "")
                email_dt = parse_email_datetime(date_header)
                body = extract_message_text(msg)

                if not is_job_alert(sender, subject, body):
                    continue

                source = detect_source(sender, subject, body)
                if not source:
                    source = "Unknown"

                if (
                    requested_source.lower() in {"linkedin", "indeed"}
                    and source.lower() != requested_source.lower()
                ):
                    continue

                messages.append(
                    {
                        "imap_id": message_id.decode(errors="replace"),
                        "sender": sender,
                        "subject": subject,
                        "date": iso_date_string(email_dt),
                        "datetime": email_dt,
                        "body": body,
                        "source": source,
                    }
                )
            except Exception as exc:
                logger.exception("Could not parse email %s: %s", message_id, exc)

    finally:
        try:
            mail.close()
        except Exception:
            pass
        try:
            mail.logout()
        except Exception:
            pass

    return messages


# ---------------------------------------------------------------------------
# Job extraction from alert emails
# ---------------------------------------------------------------------------

def extract_jobs_from_alert(
    alert: dict,
    profile: dict,
    requested_source: str = "Both",
) -> List[dict]:
    source = alert.get("source", "")
    subject = alert.get("subject", "")
    body = alert.get("body", "")
    email_date = alert.get("date", "")

    links = extract_job_links(body, requested_source)

    jobs: List[dict] = []

    # A single alert can contain several job links. Each link gets its own
    # record, but all descriptive evidence comes from the email itself.
    for detected_source, url in links:
        job_id = canonical_job_id(detected_source, url)
        if not job_id:
            continue

        title = guess_job_title(subject, body, profile)
        company = guess_company(body)
        location = guess_location(body)
        salary = extract_salary(body)
        employment_type = extract_employment_type(body)
        description = extract_job_description(body)

        if not email_contains_real_job_signal(title, company, body):
            continue

        job = {
            "job_id": job_id,
            "source": detected_source,
            "source_sender": alert.get("sender", ""),
            "email_date": email_date,
            "received_at": now_local_string(),
            "job_url": url,
            "job_title": title,
            "company": company,
            "location": location,
            "employment_type": employment_type,
            "salary": salary,
            "description": description,
            "first_seen": now_local_string(),
            "last_seen": now_local_string(),
        }

        score, decision, reason, details = analyze_job(job, profile)

        job.update(
            {
                "matched_title_terms": "; ".join(details["matched_title_terms"]),
                "matched_job_families": "; ".join(details["matched_job_families"]),
                "matched_skills": "; ".join(details["matched_skills"]),
                "matched_experience": "; ".join(details["matched_experience"]),
                "matched_location": details["matched_location"],
                "negative_matches": "; ".join(details["negative_matches"]),
                "score": score,
                "decision": decision,
                "reason": reason,
            }
        )

        jobs.append(job)

    return jobs


# ---------------------------------------------------------------------------
# Excel tracker
# ---------------------------------------------------------------------------

EXCEL_SHEETS = [
    "Settings",
    "All Jobs",
    "Applications",
    "Dashboard",
]

EXCEL_JOB_COLUMNS = [
    "job_id",
    "source",
    "email_date",
    "job_url",
    "job_title",
    "company",
    "location",
    "employment_type",
    "salary",
    "score",
    "decision",
    "reason",
    "matched_title_terms",
    "matched_job_families",
    "matched_skills",
    "matched_experience",
    "matched_location",
    "negative_matches",
    "first_seen",
    "last_seen",
]


def ensure_excel_tracker() -> None:
    if Workbook is None:
        logger.warning("openpyxl is not installed; Excel tracker skipped.")
        return

    if EXCEL_FILE.exists():
        return

    wb = Workbook()
    default_sheet = wb.active
    wb.remove(default_sheet)

    for sheet_name in EXCEL_SHEETS:
        ws = wb.create_sheet(sheet_name)
        if sheet_name == "All Jobs":
            ws.append(EXCEL_JOB_COLUMNS)
        elif sheet_name == "Applications":
            ws.append(
                EXCEL_JOB_COLUMNS
                + ["Application Status", "Application Date", "Follow-up Date", "Notes"]
            )
        elif sheet_name == "Settings":
            ws.append(["Setting", "Value"])
            ws.append(["Tracker", "JobSearchAgent"])
            ws.append(["Automatic Applications", "Disabled"])
            ws.append(["User Final Decision", "Required"])
            ws.append(["Geography", "Canada-wide"])
            ws.append(["Remote Policy", "Remote positions available in Canada"])
            ws.append(["Search Windows", "7 / 14 / 30 days"])
            ws.append(["Daily Quality Target", "2-3 applications"])
        elif sheet_name == "Dashboard":
            ws.append(["Metric", "Value"])

    wb.save(EXCEL_FILE)


def update_excel_tracker(jobs: List[dict]) -> None:
    if Workbook is None or load_workbook is None:
        return

    ensure_excel_tracker()

    try:
        wb = load_workbook(EXCEL_FILE)
    except Exception as exc:
        logger.error("Could not open Excel tracker: %s", exc)
        return

    try:
        if "All Jobs" not in wb.sheetnames:
            wb.create_sheet("All Jobs")

        ws = wb["All Jobs"]

        if ws.max_row == 1 and ws.cell(1, 1).value is None:
            ws.delete_rows(1)
            ws.append(EXCEL_JOB_COLUMNS)
        elif ws.max_row == 0:
            ws.append(EXCEL_JOB_COLUMNS)

        headers = [
            ws.cell(1, col).value
            for col in range(1, ws.max_column + 1)
        ]

        header_map = {
            normalize_space(header): index + 1
            for index, header in enumerate(headers)
            if header
        }

        if "job_id" not in header_map:
            ws.delete_rows(1, ws.max_row)
            ws.append(EXCEL_JOB_COLUMNS)
            header_map = {
                header: index + 1
                for index, header in enumerate(EXCEL_JOB_COLUMNS)
            }

        id_col = header_map["job_id"]
        existing_rows = {}

        for row_number in range(2, ws.max_row + 1):
            value = normalize_space(ws.cell(row_number, id_col).value)
            if value:
                existing_rows[value] = row_number

        for job in jobs:
            job_id = normalize_space(job.get("job_id"))
            if not job_id:
                continue

            if job_id in existing_rows:
                row_number = existing_rows[job_id]
            else:
                row_number = ws.max_row + 1
                ws.cell(row_number, id_col).value = job_id
                existing_rows[job_id] = row_number

            for column_name in EXCEL_JOB_COLUMNS:
                column = header_map.get(column_name)
                if not column:
                    continue
                ws.cell(row_number, column).value = job.get(column_name, "")

        # Applications sheet: preserve user-entered application columns.
        if "Applications" in wb.sheetnames:
            app_ws = wb["Applications"]
            if app_ws.max_row == 1 and app_ws.cell(1, 1).value is None:
                app_ws.delete_rows(1)
                app_ws.append(
                    EXCEL_JOB_COLUMNS
                    + ["Application Status", "Application Date", "Follow-up Date", "Notes"]
                )

        wb.save(EXCEL_FILE)
    except Exception as exc:
        logger.exception("Could not update Excel tracker: %s", exc)
    finally:
        wb.close()


# ---------------------------------------------------------------------------
# Run history
# ---------------------------------------------------------------------------

def record_run(row: dict) -> None:
    append_csv_row(RUN_HISTORY_FILE, RUN_HEADERS, row)


# ---------------------------------------------------------------------------
# Scan
# ---------------------------------------------------------------------------

def validate_days(days_to_scan: int, config: dict) -> int:
    allowed = config.get("search_windows_days", [7, 14, 30])
    allowed = {
        safe_int(item)
        for item in allowed
        if safe_int(item) in {7, 14, 30}
    }

    days = safe_int(days_to_scan, 7)
    if days not in allowed:
        raise ValueError(
            f"days_to_scan must be one of {sorted(allowed)}; received {days}"
        )

    return days


def scan_jobs(
    config: dict,
    profile: dict,
    days_to_scan: int = 7,
    requested_source: str = "Both",
) -> dict:
    days_to_scan = validate_days(days_to_scan, config)

    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    started = now_local_string()

    summary = {
        "run_id": run_id,
        "run_started_at": started,
        "run_finished_at": "",
        "days_to_scan": days_to_scan,
        "sources": requested_source,
        "emails_scanned": 0,
        "alerts_found": 0,
        "jobs_extracted": 0,
        "new_jobs": 0,
        "duplicate_jobs": 0,
        "apply_count": 0,
        "review_count": 0,
        "skip_count": 0,
        "errors": 0,
        "status": "STARTED",
    }

    try:
        alerts = fetch_alert_messages(
            config=config,
            days_to_scan=days_to_scan,
            requested_source=requested_source,
        )

        summary["emails_scanned"] = len(alerts)
        summary["alerts_found"] = len(alerts)

        known_ids = existing_job_ids()
        extracted_jobs: List[dict] = []

        for alert in alerts:
            try:
                jobs = extract_jobs_from_alert(
                    alert=alert,
                    profile=profile,
                    requested_source=requested_source,
                )

                for job in jobs:
                    extracted_jobs.append(job)

                    if job["job_id"] in known_ids:
                        summary["duplicate_jobs"] += 1
                    else:
                        summary["new_jobs"] += 1
                        known_ids.add(job["job_id"])

                    decision = job.get("decision", "SKIP")
                    if decision == "APPLY":
                        summary["apply_count"] += 1
                    elif decision == "REVIEW":
                        summary["review_count"] += 1
                    else:
                        summary["skip_count"] += 1

                    upsert_job(job)

            except Exception as exc:
                summary["errors"] += 1
                logger.exception("Job extraction error: %s", exc)

        summary["jobs_extracted"] = len(extracted_jobs)

        update_excel_tracker(extracted_jobs)

        summary["status"] = "SUCCESS"

    except Exception as exc:
        summary["errors"] += 1
        summary["status"] = "ERROR"
        logger.exception("Scan failed: %s", exc)

    summary["run_finished_at"] = now_local_string()
    record_run(summary)

    return summary


# ---------------------------------------------------------------------------
# Console reporting
# ---------------------------------------------------------------------------

def print_summary(summary: dict) -> None:
    print("\n" + "=" * 60)
    print("JobSearchAgent — Run Summary")
    print("=" * 60)

    ordered = [
        ("Run ID", "run_id"),
        ("Status", "status"),
        ("Search window", "days_to_scan"),
        ("Source", "sources"),
        ("Emails scanned", "emails_scanned"),
        ("Alerts found", "alerts_found"),
        ("Jobs extracted", "jobs_extracted"),
        ("New jobs", "new_jobs"),
        ("Duplicates", "duplicate_jobs"),
        ("APPLY", "apply_count"),
        ("REVIEW", "review_count"),
        ("SKIP", "skip_count"),
        ("Errors", "errors"),
    ]

    for label, key in ordered:
        print(f"{label:18}: {summary.get(key, '')}")

    print("=" * 60)
    print(f"Job database       : {JOBS_FILE}")
    print(f"Run history        : {RUN_HISTORY_FILE}")
    print(f"Excel tracker      : {EXCEL_FILE}")
    print("=" * 60 + "\n")


def print_top_jobs(limit: int = 20) -> None:
    rows = read_csv_rows(JOBS_FILE)

    def score_value(row: dict) -> int:
        return safe_int(row.get("score"), 0)

    rows.sort(key=score_value, reverse=True)

    print("\nTop matching jobs:")
    print("-" * 100)

    count = 0
    for row in rows:
        if row.get("decision") not in {"APPLY", "REVIEW"}:
            continue

        print(
            f"{row.get('score', 0):>3} | "
            f"{row.get('decision', ''):<6} | "
            f"{row.get('job_title', '')[:45]:<45} | "
            f"{row.get('company', '')[:30]:<30} | "
            f"{row.get('location', '')[:30]}"
        )
        count += 1
        if count >= limit:
            break

    if count == 0:
        print("No APPLY/REVIEW jobs currently stored.")
    print("-" * 100)


# ---------------------------------------------------------------------------
# Simple interactive dashboard
# ---------------------------------------------------------------------------

def dashboard() -> None:
    print("\n" + "=" * 60)
    print("JobSearchAgent Dashboard")
    print("=" * 60)

    rows = read_csv_rows(JOBS_FILE)
    runs = read_csv_rows(RUN_HISTORY_FILE)

    apply_count = sum(1 for row in rows if row.get("decision") == "APPLY")
    review_count = sum(1 for row in rows if row.get("decision") == "REVIEW")
    skip_count = sum(1 for row in rows if row.get("decision") == "SKIP")

    print(f"Stored jobs       : {len(rows)}")
    print(f"APPLY             : {apply_count}")
    print(f"REVIEW            : {review_count}")
    print(f"SKIP              : {skip_count}")
    print(f"Runs              : {len(runs)}")
    print(f"Tracker           : {EXCEL_FILE}")

    print_top_jobs(limit=10)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def usage() -> None:
    print(
        """
Usage:
  python3 job_agent.py
      Run the default 7-day scan for LinkedIn + Indeed alerts.

  python3 job_agent.py scan --days 7
  python3 job_agent.py scan --days 14
  python3 job_agent.py scan --days 30

  python3 job_agent.py scan --days 7 --source linkedin
  python3 job_agent.py scan --days 7 --source indeed
  python3 job_agent.py scan --days 7 --source both

  python3 job_agent.py dashboard

Notes:
  - Only 7, 14, and 30 day windows are supported.
  - No applications are submitted automatically.
  - The Yahoo App Password is read from config.json and never printed.
"""
    )


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = list(argv if argv is not None else sys.argv[1:])

    config = load_config()
    profile = load_profile()

    if not args:
        summary = scan_jobs(
            config=config,
            profile=profile,
            days_to_scan=safe_int(config.get("default_days_to_scan", 7), 7),
            requested_source="Both",
        )
        print_summary(summary)
        return 0 if summary["status"] == "SUCCESS" else 1

    command = args[0].lower()

    if command in {"help", "--help", "-h"}:
        usage()
        return 0

    if command == "dashboard":
        dashboard()
        return 0

    if command == "scan":
        days = safe_int(config.get("default_days_to_scan", 7), 7)
        source = "Both"

        index = 1
        while index < len(args):
            token = args[index].lower()

            if token == "--days":
                if index + 1 >= len(args):
                    print("ERROR: --days requires 7, 14, or 30.")
                    return 2
                days = safe_int(args[index + 1], 0)
                index += 2
                continue

            if token == "--source":
                if index + 1 >= len(args):
                    print("ERROR: --source requires linkedin, indeed, or both.")
                    return 2
                raw_source = args[index + 1].lower()
                if raw_source == "linkedin":
                    source = "LinkedIn"
                elif raw_source == "indeed":
                    source = "Indeed"
                elif raw_source == "both":
                    source = "Both"
                else:
                    print("ERROR: source must be linkedin, indeed, or both.")
                    return 2
                index += 2
                continue

            print(f"ERROR: Unknown argument: {args[index]}")
            usage()
            return 2

        try:
            days = validate_days(days, config)
        except ValueError as exc:
            print(f"ERROR: {exc}")
            return 2

        summary = scan_jobs(
            config=config,
            profile=profile,
            days_to_scan=days,
            requested_source=source,
        )
        print_summary(summary)
        return 0 if summary["status"] == "SUCCESS" else 1

    print(f"ERROR: Unknown command: {command}")
    usage()
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
'''

out.write_text(code, encoding="utf-8")
py_compile.compile(str(out), doraise=True)

print(f"Created: {out}")
print(f"Syntax test: PASSED")
print(f"Size: {out.stat().st_size:,} bytes")
