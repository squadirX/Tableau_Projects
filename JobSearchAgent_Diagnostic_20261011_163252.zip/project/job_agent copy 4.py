#!/usr/bin/env python3

import imaplib
import email
import re
import json
import csv
import os
import ssl
import html
import urllib.request
from email.header import decode_header
from datetime import datetime


# ============================================================
# CONFIG
# ============================================================

BASE_DIR = os.path.expanduser("~/JobSearchAgent")
DATA_DIR = os.path.join(BASE_DIR, "data")
LOG_DIR = os.path.join(BASE_DIR, "logs")

CONFIG_FILE = os.path.join(BASE_DIR, "config.json")
PROFILE_FILE = os.path.join(BASE_DIR, "candidate_profile.json")

JOBS_FILE = os.path.join(DATA_DIR, "jobs.csv")
LOG_FILE = os.path.join(LOG_DIR, "job_agent.log")

YAHOO_IMAP_SERVER = "imap.mail.yahoo.com"
YAHOO_IMAP_PORT = 993


# ============================================================
# DEFAULT CANDIDATE PROFILE
# ============================================================

DEFAULT_PROFILE = {
    "name": "Saiful Quadir",

    "target_titles": [
        "market research analyst",
        "market research manager",
        "data analyst",
        "business analyst",
        "business development analyst",
        "project coordinator",
        "project manager",
        "project analyst",
        "marketing analyst",
        "marketing analytics",
        "operations analyst",
        "software qa",
        "qa analyst",
        "quality assurance analyst"
    ],

    "preferred_locations": [
        "toronto",
        "ontario",
        "canada",
        "remote"
    ],

    "skills": [
        "market research",
        "data analysis",
        "business development",
        "project management",
        "project coordination",
        "stakeholder management",
        "digital surveys",
        "survey analysis",
        "market analysis",
        "competitive analysis",
        "business analysis",
        "data visualization",
        "reporting",
        "power bi",
        "tableau",
        "excel",
        "automation",
        "process improvement",
        "systems analysis",
        "software testing",
        "quality assurance",
        "marketing analytics",
        "machine learning",
        "python",
        "sql"
    ],

    "experience": [
        "market research",
        "digital surveys",
        "data analysis",
        "project management",
        "business development",
        "systems analysis",
        "team management",
        "process automation",
        "reporting",
        "client management"
    ],

    "education": [
        "mba",
        "marketing",
        "b.com",
        "business"
    ],

    "certifications": [
        "google project management",
        "google cybersecurity",
        "ibm machine learning"
    ],

    "do_not_apply": [
        "unpaid",
        "commission only",
        "commission-only",
        "volunteer",
        "must be a us citizen",
        "u.s. citizenship required",
        "security clearance required",
        "requires relocation"
    ]
}


# ============================================================
# UTILITIES
# ============================================================

def log(message):
    os.makedirs(LOG_DIR, exist_ok=True)

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {message}"

    print(line)

    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def load_json(filename, default):
    if not os.path.exists(filename):
        with open(filename, "w", encoding="utf-8") as f:
            json.dump(default, f, indent=4)

        return default

    try:
        with open(filename, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def clean_text(text):
    if not text:
        return ""

    text = html.unescape(text)

    text = re.sub(r"<script.*?</script>", " ", text,
                  flags=re.I | re.S)

    text = re.sub(r"<style.*?</style>", " ", text,
                  flags=re.I | re.S)

    text = re.sub(r"<[^>]+>", " ", text)

    text = re.sub(r"\s+", " ", text)

    return text.strip()


def decode_email_subject(subject):
    if not subject:
        return ""

    result = ""

    for part, encoding in decode_header(subject):

        if isinstance(part, bytes):
            try:
                result += part.decode(
                    encoding or "utf-8",
                    errors="ignore"
                )
            except Exception:
                result += part.decode(
                    "utf-8",
                    errors="ignore"
                )
        else:
            result += str(part)

    return result


# ============================================================
# EMAIL
# ============================================================

def connect_yahoo(config):

    username = config.get("yahoo_email")
    password = config.get("yahoo_app_password")

    if not username or not password:
        raise ValueError(
            "Yahoo email or Yahoo App Password is missing "
            "from config.json"
        )

    context = ssl.create_default_context()

    mail = imaplib.IMAP4_SSL(
        YAHOO_IMAP_SERVER,
        YAHOO_IMAP_PORT,
        ssl_context=context
    )

    mail.login(username, password)

    return mail


def get_email_body(msg):

    body = ""

    if msg.is_multipart():

        for part in msg.walk():

            content_type = part.get_content_type()
            disposition = str(
                part.get("Content-Disposition", "")
            )

            if "attachment" in disposition.lower():
                continue

            if content_type in ["text/plain", "text/html"]:

                try:
                    payload = part.get_payload(
                        decode=True
                    )

                    if payload:
                        charset = part.get_content_charset() or "utf-8"

                        body += payload.decode(
                            charset,
                            errors="ignore"
                        )

                except Exception:
                    pass

    else:

        try:
            payload = msg.get_payload(decode=True)

            if payload:

                charset = msg.get_content_charset() or "utf-8"

                body = payload.decode(
                    charset,
                    errors="ignore"
                )

        except Exception:
            pass

    return body


def is_job_alert(sender, subject, body):

    text = (
        str(sender) +
        " " +
        str(subject) +
        " " +
        str(body)
    ).lower()

    indicators = [
        "linkedin",
        "indeed",
        "job alert",
        "jobs you may be interested",
        "jobs matching",
        "recommended jobs",
        "job recommendations",
        "new jobs"
    ]

    return any(x in text for x in indicators)


# ============================================================
# URL EXTRACTION
# ============================================================

def extract_urls(text):

    if not text:
        return []

    # Basic URL detection
    urls = re.findall(
        r'https?://[^\s<>"\']+',
        text
    )

    cleaned = []

    for url in urls:

        url = html.unescape(url)

        # Remove common trailing characters
        url = url.rstrip(
            ".,);]}>\"'"
        )

        if url not in cleaned:
            cleaned.append(url)

    return cleaned


def classify_url(url):

    low = url.lower()

    if "linkedin.com" in low:
        return "LinkedIn"

    if "indeed.com" in low:
        return "Indeed"

    return "Other"


# ============================================================
# JOB PAGE
# ============================================================

def fetch_page(url):

    headers = {
        "User-Agent":
            "Mozilla/5.0 (Macintosh; Intel Mac OS X) "
            "AppleWebKit/605.1.15 "
            "Version/18.0 Safari/605.1.15"
    }

    request = urllib.request.Request(
        url,
        headers=headers
    )

    try:

        with urllib.request.urlopen(
            request,
            timeout=15
        ) as response:

            data = response.read(
                2_000_000
            )

            charset = response.headers.get_content_charset()

            if not charset:
                charset = "utf-8"

            return clean_text(
                data.decode(
                    charset,
                    errors="ignore"
                )
            )

    except Exception as e:

        log(
            f"Could not read job page: {url} | {e}"
        )

        return ""


# ============================================================
# JOB INFORMATION
# ============================================================

def guess_job_title(subject, body, page):

    combined = (
        subject + " " +
        body + " " +
        page[:10000]
    )

    patterns = [

        r"(?:job title|position|role)\s*[:\-]\s*([A-Za-z0-9 ,/&\-]{3,100})",

        r"(?:hiring|looking for)\s+(?:a|an)?\s*"
        r"([A-Za-z0-9 ,/&\-]{3,100})",

    ]

    for pattern in patterns:

        match = re.search(
            pattern,
            combined,
            re.I
        )

        if match:

            title = match.group(1).strip()

            if len(title) < 100:
                return title

    # Search for known titles
    lower = combined.lower()

    for title in DEFAULT_PROFILE["target_titles"]:

        if title.lower() in lower:
            return title.title()

    return ""


def guess_company(body, page):

    text = body + " " + page[:15000]

    patterns = [

        r"(?:company|employer)\s*[:\-]\s*"
        r"([A-Za-z0-9&.,' \-]{2,100})",

        r"(?:at|with)\s+"
        r"([A-Z][A-Za-z0-9&.,' \-]{2,80})"

    ]

    for pattern in patterns:

        match = re.search(
            pattern,
            text
        )

        if match:

            company = match.group(1).strip()

            if len(company) < 100:
                return company

    return ""


def guess_location(body, page):

    text = body + " " + page[:15000]

    locations = [
        "Toronto",
        "Mississauga",
        "Brampton",
        "Vaughan",
        "Markham",
        "Richmond Hill",
        "Oakville",
        "Burlington",
        "Ontario",
        "Canada",
        "Remote"
    ]

    found = []

    lower = text.lower()

    for location in locations:

        if location.lower() in lower:

            found.append(location)

    return ", ".join(dict.fromkeys(found))


# ============================================================
# MATCHING ENGINE
# ============================================================

def analyze_job(title, company, location, description, profile):

    text = (
        title + " " +
        company + " " +
        location + " " +
        description
    ).lower()

    score = 0

    matched_skills = []
    missing_skills = []

    # -----------------------------------------
    # TITLE
    # -----------------------------------------

    title_score = 0

    for target in profile["target_titles"]:

        if target.lower() in title.lower():

            title_score = 30
            break

    score += title_score

    # -----------------------------------------
    # SKILLS
    # -----------------------------------------

    skills_found = 0

    for skill in profile["skills"]:

        if skill.lower() in text:

            matched_skills.append(skill)
            skills_found += 1

    if skills_found:

        skill_score = min(
            40,
            skills_found * 4
        )

        score += skill_score

    # -----------------------------------------
    # EXPERIENCE
    # -----------------------------------------

    experience_found = 0

    for item in profile["experience"]:

        if item.lower() in text:

            experience_found += 1

    score += min(
        20,
        experience_found * 4
    )

    # -----------------------------------------
    # LOCATION
    # -----------------------------------------

    location_match = False

    for preferred in profile["preferred_locations"]:

        if preferred.lower() in text:

            location_match = True
            break

    if location_match:
        score += 10

    # -----------------------------------------
    # NEGATIVE RULES
    # -----------------------------------------

    negative_matches = []

    for rule in profile["do_not_apply"]:

        if rule.lower() in text:

            negative_matches.append(rule)

    # -----------------------------------------
    # DECISION
    # -----------------------------------------

    if negative_matches:

        decision = "SKIP"

    elif score >= 70:

        decision = "APPLY"

    elif score >= 45:

        decision = "REVIEW"

    else:

        decision = "SKIP"

    return {
        "score": min(score, 100),
        "decision": decision,
        "matched_skills": ", ".join(
            matched_skills[:15]
        ),
        "negative_matches": ", ".join(
            negative_matches
        )
    }


# ============================================================
# DATABASE / CSV
# ============================================================

def existing_urls():

    urls = set()

    if not os.path.exists(JOBS_FILE):
        return urls

    try:

        with open(
            JOBS_FILE,
            "r",
            encoding="utf-8"
        ) as f:

            reader = csv.DictReader(f)

            for row in reader:

                if row.get("url"):
                    urls.add(
                        row["url"]
                    )

    except Exception:
        pass

    return urls


def save_job(job):

    os.makedirs(DATA_DIR, exist_ok=True)

    file_exists = os.path.exists(
        JOBS_FILE
    )

    fields = [
        "date",
        "source",
        "title",
        "company",
        "location",
        "score",
        "decision",
        "matched_skills",
        "negative_matches",
        "url"
    ]

    with open(
        JOBS_FILE,
        "a",
        newline="",
        encoding="utf-8"
    ) as f:

        writer = csv.DictWriter(
            f,
            fieldnames=fields
        )

        if not file_exists:
            writer.writeheader()

        writer.writerow(job)


# ============================================================
# MAIN
# ============================================================

def main():

    print()
    print("=" * 60)
    print("       PERSONAL JOB SEARCH AGENT - V1")
    print("=" * 60)
    print()

    os.makedirs(
        DATA_DIR,
        exist_ok=True
    )

    os.makedirs(
        LOG_DIR,
        exist_ok=True
    )

    config = load_json(
        CONFIG_FILE,
        {
            "yahoo_email": "",
            "yahoo_app_password": "",
            "days_to_scan": 7
        }
    )

    profile = load_json(
        PROFILE_FILE,
        DEFAULT_PROFILE
    )

    if not config.get("yahoo_email"):
        print()
        print("ERROR:")
        print("Please enter your Yahoo email")
        print("and Yahoo App Password in config.json")
        print()
        return

    log("Starting job search agent")

    try:

        mail = connect_yahoo(config)

        log("Connected to Yahoo Mail")

    except Exception as e:

        log(f"Yahoo connection failed: {e}")

        print()
        print("Could not connect to Yahoo Mail.")
        print()
        print("Check:")
        print("1. Yahoo email address")
        print("2. Yahoo App Password")
        print("3. IMAP access")
        print()

        return

    try:

        mail.select("INBOX")

        status, data = mail.search(
            None,
            "ALL"
        )

        if status != "OK":

            log("Could not search inbox")
            return

        message_ids = data[0].split()

        # Only inspect the latest 100 messages
        message_ids = message_ids[-100:]

        known_urls = existing_urls()

        new_jobs = 0

        for message_id in reversed(message_ids):

            try:

                status, msg_data = mail.fetch(
                    message_id,
                    "(RFC822)"
                )

                if status != "OK":
                    continue

                raw_email = msg_data[0][1]

                msg = email.message_from_bytes(
                    raw_email
                )

                subject = decode_email_subject(
                    msg.get("Subject", "")
                )

                sender = msg.get(
                    "From",
                    ""
                )

                body = get_email_body(msg)

                if not is_job_alert(
                    sender,
                    subject,
                    body
                ):
                    continue

                log(
                    f"Job alert found: {subject}"
                )

                urls = extract_urls(
                    body
                )

                job_urls = []

                for url in urls:

                    source = classify_url(
                        url
                    )

                    if source in [
                        "LinkedIn",
                        "Indeed"
                    ]:

                        job_urls.append(
                            (
                                source,
                                url
                            )
                        )

                for source, url in job_urls:

                    if url in known_urls:
                        continue

                    log(
                        f"New job URL: {url}"
                    )

                    page = fetch_page(url)

                    title = guess_job_title(
                        subject,
                        body,
                        page
                    )

                    company = guess_company(
                        body,
                        page
                    )

                    location = guess_location(
                        body,
                        page
                    )

                    description = (
                        body + " " + page
                    )

                    analysis = analyze_job(
                        title,
                        company,
                        location,
                        description,
                        profile
                    )

                    job = {
                        "date":
                            datetime.now().strftime(
                                "%Y-%m-%d %H:%M"
                            ),

                        "source":
                            source,

                        "title":
                            title,

                        "company":
                            company,

                        "location":
                            location,

                        "score":
                            analysis["score"],

                        "decision":
                            analysis["decision"],

                        "matched_skills":
                            analysis[
                                "matched_skills"
                            ],

                        "negative_matches":
                            analysis[
                                "negative_matches"
                            ],

                        "url":
                            url
                    }

                    save_job(job)

                    known_urls.add(url)

                    new_jobs += 1

                    print()
                    print("-" * 60)
                    print(
                        f"Source:    {source}"
                    )
                    print(
                        f"Title:     {title or 'Unknown'}"
                    )
                    print(
                        f"Company:   {company or 'Unknown'}"
                    )
                    print(
                        f"Location:  {location or 'Unknown'}"
                    )
                    print(
                        f"Match:     {analysis['score']}/100"
                    )
                    print(
                        f"Decision:  {analysis['decision']}"
                    )
                    print(
                        f"URL:       {url}"
                    )

            except Exception as e:

                log(
                    f"Error processing email: {e}"
                )

        print()
        print("=" * 60)
        print(
            f"NEW JOBS PROCESSED: {new_jobs}"
        )
        print("=" * 60)
        print()

        print(
            f"Results saved to:\n{JOBS_FILE}"
        )

    finally:

        try:
            mail.logout()
        except Exception:
            pass

        log("Job search agent finished")


if __name__ == "__main__":
    main()
