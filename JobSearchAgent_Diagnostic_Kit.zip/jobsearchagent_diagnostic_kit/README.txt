JobSearchAgent Diagnostic ZIP Kit

This kit does not contain your Mac's local project files because this environment cannot directly access ~/JobSearchAgent. It contains a local builder script that creates a project-specific diagnostic ZIP on your Mac.

Run on your Mac:
1. Unzip this kit.
2. Open Terminal and run (adjust the path to where you extracted the script):

   python3 /path/to/build_diagnostic_zip.py ~/JobSearchAgent

The script writes a verified ZIP into your home folder. It includes relevant Python scripts/backups, jobs.csv, run history, a redacted log tail, scoring-only profile fields, config structure only, and an audit manifest. It deliberately excludes actual config values, .env files, credentials, and unrelated documents.

Privacy note: jobs.csv can still contain personal search history and URLs. Inspect the ZIP before sharing and upload only to a private GitHub repository.
