#!/usr/bin/env python3
"""Build a privacy-conscious JobSearchAgent diagnostic ZIP on the user's Mac.
Run from any directory: python3 build_diagnostic_zip.py [project_dir]
The archive is written to ~/JobSearchAgent_Diagnostic_YYYYMMDD_HHMMSS.zip.
"""
import csv, hashlib, json, os, re, sys, zipfile
from collections import Counter
from datetime import datetime
from pathlib import Path

HOME = Path.home()
PROJECT = Path(sys.argv[1]).expanduser().resolve() if len(sys.argv) > 1 else HOME / "JobSearchAgent"
if not PROJECT.is_dir():
    raise SystemExit(f"Project folder not found: {PROJECT}\nUsage: python3 build_diagnostic_zip.py ~/JobSearchAgent")
OUT = HOME / f"JobSearchAgent_Diagnostic_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
STAGE = HOME / f".JobSearchAgent_Diagnostic_stage_{os.getpid()}"
STAGE.mkdir(parents=True, exist_ok=False)
manifest = {"created_local": datetime.now().isoformat(timespec="seconds"), "project_path_basename": PROJECT.name, "included_files": [], "excluded": ["config.json values/secrets", ".env and credential files", "unrelated documents and spreadsheets", "Python caches"]}

def add_file(src: Path, rel: str):
    if not src.is_file(): return
    dst = STAGE / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes(src.read_bytes())
    data = dst.read_bytes()
    manifest["included_files"].append({"path": rel, "size_bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})

def redact(text: str) -> str:
    # Redact common email, URL query secrets, and credential-like assignments in logs.
    text = re.sub(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", "[REDACTED_EMAIL]", text)
    text = re.sub(r"(?i)(password|app_password|token|secret|api[_-]?key)(\s*[=:]\s*)[^\s,;]+", r"\1\2[REDACTED]", text)
    text = re.sub(r"(?i)(https?://[^\s?]+)\?[^\s]+", r"\1?[REDACTED_QUERY]", text)
    return text

# Main script, Python variants, and backups useful for finding historical CSV writers.
patterns = ["job_agent.py", "job_agent*.py", "job_agent.py.*", "job_agent*.backup*", "job_agent*.before*"]
seen = set()
for pattern in patterns:
    for src in PROJECT.glob(pattern):
        if src.is_file() and src.suffix == ".py" or (src.is_file() and ("backup" in src.name or ".before" in src.name)):
            if src.resolve() in seen: continue
            seen.add(src.resolve())
            add_file(src, f"project/{src.name}")

# CSV is important for reproducing the malformed-row issue; user should share privately.
data_csv = PROJECT / "data" / "jobs.csv"
if data_csv.is_file():
    add_file(data_csv, "project/data/jobs.csv")
    counts = Counter(); sources = Counter(); rows = 0; header = None
    try:
        with data_csv.open("r", encoding="utf-8-sig", errors="replace", newline="") as f:
            reader = csv.reader(f)
            for i, row in enumerate(reader):
                if i == 0: header = row; continue
                rows += 1; counts[len(row)] += 1
                if len(row) > 1: sources[row[1]] += 1
        manifest["jobs_csv_audit"] = {"header": header, "data_rows": rows, "field_count_distribution": dict(counts), "source_counts": dict(sources)}
    except Exception as e:
        manifest["jobs_csv_audit_error"] = type(e).__name__

# Run history and redacted tail of application log.
add_file(PROJECT / "logs" / "run_history.csv", "project/logs/run_history.csv")
log = PROJECT / "logs" / "job_agent.log"
if log.is_file():
    try:
        lines = log.read_text(encoding="utf-8", errors="replace").splitlines()[-3000:]
        target = STAGE / "project/logs/job_agent.log.redacted-tail.txt"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text("\n".join(redact(x) for x in lines) + "\n", encoding="utf-8")
        b = target.read_bytes()
        manifest["included_files"].append({"path": "project/logs/job_agent.log.redacted-tail.txt", "size_bytes": len(b), "sha256": hashlib.sha256(b).hexdigest(), "note": "last 3000 lines; common secrets redacted"})
    except Exception as e:
        manifest["log_copy_error"] = type(e).__name__

# Include only scoring-relevant profile fields, not arbitrary personal details.
allowed = {"target_titles", "skills", "experience", "preferred_locations", "do_not_apply"}
for name in ("candidate_profile.json", "candidate_profile_BK1.json"):
    src = PROJECT / name
    if src.is_file():
        try:
            obj = json.loads(src.read_text(encoding="utf-8"))
            sanitized = {k: obj[k] for k in allowed if isinstance(obj, dict) and k in obj}
            dst = STAGE / "project" / (name.replace(".json", "_sanitized.json"))
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_text(json.dumps(sanitized, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
            b = dst.read_bytes()
            manifest["included_files"].append({"path": str(dst.relative_to(STAGE)), "size_bytes": len(b), "sha256": hashlib.sha256(b).hexdigest(), "note": "only allowlisted scoring fields"})
        except Exception as e:
            manifest.setdefault("profile_errors", []).append({"file": name, "error": type(e).__name__})

# Config structure only: never include values.
config = PROJECT / "config.json"
if config.is_file():
    try:
        obj = json.loads(config.read_text(encoding="utf-8"))
        shape = {k: ("<redacted>" if any(t in k.lower() for t in ("password", "token", "secret", "key", "email", "user")) else type(v).__name__) for k, v in obj.items()} if isinstance(obj, dict) else {"root_type": type(obj).__name__}
        dst = STAGE / "project/config_structure_only.json"
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_text(json.dumps(shape, indent=2) + "\n", encoding="utf-8")
        b = dst.read_bytes(); manifest["included_files"].append({"path": "project/config_structure_only.json", "size_bytes": len(b), "sha256": hashlib.sha256(b).hexdigest(), "note": "keys/types only; values excluded"})
    except Exception as e:
        manifest["config_error"] = type(e).__name__

(STAGE / "AUDIT_MANIFEST.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
readme = """# JobSearchAgent diagnostic archive\n\nThis archive was generated locally from your JobSearchAgent folder for code/data-integrity auditing. Keep it private: `data/jobs.csv` can contain job URLs and personal search history. Review the archive before uploading or sharing.\n\n## What is included\n- Main Python script and matching Python copies/backups found at project root\n- `data/jobs.csv` plus a field-count/source audit in `AUDIT_MANIFEST.json`\n- Run history and a redacted tail of the app log\n- Scoring-only sanitized candidate-profile fields\n- Config key/type structure only; config values are not included\n\n## Deliberately excluded\n- `.env`, app passwords, tokens, Keychain data, and actual config values\n- Unrelated documents/spreadsheets and Python caches\n\n## Next step\nSend this ZIP in the conversation or upload it to a **private** GitHub repository. Do not commit it to a public repository. The log redaction catches common patterns but is not perfect, so inspect contents first.\n"""
(STAGE / "README.txt").write_text(readme, encoding="utf-8")
with zipfile.ZipFile(OUT, "w", compression=zipfile.ZIP_DEFLATED) as z:
    for p in STAGE.rglob("*"):
        if p.is_file(): z.write(p, p.relative_to(STAGE))
# Verify archive can be read.
with zipfile.ZipFile(OUT, "r") as z:
    bad = z.testzip()
    if bad: raise SystemExit(f"ZIP verification failed at {bad}")
import shutil
shutil.rmtree(STAGE, ignore_errors=True)
print(f"Created and verified: {OUT}")
print(f"Size: {OUT.stat().st_size:,} bytes")
print(f"Included files: {len(manifest['included_files'])}")
