from flask import Flask, jsonify, render_template
from config import HOST, PORT, REFRESH_SECONDS, EXCEL_FILE
from excel_reader import read_applications
from analytics import build_metrics

app = Flask(__name__)
app.config["TEMPLATES_AUTO_RELOAD"] = True

@app.get("/")
def index():
    return render_template("dashboard.html", refresh_seconds=REFRESH_SECONDS)

@app.get("/api/dashboard")
def dashboard_data():
    data = read_applications()
    if not data["available"]:
        return jsonify({"ok": False, "message": data["message"], "path": str(EXCEL_FILE), "metrics": {}, "headers": [], "rows": []})
    return jsonify({
        "ok": True,
        "message": data["message"],
        "modified": data["modified"],
        "metrics": build_metrics(data["rows"]),
        "headers": data["headers"],
        "rows": data["rows"],
    })

if __name__ == "__main__":
    app.run(host=HOST, port=PORT, debug=False)
