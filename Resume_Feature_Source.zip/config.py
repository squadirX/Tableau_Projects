from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parent
EXCEL_FILE = PROJECT_DIR / "Data" / "Job Application Tracker.xlsx"
HOST = "127.0.0.1"
PORT = 8788
REFRESH_SECONDS = 30
